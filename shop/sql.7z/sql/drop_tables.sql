﻿

DROP TABLE shop_tootja CASCADE;
DROP TABLE shop_lemmik_varuosa;
DROP TABLE shop_varuosa_auto_modifikatsioonid;
DROP TABLE shop_varuosa CASCADE;
DROP TABLE shop_varuosa_kategooria;
DROP TABLE shop_varuosa_seisund;
DROP TABLE shop_varuosa_kulg;



DROP TABLE shop_auto_mark CASCADE;
DROP TABLE shop_auto_modifikatsioon CASCADE;
DROP TABLE shop_mootor;
DROP TABLE shop_auto_mudel;
DROP TABLE shop_klient;

DROP TABLE shop_varuosa_pilt;


DROP SEQUENCE common_seq2;