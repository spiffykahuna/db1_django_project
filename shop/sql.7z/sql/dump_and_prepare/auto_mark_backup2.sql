INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Acura');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Alfa Romeo');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Alpina');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Aro');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Asia');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Aston Martin');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Audi');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Austin');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BMW');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BYD');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Bentley');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Brilliance');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Bugatti');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Buick');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Cadillac');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Caterham');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ChangFeng');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Chery');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Chevrolet');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Chrysler');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Citroen');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Coggiola');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Dacia');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Dadi');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Daewoo');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Daihatsu');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Daimler');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Derways');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Dodge');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Dong Feng');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Doninvest');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Donkervoort');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Eagle');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('FAW');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Ferrari');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Fiat');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Ford');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('GMC');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Geely');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Geo');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Great Wall');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Hafei');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Honda');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HuangHai');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Hummer');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Hyundai');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Infiniti');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Iran Khodro');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Isuzu');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('JAC');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Jaguar');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Jeep');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Kia');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Koenigsegg');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Lamborghini');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Lancia');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Land Rover');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Landwind');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Lexus');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Lifan');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Lincoln');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Lotus');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MG');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mahindra');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Maruti');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Maserati');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Maybach');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mazda');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mercedes-Benz');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mercury');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Metrocab');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Microcar');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mini');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mitsubishi');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Mitsuoka');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Morgan');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Nissan');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Oldsmobile');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Opel');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PUCH');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Pagani');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Peugeot');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Plymouth');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Pontiac');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Porsche');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Proton');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Renault');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Rolls-Royce');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Rover');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SEAT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Saab');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Saleen');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Saturn');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Scion');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ShuangHuan');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Skoda');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Smart');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Spyker');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SsangYong');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Subaru');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Suzuki');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TVR');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Tatra');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Tianma');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Tianye');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Toyota');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Trabant');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Vector');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Volkswagen');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Volvo');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Wartburg');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Wiesmann');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Xin Kai');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ZX');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ВАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Велта');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ГАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ЗАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ЗИЛ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ИЖ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('КАМАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ЛУАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('Москвич');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('СМЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('СеАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ТагАЗ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('УАЗ');

INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Integra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MDX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RDX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RSX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TSX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Acura' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('145', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('146', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('147', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('155', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('156', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('159', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('164', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('166', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('33', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alfetta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Brera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GTV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Giulietta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Spider', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alfa Romeo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B11', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alpina' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B12', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alpina' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alpina' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alpina' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alpina' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Roadster S', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Alpina' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('10', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aro' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('24', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aro' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rocsta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Asia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aston Martin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB9', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aston Martin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DBS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aston Martin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V12 Vanquish', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aston Martin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Aston Martin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Allroad', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cabriolet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Q7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Quattro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RS4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RS6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V8 (D11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Audi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Metro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Austin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mini MK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Austin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Montego', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Austin' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('02 (E10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1er 116', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1er 118', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1er 120', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1er 130', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 315', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 316', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 318', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 323', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 324', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 325', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 328', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 330', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3er 335', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 518', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 520', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 523', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 524', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 525', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 528', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 530', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 535', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 540', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 545', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5er 550', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6er 628', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6er 630', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6er 635', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6er 645', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6er 650', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 725', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 728', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 730', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 732', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 735', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 740', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 745', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 750', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7er 760', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('8er 850', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z3 M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z4 M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BYD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FLYER II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BYD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Arnage', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bentley' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Azure', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bentley' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Brooklands', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bentley' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Continental', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bentley' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mulsanne', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bentley' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Turbo R', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bentley' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Brilliance' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Brilliance' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('57 SC Atlantic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bugatti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EB 16.4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Bugatti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Century', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Enclave', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LE Sabre', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Park Avenue', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Reatta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rendezvous', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Riviera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Roadmaster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Skylark', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Buick' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Catera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DE Ville', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Eldorado', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Escalade', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fleetwood', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SRX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Seville', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XLR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Cadillac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Super Seven', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Caterham' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Flying', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ChangFeng' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ChangFeng' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Amulet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Flagcloud', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fora', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kimo (A1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Oriental Son', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QQ6 (S21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sweet (QQ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tiggo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chery' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Astro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avalanche', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aveo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Beretta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Blazer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-10', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Camaro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Caprice', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Captiva', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cavalier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cobalt', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Colorado', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corsica', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corvette', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Epica', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Equinox', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Evanda', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Express', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Geo Storm', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HHR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Impala', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lacetti', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lanos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lumina', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Metro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Niva', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prizm', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rezzo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SSR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Savana', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Silverado', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Spark', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Starcraft', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Suburban', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tahoe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tracker', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Trailblazer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Uplander', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Van', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Venture', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Viva', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chevrolet' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300C', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aspen', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cirrus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Concorde', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Crossfire', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fifth Avenue', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Voyager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Intrepid', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LE Baron', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LHS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEW Yorker', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Neon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PT Cruiser', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pacifica', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prowler', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Saratoga', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sebring', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stratus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Town &amp; Country', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tracker', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vision', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Voyager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Chrysler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Berlingo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C25', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C4 Picasso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Evasion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jumper', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jumpy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LNA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Saxo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Visa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Xantia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Xsara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Xsara Picasso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Citroen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T-Rex', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Coggiola' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1410', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dacia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('City Leading', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dadi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Shuttle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dadi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Damas', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Espero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Evanda', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kalos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LE Mans', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lacetti', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lanos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Leganza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Magnus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Matiz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Nexia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Nubira', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prince', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Racer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rezzo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tacuma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tico', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daewoo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Altis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Applause', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Atrai/extol', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Be-go', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Boon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Charade', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Copen', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cuore', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Esse', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Feroza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Materia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mira', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Move', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pyzar', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rocky', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sirion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Storia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Terios', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YRV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daihatsu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2.8 - 5.3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daimler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Limousine', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Daimler' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aurora', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Derways' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cowboy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Derways' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Plutus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Derways' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Shuttle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Derways' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avenger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Caliber', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Caravan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Challenger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Charger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Dakota', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Durango', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Caravan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Intrepid', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Magnum', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Neon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Nitro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RAM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ramcharger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Shadow', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Spirit', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stealth', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stratus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Viper', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dodge' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MPV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Dong Feng' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Assol', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Doninvest' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kondor', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Doninvest' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Orion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Doninvest' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('D8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Donkervoort' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Talon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Eagle' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vision', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Eagle' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Admiral', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FAW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jinn', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FAW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vita', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FAW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('360', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('599', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('612 Scaglietti', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('California', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Enzo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F355', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Maranello', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mondial', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Testarossa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ferrari' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('131', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Albea', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Barchetta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Brava', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bravo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cinquecento', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Croma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Doblo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fiorino', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Marea', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Multipla', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('New 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Palio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Panda', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Punto', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Regata', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ritmo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sedici', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Seicento', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stilo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tempra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tipo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('UNO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ulysse', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X 1/9', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Fiat' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aerostar', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bronco', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-MAX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Capri', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Contour', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cougar', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Crown Victoria', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Econoline', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Edge', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Escape', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Escort', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Excursion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Expedition', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Explorer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F-150', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fiesta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fiesta ST', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Five Hundred', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Focus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Focus ST', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Freestyle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fusion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fusion (USA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Galaxy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Granada', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Granada (USA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kuga', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Maverick', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mondeo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mustang', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Orion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Probe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Puma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ranger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-MAX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Scorpio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Shelby', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sierra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Taunus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Taurus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tempo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Thunderbird', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tourneo Connect', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Windstar', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Ford' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Acadia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Envoy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jimmy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Safari', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Savana', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sierra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sonoma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Yukon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('suburban', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GMC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Geely' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Otaka', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Geely' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Metro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Geo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prizm', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Geo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Storm', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Geo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tracker', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Geo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Deer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hover', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Safe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sailor', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Socool', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Wingle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Great Wall' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Brio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hafei' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Princip', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hafei' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Simbo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hafei' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Accord', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Airwave', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avancier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CR-V', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Capa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('City', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Civic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Civic Shuttle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Concerto', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Domani', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Edix', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Element', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FR-V', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fit Aria', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hr-v', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Insight', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Inspire', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Integra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jazz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Legend', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Life', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Logo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mobilio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Odyssey', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Orthia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Partner', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Passport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pilot', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prelude', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rafaga', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ridgeline', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S2000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Saber', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Shuttle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sm-x', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stepwgn', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stream', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Torneo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vamos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vigor', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Honda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Antelope', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HuangHai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hummer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hummer' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hummer H1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hummer' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hummer H2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hummer' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hummer H3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hummer' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Accent', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Atos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Elantra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Galloper', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Getz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grandeur', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('H-1 Starex', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('H100', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lavita', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Marcia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Matrix', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NF', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pony', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Santa FE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Santamo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sonata', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Terracan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tiburon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Trajet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tucson', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tuscani', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Veracruz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Verna', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Hyundai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX 35', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX 45', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX 50', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G35', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G37', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('I30', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('I35', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J30', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M35', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M45', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Q45', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QX4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QX56', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Infiniti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Samand', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Iran Khodro' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ascender', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aska', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Axiom', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bighorn', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Gemini', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Impulse', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rodeo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Trooper', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VehiCross', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Wizard', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Isuzu' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Refine', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rein', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-type', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-type', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-type', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XF', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJS Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJSc Convertible', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XK 8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XKR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jaguar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CJ5 - CJ8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cherokee', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Commander', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Compass', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Cherokee', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Liberty', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Patriot', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Wrangler', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Jeep' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avella', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Besta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Borrego', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Capital', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carens', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carnival', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cee&#039;d', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cerato', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Clarus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Joice', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Magentis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Opirus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Optima', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Picanto', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Potentia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pregio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pride', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Retona', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sedona', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sephia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Shuma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sorento', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Spectra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sportage', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Visto', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Kia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Koenigsegg' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Diablo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lamborghini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Espada', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lamborghini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Gallardo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lamborghini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Murcielago', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lamborghini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Beta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Dedra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Delta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kappa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lybra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Phedra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Thema', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Thesis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Y', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lancia' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90/110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Defender', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Discovery', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Freelander', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Rover', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Range Rover', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Range Rover Sport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Land Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Double Gate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Landwind' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Landwind' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ES 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ES 330', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ES 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS 450h', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS 460', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS 250', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS-F', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS 460', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS 600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LX 450', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LX 470', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LX 570', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 330', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 400h', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SC 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SC 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SC 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lexus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Breez (520)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lifan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aviator', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Continental', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MKX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MKZ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mark', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mark LT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Navigator', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Town Car', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Zephyr', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lincoln' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Elise', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lotus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Exige', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lotus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Super 7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Lotus' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGF', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TF', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Marshal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mahindra' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alto', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maruti' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('228', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3200 GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4300 GT Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Biturbo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GranSport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GranTurismo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Quattroporte', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Spyder', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maserati' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Maybach 57 S и Maybach 62 S', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maybach' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Maybach 57 и Maybach 62', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Maybach' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('121', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('929', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Atenza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Axela', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Az-wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-serie', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BT-50', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bongo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CX-7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CX-9', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Capella', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carol', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Demio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E 2000,2200 Bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Eunos 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Eunos Cosmo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Familia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lantis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Levante', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Luce', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MPV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mazda 2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mazda 3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mazda 3 MPS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mazda 5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mazda 6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mazda 6 MPS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Millenia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mx-3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mx-5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mx-6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Premacy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Protege', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rx-8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tribute', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Verisa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Xedos 6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Xedos 9', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mazda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES (' Cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES (' Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES (' T-mod.', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('/8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('190', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('220', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('240', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('250', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('260', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 140', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 150', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 160', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 170', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 180', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 190', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-klasse A 210', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-klasse B 170', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-klasse B 180', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-klasse B 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 180', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 220', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 240', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 250', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 270', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 32 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 36 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-klasse C 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL-Klasse CL 420', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL-Klasse CL 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL-Klasse CL 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL-Klasse CL 600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL-Klasse CL 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CL-Klasse CL 65 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLC-klasse CLC 220 CDI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 220', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 240', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 270', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK-klasse CLK 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLS-klasse CLS 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLS-klasse CLS 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLS-klasse CLS 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLS-klasse CLS 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLS-klasse CLS 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 220', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 240', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 250', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 270', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 290', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 420', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 50 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-klasse E 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 250', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 270', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 290', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-Klasse G 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GL-klasse GL 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GL-klasse GL 420', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GL-klasse GL 450', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GL-klasse GL 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GL-klasse GL 550', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 270', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-klasse ML 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pullmann', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R-klasse', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R-klasse R 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R-klasse R 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R-klasse R 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 260', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 380', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 420', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 450', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 550', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 560', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-klasse S 65 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 380', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 420', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 450', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 63 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL-klasse SL 65 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 32 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 320', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 350', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK-klasse SLK 55 AMG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLR McLaren', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V-klasse V 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V-klasse V 220', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V-klasse V 230', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V-klasse V 280', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vaneo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Viano', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercedes-Benz' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Capri', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cougar', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Marquis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mariner', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Montego', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mountaineer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mystique', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sable', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Topaz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tracer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Villager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mercury' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Taxi  (II -series)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Metrocab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MC1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Microcar' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Clubman', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cooper', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('One', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mini' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3000 GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Airtrek', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aspire', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carisma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Challenger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Chariot', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Colt', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Debonair', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Delica', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Diamante', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Dingo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Dion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EK Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Eclipse', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Emeraude', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Endeavor', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FTO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GTO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Galant', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grandis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lancer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lancer Cedia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lancer Evolution', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Legnum', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Libero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Minica', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mirage', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Montero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Montero Sport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Outlander', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pajero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pajero Sport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RVR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sapporo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sigma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Space Gear', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Space Runner', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Space Star', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Space Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Starion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Town BOX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsubishi' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Galue', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsuoka' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Le-Sayde', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsuoka' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Le-Seyde', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Mitsuoka' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aero 8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Morgan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 NX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 SX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300 ZX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('350Z', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AD', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Almera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Almera Classic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Almera Tino', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Altima', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Armada', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avenir', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bassara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bluebird', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cedric', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cefiro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cherry', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cima', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cube', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Datsun', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Elgrand', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Expert', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fairlady', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Frontier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fuga', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT-R', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Gloria', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('King Cab', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lafesta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Largo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Laurel', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Leopard', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Liberty', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lucino', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('March', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Maxima', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Micra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mistral', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Moco', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Murano', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Navara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Note', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pathfinder', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Patrol', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pick UP', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prairie', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Presage', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Presea', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Primera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pulsar', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Qashqai', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Quest', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R Nessa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rasheen', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rogue', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Safari', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sentra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Serena', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Silvia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Skyline', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stagea', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stanza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sunny', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Teana', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Terrano', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tiida', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tino', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Titan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Urvan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vanette', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Wingroad', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-Terra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-Trail', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Nissan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Achieva', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Oldsmobile' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Oldsmobile' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aurora', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Oldsmobile' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bravada', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Oldsmobile' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cutlass', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Oldsmobile' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Silhouette', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Oldsmobile' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Agila', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Antara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ascona', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Astra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Astra OPC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Calibra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Campo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Combo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Commodore', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corsa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corsa OPC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Frontera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kadett', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Manta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Meriva', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Monterey', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Movano', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Omega', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rekord', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Senator', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Signum', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sintra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Speedster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tigra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vectra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vita', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Zafira', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Opel' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-modell', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PUCH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pinzgauer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PUCH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Zonda C12', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pagani' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1007', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('106', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('107', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('205', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('206', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('207', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('305', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('306', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('307', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('308', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('309', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4007', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('405', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('406', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('407', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('605', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('607', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('806', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('807', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Peugeot' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Acclaim', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Breeze', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Voyager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Laser', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Neon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prowler', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sundance', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Voyager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Plymouth' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aztec', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bonneville', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Firebird', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GTO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand AM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Prix', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Phoenix', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Solstige', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sunbird', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sunfire', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Trans Sport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vibe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Pontiac' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('924', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('928', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('944', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('968', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Boxster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carrera GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cayenne', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cayman', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Porsche' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Persona 300 Compact', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Proton' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Persona 400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Proton' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('11', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('18', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('20', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('25', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avantime', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Clio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Clio Symbol', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Espace', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fuego', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Scenic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kangoo Express', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kangoo Passenger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Laguna', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Logan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Master', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Megane', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Modus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rapid', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Safrane', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Scenic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Scenic RX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Super 5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Symbol', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Trafic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Twingo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vel Satis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Renault' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corniche Cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rolls-Royce' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Phantom', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rolls-Royce' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Phantom Drophead Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rolls-Royce' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Silver Seraph', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rolls-Royce' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Silver Spur', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rolls-Royce' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('25', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('45', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('800', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Maestro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mini MK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Montego', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Rover' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alhambra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Altea', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Arosa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cordoba', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ibiza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Leon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Malaga', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ronda', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Toledo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-2X', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-7X', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('99', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saab' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saleen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ION', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saturn' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saturn' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saturn' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saturn' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VUE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Saturn' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('tC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Scion' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('xA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Scion' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('xB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Scion' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sceo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ShuangHuan' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fabia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Favorit', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Felicia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Octavia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Octavia Scout', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Roomster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Superb', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Skoda' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Crossblade', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Smart' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Forfour', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Smart' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fortwo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Smart' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Smart' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Spyker' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Actyon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Chairman', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Family', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Istana', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Korando', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kyron', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Musso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rexton', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Rodius', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SsangYong' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Baja', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Forester', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Impreza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Impreza WRX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Justy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Legacy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Leone', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Libero', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Outback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pleo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SVX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Stella', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Traviq', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tribeca', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vivio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Subaru' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aerio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alto', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Baleno', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cultus Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Escudo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Every', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Every Landy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Forenza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Vitara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ignis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jimny', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kei', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Liana', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MR Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SX4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Samurai', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sidekick', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Swift', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Verona', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vitara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Wagon R+', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XL7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Suzuki' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Griffith', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T613', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Tatra' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Century', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Tianma' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Admiral', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Tianye' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4runner', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Allex', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Allion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Alphard', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Altezza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aristo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aurion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Auris', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avalon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avensis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Avensis Verso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Brevis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Caldina', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cami', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Camry', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Camry Solara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carib', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carina', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carina E', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Carina ED', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cavalier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Celica', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Chaser', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla Ceres', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla FX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla Fielder', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla Levin', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla Rumion', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla RunX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla Spacio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corolla Verso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corona', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corsa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cressida', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cresta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Crown', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Crown Athlete', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Crown Majesta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Curren', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Cynos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Duet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Echo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Estima', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FJ Cruiser', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fortuner', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Funcargo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Gaia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Grand Hiace', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Granvia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Harrier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hiace', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Highlander', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hilux Pick Up', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Hilux Surf', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ipsum', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ist', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kluger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser (120) Prado', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser (90) Prado', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser 100', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser 200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser 70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Land Cruiser 80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lite Ace', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MR 2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MR-S', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mark II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Mark X', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MasterAce', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Matrix', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Nadia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Noah', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Opa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Origin', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Paseo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Passo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Picnic', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Platz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Porte', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Premio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Previa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Prius', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Probox', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Progres', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pronard', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RAV 4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ractis', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Raum', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Regius', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Regius Ace', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Scepter', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sequoia', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sera', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sienna', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sienta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Soarer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Solara', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sparky', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sprinter', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Starlet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Succeed', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Supra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tacoma', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tercel', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tundra', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vellfire', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Venza', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Verossa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vista', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vitz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Voltz', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Voxy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Will', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Windom', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Wish', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Yaris', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Yaris Verso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Toyota' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 601', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Trabant' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('W8 Twin Turbo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Vector' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Bora', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Caddy', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Corrado', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Eos', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Fox', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Golf', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Golf Plus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Jetta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kaefer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Lupo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Multivan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEW Beetle', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Passat', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Phaeton', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Pointer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Polo', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Santana', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Scirocco', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sharan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Taro', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tiguan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Touareg', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Touran', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Vento', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volkswagen' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('164', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('240', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('340-360', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('440 K', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('460 L', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('480 E', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('740', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('760', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('780 Bertone', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('940', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('960', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C30', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S40', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S60', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V40 Kombi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V50', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XC70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XC90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Volvo' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('353', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Wartburg' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Wiesmann' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Wiesmann' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PICKUP X3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Xin Kai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SR-V X3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Xin Kai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUV X3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Xin Kai' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GrandTiger', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ZX' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Landmark', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ZX' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1111 Ока 1111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1111 Ока 11113', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2101', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2102', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2103', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2104', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21043', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21047', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2105', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21053', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21054', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21055', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2106', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21061', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21063', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21065', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2107', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21071', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21072', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21073', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21074', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21079', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2108', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21081', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21083', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21086', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2108i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2109', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21093', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21099', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21099i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2109i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21101', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21102', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21103', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21104', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21108', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21112', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21113', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2112', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21121', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21122', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21123', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21124', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2113', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2114', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2115', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2115 Wankel', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2115i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2120 Надежда', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2121 4x4 2121', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2121 4x4 21213', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2121 4x4 21214', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2121 4x4 21217', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2121 4x4 21218', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2123', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2129', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2131', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2329', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kalina Hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kalina Sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Kalina Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Priora', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ВАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Автокам', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Велта' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('13', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('14', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('20', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('22', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('24', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3102', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31022', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('310221', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31026', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31029', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3102i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3105', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31105', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('311055', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3110i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('69', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('М1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ГАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1102', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1103', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1105', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1140', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('965', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('968', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Sens', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('114', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗИЛ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('117', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗИЛ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4104', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЗИЛ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2125', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2126', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21261', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2715', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2717', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('27171', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('412', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ИЖ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Ока', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='КАМАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('967', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЛУАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('968', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЛУАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('969', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ЛУАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2125', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2140', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2141', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2335', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('401', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('402', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('403', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('406', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('407', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('408', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('412', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('423 Kombi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5846', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aslk 2137 Kombi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aslk 2138', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Aslk 2140', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Князь Владимир', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Святогор', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Юрий Долгорукий', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='Москвич' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Мотоколяска', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='СМЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='СеАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Tager', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ТагАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2206', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3151', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31512', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31514', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31519', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('315195', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3153', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3159', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3160', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3162', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3163', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('469', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='УАЗ' ));            
            
