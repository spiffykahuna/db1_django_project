﻿SELECT mark, mudel
FROM shop_auto_mudel LEFT JOIN shop_auto_mark ON
shop_auto_mudel.auto_mark_id=shop_auto_mark.id
ORDER BY mark,mudel