#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on Apr 6, 2012

@author: deko
'''

if __name__ == '__main__':
    import os
    import csv
    filename = os.path.join(os.path.dirname(__file__), 'motor_dump/temp.csv')
    with open(filename) as f:
        reader = csv.reader(f)
        makes = {}
        
        for rowNum,row in enumerate(reader):
            if rowNum == 0:
                continue
            if row[0] in makes:
                makes[row[0]].append(row[1])
            else:
                makes[row[0]] = [row[1]] 
    
    makeQuery = ''
    for make in sorted(makes.keys()):        
        makeQuery += ('INSERT INTO "shop_auto_mark" ("mark") VALUES '
                       + ' (\'%s\');' % make + '\n' )
    #print makeQuery
    
    modelQuery = ''
    for make,models in sorted(makes.items()):
        for model in models:
            modelQuery += (
            """INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES (\'%s\', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark=\'%s\' ));            
            """ %(model,make))
    #print modelQuery
    
    filename = os.path.join(os.path.dirname(__file__), 'make_and_models.sql')
    with open(filename,'w') as f:
        f.write(makeQuery)
        f.write('\n')        
        f.write(modelQuery)
        f.write('\n')        
        
        
          
        