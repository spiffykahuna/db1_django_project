#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on Apr 7, 2012

@author: deko
'''

import csv, codecs, cStringIO

class UTF8Recoder:
    """
    Iterator that reads an encoded stream and reencodes the input to UTF-8
    """
    def __init__(self, f, encoding):
        self.reader = codecs.getreader(encoding)(f)

    def __iter__(self):
        return self

    def next(self):
        return self.reader.next().encode('utf-8')

class UnicodeCsvReader:
    """
    A CSV reader which will iterate over lines in the CSV file "f",
    which is encoded in the given encoding.
    """

    def __init__(self, f, dialect=csv.excel, encoding='utf-8', **kwds):
        f = UTF8Recoder(f, encoding)
        self.reader = csv.reader(f, dialect=dialect, **kwds)
        self.encoding = encoding

    def next(self):
        row = self.reader.next()
        return [unicode(s, self.encoding) for s in row]

    def __iter__(self):
        return self
    
    @property
    def line_num(self):
        return self.reader.line_num    
    

class UnicodeCsvWriter:
    """
    A CSV writer which will write rows to CSV file "f",
    which is encoded in the given encoding.
    """

    def __init__(self, f, dialect=csv.excel, encoding='utf-8', **kwds):
        # Redirect output to a queue
        self.queue = cStringIO.StringIO()
        self.writer = csv.writer(self.queue, dialect=dialect, **kwds)
        self.stream = f
        self.encoder = codecs.getincrementalencoder(encoding)()

    def writerow(self, row):
        """@param row: should be iterable"""        
        self.writer.writerow([s.encode('utf-8') for s in row])
        # Fetch UTF-8 output from the queue ...
        data = self.queue.getvalue()
        data = data.decode('utf-8')
        # ... and reencode it into the target encoding
        data = self.encoder.encode(data)
        # write to the target stream
        self.stream.write(data)
        # empty queue
        self.queue.truncate(0)

    def writerows(self, rows):
        """@param rows: should be iterable"""
        for row in rows:
            self.writerow(row)

class UnicodeDictReader(csv.DictReader):
    def __init__(self, f, encoding='utf-8', fieldnames=None, **kwds):
        csv.DictReader.__init__(self, f, fieldnames=fieldnames, **kwds)
        self.reader = UnicodeCsvReader(f, encoding=encoding, **kwds)
    
    @property
    def fieldnames(self):
        if self._fieldnames is None:
            try:
                encoding = self.reader.encoding
                encoded = [i.encode(encoding) for i in self.reader.next()] 
                self._fieldnames = encoded
            except StopIteration:
                pass
        self.line_num = self.reader.line_num
        return self._fieldnames    
    


class UnicodeDictWriter:
    """
    A CSV writer which will write rows to CSV file "f",
    which is encoded in the given encoding.
    """

    def __init__(self, f,
                 dialect=csv.excel,
                 encoding='utf-8',
                 extrasaction='ignore', # default is 'raise'
                 *args,
                 **kwds):
        # Redirect output to a queue
        self.queue = cStringIO.StringIO()
        self.writer = csv.DictWriter(self.queue,
                                     dialect=dialect,
                                     extrasaction=extrasaction,
                                     *args,
                                     **kwds)
        self.stream = f
        self.encoder = codecs.getincrementalencoder(encoding)()
        self.encoding = encoding

    def writerow(self, row):
        """@param row: should be dict"""      
        if not type(row) is dict:
            raise TypeError('Row should be dictionary type, row type is:' + str(type(row)))  
        self.writer.writerow(self._encode_dict_rows(row))
        # Fetch UTF-8 output from the queue ...
        data = self.queue.getvalue()
        data = data.decode(self.encoding)
        # ... and reencode it into the target encoding
        data = self.encoder.encode(data)
        # write to the target stream
        self.stream.write(data)
        # empty queue
        self.queue.truncate(0)

    def writerows(self, rows):
        """@param rows: should be iterable"""
        for row in rows:
            self.writerow(row)
        
    def writeheader(self):
        self.writer.writeheader()
        # Fetch UTF-8 output from the queue ...
        data = self.queue.getvalue()
        data = data.decode(self.encoding)
        # ... and reencode it into the target encoding
        data = self.encoder.encode(data)
        # write to the target stream
        self.stream.write(data)
        # empty queue
        self.queue.truncate(0)
        
    def _encode_dict_rows(self,row):
        encodedDict = {}
        for key,value in row.iteritems():
            if key is None:
                encKey = None
            else:
                encKey = key.encode(self.encoding)
            if type(value) is list:
                encValue = [i.encode(self.encoding) for i in value]
            else:
                encValue = value.encode(self.encoding)
                            
            encodedDict[encKey] = encValue
        return encodedDict
               

            
def unicode_csv_reader(unicode_csv_data, dialect=csv.excel, **kwargs):
    # csv.py doesn't do Unicode; encode temporarily as UTF-8:
    csv_reader = csv.reader(utf_8_encoder(unicode_csv_data),
                            dialect=dialect, **kwargs)
    for row in csv_reader:
        # decode UTF-8 back to Unicode, cell by cell:
        yield [unicode(cell, 'utf-8') for cell in row]

def utf_8_encoder(unicode_csv_data):
    for line in unicode_csv_data:
        yield line.encode('utf-8')