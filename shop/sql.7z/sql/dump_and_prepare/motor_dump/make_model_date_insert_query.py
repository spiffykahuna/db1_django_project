#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on Apr 11, 2012

@author: deko
'''

import os

from UnicodeCsvReaderWriter import UnicodeCsvReader
from prepare_make_model_queries import carDict
import re
from prepare_make_model_queries import get_uniq_lines
import cStringIO
import datetime



def get_filtered_rows(filename):
    result = []
    
    
    with open(filename) as f:
        reader = UnicodeCsvReader(f, delimiter=';')
        
        
        for row in reader: 
            tempRow = []           
            for cell in row:
                for i in range(10):
                    for word in carDict.keys():
                        if word in cell:
                            cell = cell.replace(word, carDict[word])
                # remove whitespaces and non-breaking
                pattern = re.compile(r'\xa0')  # 160 ascii symbol (&nbsp;)
                cell = re.sub(pattern, ' ', cell)                    
                pattern = re.compile(r'\s+')
                cell = re.sub(pattern, ' ', cell)
                pattern = re.compile('\'') # single quotes in sql
                cell = re.sub(pattern, '\'\'', cell)
                tempRow.append(cell)
                
            result.append(tempRow)
           
    #print result
    return result 


def get_parsed_dates(dateString):
    dates = {'startDate': None,
             'endDate': None
             }
    if '-' not in dateString:
        raise ValueError('- should be in date, str -> ' + dateString)
    start, stop = dateString.split('-')
    if start:
        year, month = start.split('/')
        dates['startDate'] = datetime.date(int(year), int(month), 1)
    if stop:
        year, month = stop.split('/')
        dates['endDate'] = datetime.date(int(year), int(month), 1)
    
    return dates


def get_modified_dates(rows):
    return [ [row[0], row[1], get_parsed_dates(row[2])] for row in rows]
    
    


def make_model_query(modelData):
    resultQuery = ''
    for row in modelData:
        make = row[0]
        model = row[1]
        startDate = row[2]['startDate']
        endDate = row[2]['endDate']
        if startDate is None:
            startDate = 'NULL'
        else:
            startDate = '\'' + startDate.isoformat() + '\''
            
        if endDate is None:
            endDate = 'NULL'
        else:
            endDate = '\'' + endDate.isoformat() + '\''
            
        resultQuery += (
            """
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = %s,
"valjalaske_lopp" = %s
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark=\'%s\' )
AND "mudel" = \'%s\' ;
            """ %(startDate, endDate,make,model))
#            """
#            UPDATE "shop_auto_mudel" SET valjalaske_algus=\'%s\' where (col2 = 'myId');
#insert into mytable select 'value1', 'myId' where not exists (select 1 from mytable where col2='myId');
#            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id", "valjalaske_algus", "valjalaske_lopp") 
#            VALUES (\'%s\', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
#                              WHERE mark=\'%s\' ), \'%s\', \'%s\' );            
#            """ %(model,make, startDate, endDate))
    
    return resultQuery


if __name__ == '__main__':
    uniqLineSet = get_uniq_lines('mark_info.csv')
    tempName = os.path.join(os.path.dirname(__file__), 't1.csv')
    with open(tempName, 'w') as tempFile:
        tempFile.write(''.join(uniqLineSet))
           
    rows = get_filtered_rows('t1.csv')
    modelData = get_modified_dates(rows)
    modelQuery = make_model_query(modelData)
    
    filename = os.path.join(os.path.dirname(__file__), 'model_dates.sql')
    with open(filename, 'w') as tempFile:
        tempFile.write(modelQuery)
    #print modelData
    
    os.remove(tempName)
    