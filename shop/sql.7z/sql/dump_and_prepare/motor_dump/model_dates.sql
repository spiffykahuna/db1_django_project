
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1974-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = '428 Fastback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-01-01',
"valjalaske_lopp" = '1974-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = '428 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = 'ACE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = 'ACE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = 'ACECA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = 'COBRA Mk IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AC' )
AND "mudel" = 'ME' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'INTEGRA hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'INTEGRA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'INTEGRA sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'LEGEND II coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'LEGEND III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'LEGEND coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'LEGEND' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'Legend II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'NSX тарга' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ACURA' )
AND "mudel" = 'NSX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '2001-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '145 (930)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-12-01',
"valjalaske_lopp" = '2001-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '146 (930)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '147 (937)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '155 (167)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '156 (932)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '156 Sportwagon (932)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '164 (164)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '166 (936)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1975-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '1750-2000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-03-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '2300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-05-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '33 (905)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '33 (907A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '33 Sport Wagon (907B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '33 Sportwagon (905A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-04-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '6 (119)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-05-01',
"valjalaske_lopp" = '1992-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '75 (162B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1987-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = '90 (162)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-06-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'ALFASUD (901)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'ALFASUD Giardinetta (904)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-09-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'ALFASUD Sprint (902.A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-07-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'ALFETTA (116)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-01-01',
"valjalaske_lopp" = '1986-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'ALFETTA GT (116)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-04-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'AR 6 bus (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-04-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'AR 6 truck (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'AR 8 c бортовой платформой/ходовая часть (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'AR 8 truck (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'ARNA (920)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GIULIA GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-06-01',
"valjalaske_lopp" = '1978-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GIULIA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-10-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GIULIETTA (116)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-03-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-05-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GTA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1987-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GTV (116)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'GTV (916C_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-12-01',
"valjalaske_lopp" = '1979-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'MONTREAL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'RZ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-03-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'SPIDER (105)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-03-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'SPIDER (115)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'SPIDER (916S_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALFA ROMEO' )
AND "mudel" = 'SZ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1995-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B10 (E34)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B10 (E39)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-11-01',
"valjalaske_lopp" = '1996-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B10 Touring (E34)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B10 Touring (E39)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1994-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B11 (E32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-07-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B12 (E32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = '2001-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B12 (E38)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B12 coupe (E31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-04-01',
"valjalaske_lopp" = '1999-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 Touring (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-04-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 Touring (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 Touring (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 cabrio (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-04-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 cabrio (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 cabrio (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 coupe (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B3 coupe (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-03-01',
"valjalaske_lopp" = '1983-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B6 (E21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B6 (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1993-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B6 (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-12-01',
"valjalaske_lopp" = '1982-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B7 (E12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-04-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B7 (E28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B7 (E65)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-12-01',
"valjalaske_lopp" = '1988-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B7 coupe (E24)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B8 (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B8 Touring (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B8 cabrio (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B8 coupe (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-11-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B9 (E28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-07-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'B9 coupe (E24)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1983-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'C1 (E21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-08-01',
"valjalaske_lopp" = '1988-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'C1 (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1988-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'C2 (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-02-01',
"valjalaske_lopp" = '1987-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'C2 cabrio (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'D10 (E39)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'D10 Touring (E39)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'RLE Roadster (Z1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'ROADSTER (Z8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINA' )
AND "mudel" = 'ROADSTER S (Z4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = '1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = '1600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = 'A110' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = 'A310' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = 'A610' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = 'BERLINETTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ALPINE' )
AND "mudel" = 'V6' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ARO INTREPRINDEREA' )
AND "mudel" = '10' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ARO INTREPRINDEREA' )
AND "mudel" = '240-244' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ARO INTREPRINDEREA' )
AND "mudel" = 'SPARTANA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASIA MOTORS' )
AND "mudel" = 'HI-TOPIC (AM 725)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASIA MOTORS' )
AND "mudel" = 'ROCSTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'BULLDOG' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-10-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DB6 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-10-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DB6 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DB7 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DB7 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DB9 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DB9 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'DBS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'LAGONDA I universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'LAGONDA I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'LAGONDA universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'LAGONDA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'TICKFORD CAPRI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'V8 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'V8 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VANQUISH' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VIRAGE LIMITED EDITI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VIRAGE Saloon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VIRAGE cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VIRAGE coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VIRAGE coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'VIRAGE universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'ZAGATO cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ASTON MARTIN' )
AND "mudel" = 'ZAGATO coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-06-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 (43, C2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 (44, 44Q, C3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 (4A, C4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-11-01',
"valjalaske_lopp" = '1976-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 (C1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-07-01',
"valjalaske_lopp" = '1983-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 Avant (43, C2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 Avant (44, 44Q, C3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 Avant (4A, C4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '100 coupe (C1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-10-01',
"valjalaske_lopp" = '1982-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '200 (43)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-06-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '200 (44, 44Q)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '200 Avant (44, 44Q)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-08-01',
"valjalaske_lopp" = '1978-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '50 (86)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1973-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '60 Variant' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1973-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '60' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-09-01',
"valjalaske_lopp" = '1973-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '75 Variant' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-09-01',
"valjalaske_lopp" = '1973-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '75' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-05-01',
"valjalaske_lopp" = '1978-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '80 (80, 82, B1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-08-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '80 (81, 85, B2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1991-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '80 (89, 89Q, 8A, B3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '80 (8C, B4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1996-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '80 Avant (8C, B4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1987-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '90 (81, 85, B2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-04-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '90 (89, 89Q, 8A, B3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1971-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = '90 Super' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A2 (8Z0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A3 (8L1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A3 (8P1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A3 Sportback (8PA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A4 (8D2, B5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A4 (8E2, B6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A4 Avant (8D5, B5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A4 Avant (8E5, B6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A4 cabrio (8H7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '1997-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A6 (4A, C4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A6 (4B, C5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A6 (4F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A6 Avant (4A, C4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A6 Avant (4B, C5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A8 (4D2, 4D8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'A8 (4E_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'ALLROAD (4BH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-05-01',
"valjalaske_lopp" = '2000-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'CABRIOLET (8G7, B4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1988-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'COUPE (81, 85)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'COUPE (89, 8B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1977-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'NSU RO 80' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1991-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'QUATTRO (85)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'TT (8N3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'TT Roadster (8N9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1994-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUDI' )
AND "mudel" = 'V8 (D1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-03-01',
"valjalaske_lopp" = '1971-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN-HEALEY' )
AND "mudel" = 'AUSTIN-HEALEY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1974-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = '1000-Series MK II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-05-01',
"valjalaske_lopp" = '1982-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'ALLEGRO (ADO 67)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-08-01',
"valjalaske_lopp" = '1982-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'ALLEGRO universal (ADO 67)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1984-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'AMBASSADOR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-11-01',
"valjalaske_lopp" = '1974-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'APACHE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'MAESTRO (XC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-10-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'MAXI II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-04-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'MAXI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-10-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'METRO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'MINI MK I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-04-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'MONTEGO (XE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'MONTEGO universal (XE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-10-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'PRINCESS 2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-04-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUSTIN' )
AND "mudel" = 'PRINCESS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-06-01',
"valjalaske_lopp" = '1965-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'AU 1000 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-04-01',
"valjalaske_lopp" = '1965-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'AU 1000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-03-01',
"valjalaske_lopp" = '1969-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'AUDI 80 L' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-04-01',
"valjalaske_lopp" = '1968-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'AUDI N Variant' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-08-01',
"valjalaske_lopp" = '1970-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'AUDI N' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-11-01',
"valjalaske_lopp" = '1970-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'AUDI SUPER 90' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-03-01',
"valjalaske_lopp" = '1967-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW F102' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-04-01',
"valjalaske_lopp" = '1953-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW F10' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-02-01',
"valjalaske_lopp" = '1966-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW F11' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-11-01',
"valjalaske_lopp" = '1966-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW F12 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-11-01',
"valjalaske_lopp" = '1966-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW F12' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-08-01',
"valjalaske_lopp" = '1955-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW MEISTERKLASSE F' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1951-12-01',
"valjalaske_lopp" = '1955-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW MEISTERKLASSE Universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1956-05-01',
"valjalaske_lopp" = '1960-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW SONDERKLASSE F Universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-09-01',
"valjalaske_lopp" = '1960-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW SONDERKLASSE F' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-04-01',
"valjalaske_lopp" = '1957-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW SONDERKLASSE Universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-04-01',
"valjalaske_lopp" = '1957-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'DKW SONDERKLASSE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1956-11-01',
"valjalaske_lopp" = '1969-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTO UNION' )
AND "mudel" = 'MUNGA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-08-01',
"valjalaske_lopp" = '1972-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTOBIANCHI' )
AND "mudel" = 'A 111' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTOBIANCHI' )
AND "mudel" = 'A 112' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-03-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='AUTOBIANCHI' )
AND "mudel" = 'Y10' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BARKAS' )
AND "mudel" = 'B 1000 bus (KB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-04-01',
"valjalaske_lopp" = '1976-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BARKAS' )
AND "mudel" = 'B 1000 bus (KO)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BARKAS' )
AND "mudel" = 'B 1000 truck (KM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-08-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BEDFORD' )
AND "mudel" = 'BLITZ (CF97)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-06-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BEDFORD' )
AND "mudel" = 'CHEVANNE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BEDFORD' )
AND "mudel" = 'MIDI bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BEDFORD' )
AND "mudel" = 'MIDI truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BEDFORD' )
AND "mudel" = 'RASCAL bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BEDFORD' )
AND "mudel" = 'RASCAL truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'ARNAGE I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'ARNAGE II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'ARNAGE Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'ARNAGE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'AZURE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'CONTINENTAL GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BENTLEY' )
AND "mudel" = 'CONTINENTAL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BERTONE' )
AND "mudel" = 'FREECLIMBER 2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BERTONE' )
AND "mudel" = 'FREECLIMBER Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BERTONE' )
AND "mudel" = 'FREECLIMBER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BITTER' )
AND "mudel" = 'TYPE 3 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-04-01',
"valjalaske_lopp" = '1977-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '02 (E10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1975-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '02 Touring (E6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-12-01',
"valjalaske_lopp" = '1975-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '02 cabrio (E10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '1 (E87)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1972-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '1500-2000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1969-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '1600 GT coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-10-01',
"valjalaske_lopp" = '1966-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '2.6- 3200 V8 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1976-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '2000-3.2 coupe (E9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1977-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '2500-3.3 (E3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-06-01',
"valjalaske_lopp" = '1984-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 (E21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-09-01',
"valjalaske_lopp" = '1992-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2000-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 Compact (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 Compact (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-07-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 Touring (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1999-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 Touring (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 Touring (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-12-01',
"valjalaske_lopp" = '1993-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 cabrio (E30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 cabrio (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 cabrio (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 coupe (E36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '3 coupe (E46)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-08-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 (E12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-06-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 (E28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 (E34)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 (E39)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 (E60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-11-01',
"valjalaske_lopp" = '1997-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 Touring (E34)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 Touring (E39)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '5 Touring' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1952-07-01',
"valjalaske_lopp" = '1959-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '501' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-01-01',
"valjalaske_lopp" = '1961-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '503 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-04-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '6 (E24)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '6 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-12-01',
"valjalaske_lopp" = '1961-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '6' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-05-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '7 (E23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '7 (E32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2001-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '7 (E38)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '7 (E65, E66)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-08-01',
"valjalaske_lopp" = '1964-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '700 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-01-01',
"valjalaske_lopp" = '1966-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '700' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-04-01',
"valjalaske_lopp" = '1999-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = '8 (E31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1956-01-01',
"valjalaske_lopp" = '1963-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'ISETTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1983-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'M1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'X3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'X5' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-06-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'Z1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'Z3 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'Z3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'Z4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-06-01',
"valjalaske_lopp" = '2003-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BMW' )
AND "mudel" = 'Z8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BOND' )
AND "mudel" = 'EQUIPE Mk. II cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BOND' )
AND "mudel" = 'EQUIPE Mk. II coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BOND' )
AND "mudel" = 'EQUIPE coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1954-06-01',
"valjalaske_lopp" = '1962-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BORGWARD' )
AND "mudel" = 'ISABELLA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BRISTOL' )
AND "mudel" = '411' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BUGATTI' )
AND "mudel" = 'EB 110' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BUGATTI' )
AND "mudel" = 'EB 16.4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-06-01',
"valjalaske_lopp" = '1979-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BUICK' )
AND "mudel" = 'CENTURY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BUICK' )
AND "mudel" = 'LE SABRE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BUICK' )
AND "mudel" = 'PARK AVENUE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-04-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='BUICK' )
AND "mudel" = 'SKYLARK' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'CTS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'ELDORADO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'ESCALADE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'EVOQ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'SEVILLE II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'SEVILLE Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'SEVILLE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CADILLAC' )
AND "mudel" = 'XLR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CALLAWAY' )
AND "mudel" = 'C12 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CALLAWAY' )
AND "mudel" = 'C12 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CARBODIES' )
AND "mudel" = 'FL2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CARBODIES' )
AND "mudel" = 'FX FAIRWAY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CARBODIES' )
AND "mudel" = 'FX4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CARBODIES' )
AND "mudel" = 'FX4R' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CARBODIES' )
AND "mudel" = 'FX4S' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CARBODIES' )
AND "mudel" = 'TX1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CATERHAM' )
AND "mudel" = '21' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CATERHAM' )
AND "mudel" = 'SUPER SEVEN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHECKER' )
AND "mudel" = 'MARATHON Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHECKER' )
AND "mudel" = 'MARATHON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHECKER' )
AND "mudel" = 'TAXICAB' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'ALERO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'BERETTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'BLAZER ''94' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-09-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'BLAZER S ''82' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAMARO ''70' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAMARO ''81' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAMARO ґ92' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAMARO ґ98 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAMARO ґ98' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1983-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAPRICE ''70' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1990-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CAPRICE ''83' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CORSICA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1997-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CORVETTE ''83' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CORVETTE (C06)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = '2004-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CORVETTE ґ97 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2004-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'CORVETTE ґ97' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'IMPALA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-08-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'LUMINA APV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'MALIBU ''69' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'MONTE CARLO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'TAHOE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'TRAILBLAZER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHEVROLET' )
AND "mudel" = 'TRANS SPORT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = '300 C' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = '300 M (LR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'CROSSFIRE Roadster' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'CROSSFIRE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1992-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'GS DAYTONA SHELBY coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'LE BARON cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'LE BARON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-05-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'NEON (PL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'NEON II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'NEON Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'NEW YORKER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'PT CRUISER cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'PT CRUISER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'SARATOGA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'SEBRING (JR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'SEBRING cabrio (JR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = '2001-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'STRATUS (JA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = '2001-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'STRATUS cabrio (JX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VIPER Convertible' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VIPER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VISION' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-08-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VOYAGER I (ES)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VOYAGER II (GS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VOYAGER III (RG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VOYAGER Mk II (GS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VOYAGER Mk III (RG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-08-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CHRYSLER' )
AND "mudel" = 'VOYAGER (ES)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-03-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = '2 CV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-08-01',
"valjalaske_lopp" = '1988-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'ACADIANE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-05-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'AMI Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'AMI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-07-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'AX (ZA-_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1991-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'AXEL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'BERLINGO (MF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'BERLINGO truck (M_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'BX (XB-_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-04-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'BX Break (XB-_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C15 (VD-_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-07-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C25 c бортовой платформой/ходовая часть (280_, 290_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-07-01',
"valjalaske_lopp" = '1994-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C25 bus (280_, 290_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-07-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C25 truck (280_, 290_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C3 Pluriel' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-11-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C35 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-11-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C35 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C5 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C5' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'C8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX I Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-09-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX II Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-09-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'CX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DISPATCH (U6U)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DISPATCH c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DISPATCH truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DS Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1956-08-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DS cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-05-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'DYANE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2002-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'EVASION (22, U6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-07-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'GS Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-09-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'GS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-11-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'HY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'ID Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1956-03-01',
"valjalaske_lopp" = '1965-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'ID cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-08-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'ID' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPER c бортовой платформой/ходовая часть (230)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPER c бортовой платформой/ходовая часть (244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-02-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPER bus (230P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPER bus (244, Z_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-02-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPER truck (230L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPER truck (244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPY (U6U)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPY c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'JUMPY truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-11-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'LNA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-05-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'MEHARI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1991-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'OLTCIT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'RELAY c бортовой платформой/ходовая часть (230)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-02-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'RELAY bus (230P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-02-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'RELAY truck (230L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'SAXO (S0, S1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-04-01',
"valjalaske_lopp" = '1974-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'SM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2002-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'SYNERGIE (22, U6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1988-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'VISA cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-09-01',
"valjalaske_lopp" = '1991-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'VISA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1998-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XANTIA (X1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XANTIA (X2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-06-01',
"valjalaske_lopp" = '1998-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XANTIA Break (X1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XANTIA Break (X2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XM (Y3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-05-01',
"valjalaske_lopp" = '2000-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XM (Y4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-11-01',
"valjalaske_lopp" = '1994-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XM Break (Y3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-05-01',
"valjalaske_lopp" = '2000-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XM Break (Y4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XSARA (N1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XSARA Break (N2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XSARA PICASSO (N68)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'XSARA coupe (N0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-03-01',
"valjalaske_lopp" = '1997-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'ZX (N2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-10-01',
"valjalaske_lopp" = '1997-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='CITROEN' )
AND "mudel" = 'ZX Break (N2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-12-01',
"valjalaske_lopp" = '1983-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DACIA' )
AND "mudel" = '1300 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-12-01',
"valjalaske_lopp" = '1983-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DACIA' )
AND "mudel" = '1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DACIA' )
AND "mudel" = '1310 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DACIA' )
AND "mudel" = '1310' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'ESPERO (KLEJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'EVANDA (KLAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'KALOS (KLAS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'KORANDO (KJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'KORANDO Cabrio (KJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'LACETTI (KLAN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'LANOS (KLAT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'LANOS sedan (KLAT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = '2002-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'LEGANZA (KLAV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'LUBLIN II c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'LUBLIN II truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'MATIZ (KLYA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'MUSSO (FJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-02-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NEXIA (KLETN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-02-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NEXIA sedan (KLETN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NUBIRA (KLAJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NUBIRA Break (KLAJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NUBIRA Wagon (KLAJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NUBIRA sedan (KLAJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'NUBIRA sedan (KLAN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'REXTON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'REZZO (KLAU)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'TACUMA (KLAU)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAEWOO' )
AND "mudel" = 'TICO (KLY3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '33' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-04-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '400-Serie truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1974-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '44 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-11-01',
"valjalaske_lopp" = '1974-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '44' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-09-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '46 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-09-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '46' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-05-01',
"valjalaske_lopp" = '1972-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '55 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1972-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '55 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1972-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '55' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-09-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '66 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-10-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '66 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-10-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAF' )
AND "mudel" = '66' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1997-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'APPLAUSE I (A101, A111)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'APPLAUSE II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'APPLAUSE Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1997-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'APPLAUSE (A101, A111)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'Atrai bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-10-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE I (G10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE II (G11, G30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE III (G100, G101, G102)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE III sedan (G102)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE IV (G200, G202)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE IV sedan (G203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE Mk II (G11, G30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE Mk III (G100, G101, G102)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE Mk IV (G200, G202)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE Mk IV sedan (G203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-10-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARADE (G10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1987-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CHARMANT (A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'COPEN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1985-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE I (L55, L60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE II (L80, L81)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE III (L201)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE IV (L501)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = '2003-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE Mk VI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-11-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE V (L5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = '2003-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE VI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'CUORE VII' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'EXTOL bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'FEROZA Hard Top (F300)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'FEROZA Soft Top (F300)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'FOURTRAK (F7, F8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'GRAN MOVE (G3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET I bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET I truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET II bus (S85)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET II truck (S85)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET Mk II bus (S85)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET Mk II truck (S85)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'HIJET truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'MIRA Mk II (L80, L81)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'MIRA Mk III (L201)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1985-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'MIRA (L55, L60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'MOVE (L6, L9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'ROCKY Hard Top (F7, F8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'ROCKY Soft Top (F7, F8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'SIRION (M1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1986-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'SPARCAR bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1986-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'SPARCAR truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'SPORTRAK (F300)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-09-01',
"valjalaske_lopp" = '1985-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'TAFT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'TERIOS (J1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'VALERA IV sedan (G203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-02-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'WILDCAT/ROCKY (F70)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-02-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'WILDCAT/ROCKY (F75)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIHATSU' )
AND "mudel" = 'YRV (M2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIMLER' )
AND "mudel" = '2.8 - 5.3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-09-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIMLER' )
AND "mudel" = 'COUPE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIMLER' )
AND "mudel" = 'DAIMLER (X300)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-03-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIMLER' )
AND "mudel" = 'LANDAULETTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-06-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIMLER' )
AND "mudel" = 'LIMOUSINE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DAIMLER' )
AND "mudel" = 'XJ 40, 81' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DALLAS' )
AND "mudel" = 'FUN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE LOREAN' )
AND "mudel" = 'DMC-12' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'BIGUA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'DEAUVILLE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'GUARA Barchetta' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'GUARA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'LONGCHAMP cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'LONGCHAMP' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DE TOMASO' )
AND "mudel" = 'PANTERA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DODGE' )
AND "mudel" = 'CARAVAN II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DODGE' )
AND "mudel" = 'CARAVAN III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DODGE' )
AND "mudel" = 'NEON II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-05-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DODGE' )
AND "mudel" = 'NEON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = '2001-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DODGE' )
AND "mudel" = 'STRATUS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='DODGE' )
AND "mudel" = 'VIPER cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1989-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '208/308' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1989-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '328 GTB' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1989-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '328 GTS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-02-01',
"valjalaske_lopp" = '1994-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '348 TB' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '348 TS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '360 MODENA (F131)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '360 MODENA Spider (F131)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-06-01',
"valjalaske_lopp" = '1971-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '365 GT 2+2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-02-01',
"valjalaske_lopp" = '1974-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '365 GTB/4 DAYTONA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-02-01',
"valjalaske_lopp" = '1974-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '365 GTS/4 DAYTONA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1985-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '400 i' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-04-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '412 i' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '456 GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-08-01',
"valjalaske_lopp" = '1984-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '512 BB' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-11-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '512 M' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '512 TR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '550 BARCHETTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '5__ MARANELLO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = '612 SCAGLIETTI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-02-01',
"valjalaske_lopp" = '1973-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'DINO GT (206/246)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-02-01',
"valjalaske_lopp" = '1980-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'DINO GT4 (208/308)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-04-01',
"valjalaske_lopp" = '1973-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'DINO GTS (206/246)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'ENZO FERRARI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-05-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'F355 BERLINETTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'F355 GTS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'F40' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-03-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'MONDIAL cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'MONDIAL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-05-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FERRARI' )
AND "mudel" = 'TESTAROSSA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-07-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '1000er-Serie' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-04-01',
"valjalaske_lopp" = '1975-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '124 Familiare' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1985-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '124 Spider' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-06-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '124 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-07-01',
"valjalaske_lopp" = '1975-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '124' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '125' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-09-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '126' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '127 Panorama' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-06-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '127' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '128 Familiare' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-03-01',
"valjalaske_lopp" = '1981-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '128 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-03-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '128' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-10-01',
"valjalaske_lopp" = '1978-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '130 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-06-01',
"valjalaske_lopp" = '1978-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '130' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '131 Familiare/Panorama' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-10-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '131' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-04-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '132' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1972-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '135 DINO Spider' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-10-01',
"valjalaske_lopp" = '1974-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '135 DINO coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-04-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '147 Panorama' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-10-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '147' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-06-01',
"valjalaske_lopp" = '1967-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '1500 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-07-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '1500-2300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-09-01',
"valjalaske_lopp" = '1982-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '238-SERIE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '242-SERIE bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1982-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '242-SERIE truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-05-01',
"valjalaske_lopp" = '1966-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '500 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-01-01',
"valjalaske_lopp" = '1976-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-03-01',
"valjalaske_lopp" = '1971-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '850 Spider' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-07-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '850 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-07-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '850' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1986-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '900 T/E Panorama' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1986-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = '900 T/E Pulmino' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-05-01',
"valjalaske_lopp" = '1987-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'ARGENTA (132A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'BARCHETTA (183)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'BRAVA (182)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'BRAVO (182)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-06-01',
"valjalaske_lopp" = '1989-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'CAMPAGNOLA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = '1998-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'CINQUECENTO (170)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'COUPE (FA/175)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-12-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'CROMA (154)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DOBLO (223)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DOBLO Cargo (223)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-07-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO Panorama (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO Panorama (290)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO c бортовой платформой/ходовая часть (230)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO c бортовой платформой/ходовая часть (244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-07-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO c бортовой платформой/ходовая часть (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO c бортовой платформой/ходовая часть (290)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO bus (230)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO bus (244, Z_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO truck (230L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO truck (244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO truck (280)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUCATO truck (290)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUNA (146 B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'DUNA Weekend (146 B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-04-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'ELBA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-10-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'FIORINO (127)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1988-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'FIORINO (147)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'FIORINO Pick up (146)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'FIORINO Pick up (147)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'FIORINO truck (146 Uno)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'IDEA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1971-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'JAGST' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'MAREA (185)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'MAREA Weekend (185)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'MULTIPLA (186)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PALIO (178BX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PALIO Weekend (178DX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PANDA (141A_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PANDA Van' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PANDA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-03-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PREMIO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PUNTO (176)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PUNTO (188)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = '2000-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PUNTO Van (176L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PUNTO Van (188AX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-04-01',
"valjalaske_lopp" = '2000-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'PUNTO cabrio (176C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'REGATA (138)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'REGATA Weekend' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1989-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'RITMO Bertone cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1987-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'RITMO I (138A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'RITMO II (138A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'RITMO Mk II (138A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1987-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'RITMO (138A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'SCUDO Combinato (220P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'SCUDO truck (220L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'SEICENTO (187)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'SEICENTO Van (187)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'SIENA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-10-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'SPAZIO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'STILO (192)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'STILO Multi Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'STRADA (178E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TALENTO c бортовой платформой/ходовая часть (290)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TALENTO bus (290)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TALENTO truck (290)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-03-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TEMPRA (159)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-03-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TEMPRA S.W. (159)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-03-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TEMPRA SW (159)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-07-01',
"valjalaske_lopp" = '1995-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'TIPO (160)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'ULYSSE (179AX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2002-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'ULYSSE (220)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'UNO (146A/E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-11-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FIAT' )
AND "mudel" = 'X 1/9 (128 AS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-03-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'AEROSTAR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'BRONCO II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'BRONCO Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'EXPLORER (U2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'MUSTANG Convertible' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'MUSTANG' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1993-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'PROBE I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'PROBE II (ECP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'PROBE Mk II (ECP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1993-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'PROBE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'TAURUS Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'TAURUS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD USA' )
AND "mudel" = 'WINDSTAR (A3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-12-01',
"valjalaske_lopp" = '1974-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CAPRI (ECJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-02-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CAPRI II (GECP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CAPRI III (GECP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-02-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CAPRI Mk II (GECP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CAPRI Mk III (GECP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CONSUL (GGFL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CONSUL Turnier (GGNL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CONSUL coupe (GGCL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1971-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORSAIR Estate universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1971-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORSAIR Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-10-01',
"valjalaske_lopp" = '1971-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORSAIR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-07-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA ''80 (GBS, GBNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA (GBFK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA (GBTK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-05-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA (GBTS, GBFS, CBTS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Coach coupe (GBCK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Coach' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-07-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Estate ''80 universal (GBNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Estate universal (GBNK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-05-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Estate universal (GBNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Estate universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'CORTINA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'COUGAR (EC_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-03-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ECONOVAN (KBA, KCA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-05-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ECONOVAN truck (KAA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1986-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''81 Courrier (AVA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1986-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''81 Express (AVA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-02-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''86 Courrier (AVF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-02-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''86 Express (AVF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''91 Courrier (AVL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''91 Express (AVL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT ''95 truck (AVL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = '2000-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT CLASSIC (AAL, ABL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = '2000-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT CLASSIC Turnier (ANL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT I (AFH, ATH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-06-01',
"valjalaske_lopp" = '1979-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT I Break (ADH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-06-01',
"valjalaske_lopp" = '1979-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT I Turnier (ADH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-03-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT II (ATH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT II Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT II Turnier' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT III (GAA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT III Break (AWA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT III Turnier (AWA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT III cabrio (ALD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT IV (GAF, AWF, ABFT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT IV Break (AWF, AVF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT IV Turnier (AWF, AVF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT IV cabrio (ALF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-03-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk II (ATH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk III (GAA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk III cabrio (ALD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk III universal (AWA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk IV (GAF, AWF, ABFT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk IV cabrio (ALF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk IV universal (AWF, AVF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk V (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk V cabrio (ALL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk V universal (GAL, AVL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VI (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VI cabrio (ALL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-08-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VI sedan (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VI universal (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VII (GAL, AAL, ABL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-02-01',
"valjalaske_lopp" = '2000-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VII cabrio (ALL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VII sedan (GAL, AFL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT Mk VII universal (GAL, ANL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT V (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT V Break (GAL, AVL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT V Turnier (GAL, AVL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT V cabrio (ALL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VI (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VI Break (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VI Turnier (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VI cabrio (ALL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-08-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VI sedan (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VII (GAL, AAL, ABL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VII Clipper (GAL, ANL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VII Turnier (GAL, ANL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-02-01',
"valjalaske_lopp" = '2000-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VII cabrio (ALL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT VII sedan (GAL, AFL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT (AFH, ATH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-06-01',
"valjalaske_lopp" = '1979-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ESCORT universal (ADH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA Courier (F3L, F5L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA Courier (J5_, J3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1986-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1989-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA II (FBD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA III (GFJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-08-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA IV (JA_, JB_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1989-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA Mk II (FBD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA Mk III (GFJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-08-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA Mk IV (JA_, JB_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA V (JH_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA truck (F3L, F5L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA truck (FVD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA truck (J5_, J3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA truck (JV_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1986-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA truck (WFVT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1986-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FIESTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FOCUS (DAW, DBW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FOCUS C-MAX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FOCUS Clipper (DNW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FOCUS Turnier (DNW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FOCUS sedan (DFW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'FUSION (JU_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GALAXY (VX, VY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA (GGTL, GGFL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA (GU)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Break (GGNL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Break (GNU)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-05-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA I universal (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Mk III sedan (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-04-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Mk III (GAE, GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Mk III sedan (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-05-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Mk III universal (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Turnier (GGNL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA Turnier (GNU)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GRANADA coupe (GGCL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'KA (RB_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = '1998-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MAVERICK (UDS, UNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MAVERICK' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO I (GBP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO I Clipper (BNP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO I Turnier (BNP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO I sedan (GBP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO II (BAP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO II Clipper (BNP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO II Turnier (BNP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO II sedan (BFP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO III (B5Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO III Clipper (BWY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO III Turnier (BWY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO III sedan (B4Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO Mk II (BAP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO Mk II sedan (BFP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO Mk II universal (BNP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO Mk III (B5Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO Mk III sedan (B4Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO Mk III universal (BWY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO (GBP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO sedan (GBP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'MONDEO universal (BNP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-07-01',
"valjalaske_lopp" = '1986-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ORION I (AFD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-12-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ORION II (AFF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ORION III (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-12-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ORION Mk II (AFF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ORION Mk III (GAL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-07-01',
"valjalaske_lopp" = '1986-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ORION (AFD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-04-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'P 100 I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'P 100 II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'P 100 Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-04-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'P 100' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'PUMA (EC_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'RANGER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-04-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO I (GAE, GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-05-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO I Break (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-05-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO I Turnier (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO I sedan (GGE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO II (GFR, GGR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO II Break (GNR, GGR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO II Turnier (GNR, GGR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO Mk II (GFR, GGR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SCORPIO Mk II universal (GNR, GGR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA (GBG, GB4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA Break (BNC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA Turnier (BNC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA Turnier (BNG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA hatchback (GBC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA hatchback (GBC, GBG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'SIERRA universal (BNG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'STREET KA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1951-01-01',
"valjalaske_lopp" = '1953-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS ''51' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-07-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS ''80 (GBS, GBNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS (GBFK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS (GBTK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-05-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS (GBTS, GBFS, CBTS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M (11G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M (12G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-07-01',
"valjalaske_lopp" = '1967-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M (P4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-09-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M Turnier (15G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-04-01',
"valjalaske_lopp" = '1967-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M Turnier (P4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-05-01',
"valjalaske_lopp" = '1963-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M Turnier' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M coupe (13G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-12-01',
"valjalaske_lopp" = '1967-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M coupe (P4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1951-12-01',
"valjalaske_lopp" = '1963-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 12M' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M (21G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M (22G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M (28G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M (29G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-09-01',
"valjalaske_lopp" = '1971-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M Turnier (25G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M coupe (23G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1954-12-01',
"valjalaske_lopp" = '1958-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 15M' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-09-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M (21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M (31F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M (32F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-09-01',
"valjalaske_lopp" = '1965-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M (P3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-11-01',
"valjalaske_lopp" = '1967-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M Turnier (21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-09-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M Turnier (35F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-09-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M Turnier (36F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-12-01',
"valjalaske_lopp" = '1965-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M Turnier (P3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-08-01',
"valjalaske_lopp" = '1960-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M Turnier' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M coupe (33F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-11-01',
"valjalaske_lopp" = '1965-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M coupe (P3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-08-01',
"valjalaske_lopp" = '1960-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 17M' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M (41F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M (42F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M Turnier (46F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-11-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M Turnier' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M XL (51F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M XL (52F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M XL coupe (53F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M coupe (43F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-11-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 20M' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 26M XL (52F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1974-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS 26M XL coupe (53F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS Turnier (GBNK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-05-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS Turnier (GBNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS coupe (GBCK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-07-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TAUNUS ґ80 Turnier (GBNS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TOURNEO CONNECT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-04-01',
"valjalaske_lopp" = '1967-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT ''55- bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-04-01',
"valjalaske_lopp" = '1967-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT ''55- truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT CONNECT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-12-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT c бортовой платформой/ходовая часть (74E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT c бортовой платформой/ходовая часть (E_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT c бортовой платформой/ходовая часть (E_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT c бортовой платформой/ходовая часть (FM_Y, FN_Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1992-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT c бортовой платформой/ходовая часть (T_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-11-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT c бортовой платформой/ходовая часть (V_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-11-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT bus (72E, 73E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT bus (E_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2000-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT bus (E_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT bus (FD_Y, FB_Y, FS_Y, FZ_Y, FC_Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1992-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT bus (T_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-11-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT bus (V_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-11-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (72E, 71E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-11-01',
"valjalaske_lopp" = '1973-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (81E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-05-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (E_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (E_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (FA_Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1992-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (T_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'TRANSIT truck (V_ _)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-03-01',
"valjalaske_lopp" = '1968-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR III Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-03-01',
"valjalaske_lopp" = '1968-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR IV Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-03-01',
"valjalaske_lopp" = '1968-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR Mk III universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-03-01',
"valjalaske_lopp" = '1968-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZEPHYR Mk IV universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-03-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZODIAC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-03-01',
"valjalaske_lopp" = '1970-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FORD' )
AND "mudel" = 'ZODIAK Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = '125P universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = '125P' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-07-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = '126P' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1976-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = '127P' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-01-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = '132P' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'ATOU III sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'CARO III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-10-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ III sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ Mk III sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-10-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'POLONEZ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='FSO' )
AND "mudel" = 'PRIMA II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'METRO cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'METRO sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'METRO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1991-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'STORM Kombi Coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-04-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'STORM Kombi Coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1991-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'STORM hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-04-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'STORM hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1991-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'STORM coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-04-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'STORM coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'TRACKER Cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GEO' )
AND "mudel" = 'TRACKER Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G15' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1979-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G21' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G23' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G27' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G32' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G33' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G34' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GINETTA' )
AND "mudel" = 'G40' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-05-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = '04 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = '04' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-02-01',
"valjalaske_lopp" = '1969-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = '1700' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-02-01',
"valjalaske_lopp" = '1969-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = 'GOGGOMOBIL coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1954-01-01',
"valjalaske_lopp" = '1969-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = 'GOGGOMOBIL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-01-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = 'GT cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = 'ISAR universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-08-01',
"valjalaske_lopp" = '1967-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = 'ISAR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='GLAS' )
AND "mudel" = 'V 8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HINDUSTAN' )
AND "mudel" = 'AMBASSADOR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HINDUSTAN' )
AND "mudel" = 'CONTESSA CLASSIC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HOBBYCAR' )
AND "mudel" = 'PASSPORT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HOLDEN' )
AND "mudel" = 'STATESMANN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HOLDEN' )
AND "mudel" = 'VT Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HOLDEN' )
AND "mudel" = 'VT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD I (SJ, SY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD I Hatchback (SJ, SY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1985-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD II (AC, AD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1985-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD II Hatchback (AC, AD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD III (CA4, CA5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD III Aerodeck (CA5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD IV (CB3, CB7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD IV Aerodeck (CB8, CC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD IV coupe (CC1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD MK V coupe (CD7, CD9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1985-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk II (AC, AD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1985-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk II hatchback (AC, AD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk III (CA4, CA5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk III universal (CA5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk IV (CB3, CB7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk IV coupe (CC1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk IV universal (CB8, CC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk V (CC7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk V universal (CE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk VI (CE, CF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk VII (CG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk VII hatchback (CH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk VII coupe (CG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD Mk VII universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD V (CC7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD V Aerodeck (CE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD V coupe (CD7, CD9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VI (CE, CF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VII (CG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VII Aerodeck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VII Hatchback (CH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VII coupe (CG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VIII Tourer' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD VIII' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD (SJ, SY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACCORD hatchback (SJ, SY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = '1986-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'ACTY TN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-10-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'BALLADE I (SL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CAPA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-10-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC I (SL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC I Break (WC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-07-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC I Hatchback (SB, SS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC I Shuttle (AN, AR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC I Wagon (WC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC II Hatchback (AL, AJ, AG, AH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1995-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC II Shuttle (EE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC III Hatchback (EC, ED, EE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC III sedan (ED)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC IV (EG, EH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '1997-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC IV Fastback (MA, MB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC IV Hatchback (EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC IV coupe (EJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk II (AL, AJ, AG, AH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1995-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk II universal (EE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk III hatchback (EC, ED, EE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk III sedan (ED)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk IV (EG, EH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk IV hatchback (EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '1997-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk IV hatchback (MA, MB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk IV coupe (EJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk V (EJ9, EK3/4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk V hatchback (EJ9, EK1/3/4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk V hatchback (MB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC Mk V universal (MC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC V (EJ9, EK3/4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC V Aerodeck (MC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC V Fastback (MB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC V Hatchback (EJ9, EK1/3/4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC V coupe (EJ6, EJ8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC VI Hatchback (EU_, EP_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC VI coupe (EM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC VI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-10-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC (SL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-07-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC hatchback (SB, SS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC universal (AN, AR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CIVIC universal (WC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-08-01',
"valjalaske_lopp" = '1995-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CONCERTO (HW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-08-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CONCERTO sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CR-V I (RD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CR-V II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CR-V Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CRX I (AF, AS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1992-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CRX II (ED, EE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CRX III (EH, EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1992-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CRX Mk II (ED, EE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CRX Mk III (EH, EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'CRX (AF, AS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'HR-V (GH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'INSIGHT (ZE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1989-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'INTEGRA (DA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-11-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'INTEGRA (DC2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'INTEGRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'JAZZ (AA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'JAZZ (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND I (HS, KA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND I coupe (KA3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND II (KA7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND II coupe (KA8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND III (KA9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND Mk II (KA7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND Mk II coupe (KA8)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND Mk III (KA9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND (HS, KA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LEGEND coupe (KA3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = '2002-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'LOGO (GA3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-06-01',
"valjalaske_lopp" = '1974-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'N III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'NSX cabrio (NA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'NSX coupe (NA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-11-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE I coupe (SN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE II (AB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-04-01',
"valjalaske_lopp" = '1992-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE III (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-02-01',
"valjalaske_lopp" = '1996-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE IV (BB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE Mk II (AB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-04-01',
"valjalaske_lopp" = '1992-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE Mk III (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-02-01',
"valjalaske_lopp" = '1996-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE Mk IV (BB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE Mk V (BB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE V (BB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-11-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'PRELUDE coupe (SN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-02-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'QUINTET (SU)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'S2000 (AP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2001-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'SHUTTLE (RA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HONDA' )
AND "mudel" = 'STREAM (RN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HUMMER' )
AND "mudel" = 'HUMMER H1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HUMMER' )
AND "mudel" = 'HUMMER H2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ACCENT (LC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ACCENT (X-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ACCENT sedan (LC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ACCENT sedan (X-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ATOS (MX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ATOS PRIME (MX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'COUPE (GK)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'COUPE (RD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ELANTRA (XD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ELANTRA I (J-1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ELANTRA II (J-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ELANTRA II universal (J2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'ELANTRA sedan (XD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'EXCEL (LC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'EXCEL (X-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'EXCEL sedan (X-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'EXCEL sedan (X-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'GALLOPER I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'GALLOPER II (JK-01)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'GETZ (TB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H 150 bus (P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H 150 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H 200 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H 200 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H-1 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H-1 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H100 bus (P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'H100 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'HIGHWAY VAN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA I (J-1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA II (J-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA II Break (J2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA II Wagon (J2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA Mk II (J-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA Mk II universal (J2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'LANTRA (J-1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'MATRIX (FC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-10-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY (X-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY (X-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1986-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY sedan (X-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1989-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY/EXCEL sedan (X-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-06-01',
"valjalaske_lopp" = '1986-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1989-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'PONY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-02-01',
"valjalaske_lopp" = '1996-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'S COUPE (SLC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SANTA FЙ (SM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SANTAMO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SATELLITE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1993-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA I (Y-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-05-01',
"valjalaske_lopp" = '1998-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA II (Y-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA III (EF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA MK IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-05-01',
"valjalaske_lopp" = '1998-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA Mk II (Y-3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA Mk III (EF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1993-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'SONATA (Y-2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'STAREX (H1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'STELLAR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'TERRACAN (HP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'TRAJET (FO)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='HYUNDAI' )
AND "mudel" = 'XG' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INDIGO' )
AND "mudel" = '3000 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'G20' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'I30' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'J30' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'M30 Convertible' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'M30 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'Q45' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INFINITI' )
AND "mudel" = 'QX4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INNOCENTI' )
AND "mudel" = 'ELBA (146)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INNOCENTI' )
AND "mudel" = 'KORAL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='INNOCENTI' )
AND "mudel" = 'MINI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='IRMSCHER' )
AND "mudel" = 'COUPE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='IRMSCHER' )
AND "mudel" = 'GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='IRMSCHER' )
AND "mudel" = 'OMEGA Caravan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='IRMSCHER' )
AND "mudel" = 'SENATOR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISDERA' )
AND "mudel" = 'COMMENDATORE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISDERA' )
AND "mudel" = 'IMPERATOR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISH' )
AND "mudel" = 'ORBITA (2126)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISH' )
AND "mudel" = 'ORBITA universal (21262)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-04-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'CAMPO (KB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-04-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'FASTER (KB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'GEMINI (JT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'GEMINI sedan (JT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'MIDI Van (94000, 98000)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'MIDI bus (94000, 98000)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'MIDI truck (98000N)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-06-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'PIAZZA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'TROOPER (UB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'TROOPER (UBS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'TROOPER Джип открытый (UB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'TROOPER Джип открытый (UBS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'TROOPER Джип открытый' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ISUZU' )
AND "mudel" = 'TROOPER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-06-01',
"valjalaske_lopp" = '1975-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'E-TYPE 2+2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-04-01',
"valjalaske_lopp" = '1975-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'E-TYPE Convertible' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-04-01',
"valjalaske_lopp" = '1975-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'E-TYPE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'S-TYPE (CCX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'X-TYPE (CF1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'X-TYPE Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-07-01',
"valjalaske_lopp" = '2003-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJ (NAW, NBW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-11-01',
"valjalaske_lopp" = '1997-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJ (X300)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1994-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJ (XJ 40, 81)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-07-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1996-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJS coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1996-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XJSC Convertible' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XK 8 Convertible (QDV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JAGUAR' )
AND "mudel" = 'XK 8 coupe (QEV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'CHEROKEE (KJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'CHEROKEE (XJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'CJ5 - CJ8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'GRAND CHEROKEE I (Z)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'GRAND CHEROKEE II (WJ, WG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'GRAND CHEROKEE Mk II (WJ, WG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'GRAND CHEROKEE (Z)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'LIBERTY (KJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'WRANGLER I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'WRANGLER II (TJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'WRANGLER Mk II (TJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JEEP' )
AND "mudel" = 'WRANGLER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-06-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'GT coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'HEALEY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'INTERCEPTOR MK III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'INTERCEPTOR Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'INTERCEPTOR S4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'INTERCEPTOR SP' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='JENSEN' )
AND "mudel" = 'S-V8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'BESTA truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = '2002-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CARENS I (FC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CARENS II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CARENS Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CARNIVAL (UP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CARNIVAL II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CERATO sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CERATO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CLARUS (K9A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'CLARUS universal (GC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'JOICE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'K2500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'MAGENTIS (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1997-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'MENTOR (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1997-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'MENTOR sedan (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'OPIRUS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'OPTIMA (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'PICANTO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'PREGIO (TB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'PRIDE (DA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'PRIDE universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'RETONA (CE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'RIO universal (DC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'RIO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'ROADSTER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SEDONA (UP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SEDONA Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '1997-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SEPHIA (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SEPHIA (FB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SEPHIA (FB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1997-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SEPHIA sedan (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SHUMA (FB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-05-01',
"valjalaske_lopp" = '2004-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SHUMA II (FB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-05-01',
"valjalaske_lopp" = '2004-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SHUMA II sedan (FB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SHUMA sedan (FB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SORENTO (JC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='KIA' )
AND "mudel" = 'SPORTAGE (K00)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = '110' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = '111' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = '112' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-09-01',
"valjalaske_lopp" = '1985-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = '1200-1500 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = '1200-1600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'DIVA (21099)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'KALINKA (2105, 2108, 2109)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'KALINKA universal (2104)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'NADESCHDA (2120)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'NIVA (2121)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'NOVA (2105, 2108, 2109)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'NOVA universal (2104)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'SAGONA (21099)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'SAMARA (2108, 2109)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'SAMARA FORMA (21099)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LADA' )
AND "mudel" = 'TOSCANA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'COUNTACH' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'DIABLO Roadster' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'DIABLO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'ESPADA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'GALLARDO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'JALPA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'JARAMA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'LM-001' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'LM-002' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'MIURA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'MURCIЙLAGO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAMBORGHINI' )
AND "mudel" = 'URRACO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-03-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'A 112' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1984-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'BETA H.P.E. (828BF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-08-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'BETA (828_B_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1981-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'BETA MONTE CARLO (137AS, 137BS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'BETA Spider (828BS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-04-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'BETA coupe (828BC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1999-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'DEDRA (835)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1999-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'DEDRA SW (835)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'DELTA I (831AB0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'DELTA II (836)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'DELTA Mk II (836)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'DELTA (831AB0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-09-01',
"valjalaske_lopp" = '1975-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'FULVIA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1984-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'GAMMA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'GAMMA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'KAPPA (838A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'KAPPA SW (838B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'KAPPA coupe (838)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'LYBRA (839AX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'LYBRA SW (839BX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'PHEDRA (179)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1992-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'PRISMA (831AB0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'THEMA (834)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-03-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'THEMA SW (834)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'THESIS (841AX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-05-01',
"valjalaske_lopp" = '1987-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'TREVI (828DB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'Y (840A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-03-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'Y10 (156)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'YPSILON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-05-01',
"valjalaske_lopp" = '2002-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LANCIA' )
AND "mudel" = 'ZETA (220)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-09-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = '88/109 Hardtop' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-09-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = '88/109' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-09-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = '90/110' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DEFENDER (LD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DEFENDER Station Wagon (LD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DEFENDER пикап' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DISCOVERY I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DISCOVERY II (LJ, LT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DISCOVERY Mk II (LJ, LT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'DISCOVERY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'FREELANDER (LN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'FREELANDER Soft Top' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-07-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'RANGE ROVER I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '2002-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'RANGE ROVER II (LP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'RANGE ROVER III (LM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'RANGE ROVER MK III (LM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '2002-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'RANGE ROVER Mk II (LP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-07-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LAND ROVER' )
AND "mudel" = 'RANGE ROVER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = '400 c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = '400 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = '400 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = 'CONVOY c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = 'CONVOY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-03-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = 'SHERPA bus (AS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1988-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LDV INTERNATIONAL' )
AND "mudel" = 'SHERPA bus (FR)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'ES (F1, F2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'GS (JZS147)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'GS (JZS160)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'IS (GXE10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'IS SportCross' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'LS (FE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-10-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'LS (UCF10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'LS (UCF20)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-08-01',
"valjalaske_lopp" = '2003-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'RX (XU1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'RX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LEXUS' )
AND "mudel" = 'SC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LIGIER' )
AND "mudel" = 'AMBRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LIGIER' )
AND "mudel" = 'BE UP' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LIGIER' )
AND "mudel" = 'NOVA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LINCOLN' )
AND "mudel" = 'LS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ECLAT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ELAN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ELISE 340 R' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-08-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ELISE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ELISE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-05-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ELITE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ESPRIT S2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-05-01',
"valjalaske_lopp" = '1989-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ESPRIT S3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'ESPRIT S4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1970-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'EUROPA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-05-01',
"valjalaske_lopp" = '1976-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'EUROPA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'EXCEL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='LOTUS' )
AND "mudel" = 'EXIGE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAHINDRA' )
AND "mudel" = 'CJ 3 Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAHINDRA' )
AND "mudel" = 'CJ 3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = '1600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = '2-3 Litre' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = 'LM cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = 'LM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = 'MANTA RAY cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = 'MANTA RAY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = 'MANTIS cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARCOS' )
AND "mudel" = 'MANTIS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARUTI' )
AND "mudel" = '800' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = NULL,
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MARUTI' )
AND "mudel" = 'UDYOG' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-12-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = '228' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = '2002-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = '3200 GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-03-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = '420/430' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'BITURBO Spider' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'BITURBO coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-06-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'BITURBO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1980-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'BORA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'GHIBLI II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'GHIBLI Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'GHIBLI Spider' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'GHIBLI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'INDY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'KARIF' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'KHAMSIN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-04-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'KYALAMI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-05-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'MERAK' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'MEXICO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'QUATTROPORTE II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'QUATTROPORTE III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'QUATTROPORTE Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-08-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'QUATTROPORTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'SHAMAL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'SPYDER GT cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MASERATI' )
AND "mudel" = 'SPYDER coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAYBACH' )
AND "mudel" = 'MAYBACH (240_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = '1977-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '1000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '121 I (DA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-11-01',
"valjalaske_lopp" = '1996-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '121 II (DB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '121 III (JASM, JBSM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-11-01',
"valjalaske_lopp" = '1996-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '121 Mk II (DB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '121 Mk III (JASM, JBSM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-10-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '121 (DA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = '1977-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '3 sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 C IV (BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 C Mk IV (BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 C Mk V (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 C V (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 F IV (BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 F Mk IV (BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 F Mk V (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 F V (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 F VI (BJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 F/P Mk VI (BJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1980-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 I (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-05-01',
"valjalaske_lopp" = '1986-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 I Break (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-05-01',
"valjalaske_lopp" = '1986-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 I Station Wagon (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-11-01',
"valjalaske_lopp" = '1989-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 II (BD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-06-01',
"valjalaske_lopp" = '1989-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 II Hatchback (BD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 III (BF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-05-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 III Break (BW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1991-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 III Hatchback (BF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-05-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 III Station Wagon (BW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-11-01',
"valjalaske_lopp" = '1989-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 Mk II (BD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-06-01',
"valjalaske_lopp" = '1989-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 Mk II hatchback (BD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 Mk III (BF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1991-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 Mk III hatchback (BF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-05-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 Mk III universal (BW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 P Mk V' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 P Mk VI (BJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 P V' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 P VI (BJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 S IV (BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 S Mk IV (BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 S Mk V (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 S Mk VI (BJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 S V (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 S VI (BJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1980-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-05-01',
"valjalaske_lopp" = '1986-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '323 universal (FA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '6 (GG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '6 Hatchback (GG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '6 Station Wagon (GY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-05-01',
"valjalaske_lopp" = '1978-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '616' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 I (CB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-11-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 II (GC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-11-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 II Hatchback (GC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-07-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 III (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 III Break (GV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-06-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 III Hatchback (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 III Station Wagon (GV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-06-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 III coupe (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 IV (GE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 IV Hatchback (GE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-11-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk II (GC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-11-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk II hatchback (GC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-07-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk III (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-06-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk III hatchback (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-06-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk III coupe (GD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk III universal (GV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk IV (GE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk IV hatchback (GE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk V (GF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk V hatchback (GF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 Mk V universal (GW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 V (GF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 V Break (GW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 V Hatchback (GF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 V Station Wagon (GW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '626 (CB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-09-01',
"valjalaske_lopp" = '1978-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '818 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-09-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 I (LA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 II (HB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 II Break (HV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 II Station Wagon (HV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 II coupe (HB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-05-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 III (HC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 Mk II (HB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1987-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 Mk II coupe (HB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 Mk II universal (HV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-05-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 Mk III (HC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-09-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = '929 (LA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'ATENZA (GG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'ATENZA hatchback (GG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'ATENZA universal (GY)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-02-01',
"valjalaske_lopp" = '1982-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'B-SERIE (PE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'B-SERIE (UD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1999-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'B-SERIE (UF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'B-SERIE (UN)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'DEMIO (DW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1984-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'E 1600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1994-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'E 2000,2200 bus (SR1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'E 2000,2200 truck (SR2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'EUNOS 500 (CA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'EUNOS 800 (TA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MILLENIA (TA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-03-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MPV I (LV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MPV II (LW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MPV Mk II (LW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MX-3 (EC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1998-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MX-5 I (NA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MX-5 II (NB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MX-5 Mk II (NB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1998-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MX-5 (NA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'MX-6 (GE6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'PREMACY (CP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-06-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 5' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-03-01',
"valjalaske_lopp" = '1986-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 7 I (SA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 7 II (FC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 7 III (FD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-11-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 7 Mk II (FC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 7 Mk III (FD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-03-01',
"valjalaske_lopp" = '1986-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 7 (SA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'RX 8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'TRIBUTE (EP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'XEDOS 6 (CA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MAZDA' )
AND "mudel" = 'XEDOS 9 (TA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MCLAREN' )
AND "mudel" = 'F1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MCLAREN' )
AND "mudel" = 'LM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MEGA' )
AND "mudel" = 'CLUB II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1999-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MEGA' )
AND "mudel" = 'CLUB' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MEGA' )
AND "mudel" = 'MONTE CARLO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MEGA' )
AND "mudel" = 'TRACK' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '/8 (W114)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1977-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '/8 (W115)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-04-01',
"valjalaske_lopp" = '1977-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '/8 coupe (W114)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '100 c бортовой платформой/ходовая часть (631)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '100 bus (631)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '100 truck (631)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1946-06-01',
"valjalaske_lopp" = '1958-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '170 (W170)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = '190 (W201)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'A-CLASS (W168)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '2000-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS (W202)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS (W203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS Break (S202)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS Coupe Sport (CL203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS Sportcoupe (CL203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS Sportscoupe (CL203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS T-Model (S202)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS T-Model (S203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS coupe (CL203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS universal (S202)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'C-CLASS universal (S203)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1993-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CABRIOLET (A124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CABRIOLET (W111)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = '2002-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CLK (C208)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CLK (C209)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CLK cabrio (A208)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CLK cabrio (A209)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'CLS (C219)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-03-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'COUPE (C123)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-03-01',
"valjalaske_lopp" = '1993-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'COUPE (C124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'COUPE (W111)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1995-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS (W124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-06-01',
"valjalaske_lopp" = '2002-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS (W210)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS (W211)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS Break (S124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2003-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS Break (S210)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS T-Model (S124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2003-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS T-Model (S210)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS T-Model (S211)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-05-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS cabrio (A124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1997-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS coupe (C124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-06-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS universal (S124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2003-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS universal (S210)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'E-CLASS universal (S211)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'G-CLASS (W460)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'G-CLASS (W461)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'G-CLASS (W463)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'G-CLASS Cabrio (W463)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'G-CLASS Джип открытый (W463)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1954-09-01',
"valjalaske_lopp" = '1957-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'GULLWING (W198)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-08-01',
"valjalaske_lopp" = '1968-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'HECKFLOSSE (W110)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-08-01',
"valjalaske_lopp" = '1968-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'HECKFLOSSE (W111)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-02-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'HENSCHEL 2-t' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'KOMBI Break (S123)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'KOMBI Break (S124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-09-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'KOMBI T-Model (S123)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'KOMBI T-Model (S124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'M-CLASS (W163)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'PAGODE (W113)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-01-01',
"valjalaske_lopp" = '1962-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'PONTON (W120)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-06-01',
"valjalaske_lopp" = '1961-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'PONTON (W121)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-01-01',
"valjalaske_lopp" = '1959-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'PONTON (W128)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1954-01-01',
"valjalaske_lopp" = '1959-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'PONTON (W180)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-09-01',
"valjalaske_lopp" = '1979-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'PULLMANN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1972-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS (W108, W109)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-08-01',
"valjalaske_lopp" = '1980-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS (W116)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-10-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS (W126)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-02-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS (W140)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS (W220)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1991-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS coupe (C126)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS coupe (C140)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS coupe (C215)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1972-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'S-CLASS sedan (W108, W109)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-05-01',
"valjalaske_lopp" = '1989-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SL (R107)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SL (R129)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-05-01',
"valjalaske_lopp" = '1963-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SL (R198)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SL (R230)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-01-01',
"valjalaske_lopp" = '1963-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SL (W121)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1981-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SL coupe (C107)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SLK (R170)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SLK (R171)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SLR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 2-t c бортовой платформой/ходовая часть (901, 902)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 2-t bus (901, 902)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 2-t truck (901, 902)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 3-t c бортовой платформой/ходовая часть (903)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 3-t bus (903)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 3-t truck (903)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 4-t c бортовой платформой/ходовая часть (904)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 4-t bus (904)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'SPRINTER 4-t truck (904)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'T1 c бортовой платформой/ходовая часть (601)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-04-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'T1 c бортовой платформой/ходовая часть (602)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-05-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'T1 bus (601)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-04-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'T1 bus (602)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-05-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'T1 truck (601)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'T1 truck (602)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'V-CLASS (638/2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'VANEO (414)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'VIANO (W639)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'VITO bus (638)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'VITO bus (W639)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'VITO truck (638)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'VITO truck (W639)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'sedan (W123)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-12-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MERCEDES BENZ' )
AND "mudel" = 'sedan (W124)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-09-01',
"valjalaske_lopp" = '1970-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = '1300 Mk.II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MAESTRO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-03-01',
"valjalaske_lopp" = '1968-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MAGNETTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-05-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'METRO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MG ZR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MG ZS Hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MG ZS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MG ZT- T' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MG ZT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1980-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGB GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGB cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1969-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGC GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1969-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-03-01',
"valjalaske_lopp" = '2002-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGF (RD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGR V8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MGTF' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-01-01',
"valjalaske_lopp" = '1979-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MIDGET' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-04-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MG' )
AND "mudel" = 'MONTEGO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MIDDLEBRIDGE' )
AND "mudel" = 'SCIMITAR GTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MINI' )
AND "mudel" = 'MINI cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MINI' )
AND "mudel" = 'MINI-MOKE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MINI' )
AND "mudel" = 'MINI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = '3000 GT (Z16A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'CARISMA (DA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'CARISMA sedan (DA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1981-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'CELESTE (A7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'CHALLENGER (K90)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'CHARIOT (N3_W, N4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-12-01',
"valjalaske_lopp" = '1984-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT I (A15_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-02-01',
"valjalaske_lopp" = '1988-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT II (C1_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT III (C5_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1995-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT IV (CA_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1979-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT LANCER (A7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1979-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT LANCER Station Wagon (A7_K)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-02-01',
"valjalaske_lopp" = '1988-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT Mk II (C1_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1992-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT Mk III (C5_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1995-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT Mk IV (CA_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT Mk V (CJ_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT V (CJ_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT VI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-12-01',
"valjalaske_lopp" = '1984-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'COLT (A15_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'CORDIA (A21_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-04-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'ECLIPSE I (D2_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'ECLIPSE II (D3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'ECLIPSE Mk II (D3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-04-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'ECLIPSE (D2_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT I (A12_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT I Break (A12_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT I Station Wagon (A12_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1984-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT II (A16_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1984-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT II Break (A16_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1984-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT II Station Wagon (A16_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-06-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT III (E1_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-11-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT IV (E3_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-11-01',
"valjalaske_lopp" = '1992-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT IV sedan (E3_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1984-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk II (A16_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1984-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk II universal (A16_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-06-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk III (E1_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-11-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk IV (E3_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-11-01',
"valjalaske_lopp" = '1992-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk IV sedan (E3_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-11-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk V (E5_A, E7_A, E8_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-11-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk V sedan (E5_A, E7_A, E8_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk VI (EA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT Mk VI universal (EA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-11-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT V (E5_A, E7_A, E8_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-11-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT V sedan (E5_A, E7_A, E8_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT VI (EA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT VI universal (EA_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT (A12_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALANT universal (A12_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GALLOPER (JK-01)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'GRANDIS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'IO (H6_W, H7_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-11-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 200 (K__T)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 200 (K__T)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-05-01',
"valjalaske_lopp" = '1994-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 300 c бортовой платформой/ходовая часть (L03_P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 300 c бортовой платформой/ходовая часть (P1_T )' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-05-01',
"valjalaske_lopp" = '1987-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 300 bus (LO3_P/G, L0_2P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 300 bus (P0_W, P1_W, P2_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-05-01',
"valjalaske_lopp" = '1987-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 300 truck (L03_P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 300 truck (P0_W, P1_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 400 bus (PAOV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'L 400 truck (PAOV)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1984-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER F II (A17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1984-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER F Mk II (A17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER I (A17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1988-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER III (C1_A, C6_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER III Break (C1_V, C3_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER III Station Wagon (C1_V, C3_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1994-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER IV (C6_A, C7_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER IV sedan (C6_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Kombi' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1988-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk III (C1_A, C6_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk III universal (C1_V, C3_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1994-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk IV (C6_A, C7_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1992-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk IV sedan (C6_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-06-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk V (CB/D_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk V universal (CB_W, CD_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER Mk VI (CK/P_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-06-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER V (CB/D_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER V Break (CB_W, CD_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER V Station Wagon (CB_W, CD_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER VI (CK/P_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER (A17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'LANCER universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO III (V60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO SPORT (K90)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO iO (H6_W, H7_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO (L04_G, L14_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '2000-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO (V2_W, V4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO Джип открытый (L04_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '2000-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'MONTERO Джип открытый (V2_W, V4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'OUTLANDER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO CLASSIC (V2_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO I (L04_G, L14_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO I Джип открытый (L04_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '2000-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO II (V2_W, V4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '2000-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO II Джип открытый (V2_W, V4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO III (V60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO PININ (H6_W, H7_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PAJERO SPORT (K90)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'PROUDIA/DIGNITY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'RVR (N1_W, N2_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SANTAMO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = '1980-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SAPPORO I (A12_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1984-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SAPPORO II (A16_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-06-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SAPPORO III (E16A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1984-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SAPPORO Mk II (A16_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-06-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SAPPORO Mk III (E16A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = '1980-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SAPPORO (A12_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '2000-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SHOGUN Mk II (V2_W, V4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SHOGUN Mk II Джип открытый (L04_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SHOGUN Mk III (V60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SHOGUN PININ (H6_W, H7_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SHOGUN (L04_G, L14_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '2000-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SHOGUN Джип открытый (V2_W, V4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SIGMA (F16A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SIGMA Break (F07W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SIGMA Station Wagon (F07W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE GEAR (PA/B/D_V/W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE RUNNER (N1_W, N2_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE RUNNER (N50)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE STAR (DG0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1991-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE WAGON (D0_V/W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE WAGON (N3_W, N4_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'SPACE WAGON (N5_W)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-05-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'STARION (A18_A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-09-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MITSUBISHI' )
AND "mudel" = 'TREDIA (A21_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORGAN' )
AND "mudel" = 'AERO 8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORGAN' )
AND "mudel" = 'FOUR FOUR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORGAN' )
AND "mudel" = 'PLUS EIGHT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORGAN' )
AND "mudel" = 'PLUS FOUR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1984-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'ITAL Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1984-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'ITAL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-04-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA II Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-10-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA III universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-10-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-04-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-04-01',
"valjalaske_lopp" = '1980-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-04-01',
"valjalaske_lopp" = '1980-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MORRIS' )
AND "mudel" = 'MARINA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-07-01',
"valjalaske_lopp" = '1983-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '2140' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '21412' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '403' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '407' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '412' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '423 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = '427 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = 'ASLK 2137 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='MOSKVICH' )
AND "mudel" = 'ASLK 2140' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-03-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '100 NX (B13)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-07-01',
"valjalaske_lopp" = '1994-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '200 SX (S13)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '200 SX (S14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-07-01',
"valjalaske_lopp" = '1984-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '280 ZX,ZXT (HGS130)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '300 ZX (Z31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1995-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '300 ZX (Z32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = '350 Z' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '2000-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA I (N15)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA I Hatchback (N15)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA II (N16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA II Hatchback (N16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA Mk II (N16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA Mk II (N16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA TINO (V10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '2000-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA (N15)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'ALMERA hatchback (N15)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD (910)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-08-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD (B610)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-12-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD (T72 , T12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1990-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD (U11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD Break (WU11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-12-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD Hatchback (T72, T12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-11-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD Station Wagon (WU11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1984-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD Traveller (W910)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'BLUEBIRD coupe (910)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-09-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'CHERRY (E10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-04-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'CHERRY (N12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-08-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'CHERRY Hatchback (N10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-08-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'CHERRY Traveller (VN10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-08-01',
"valjalaske_lopp" = '1982-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'CHERRY coupe (N10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-12-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 100 A (E10, BLF10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-12-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 100 A universal (WBLF10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-04-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 120 Y coupe (KB 210)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-04-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 120' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1977-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 140 J' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-02-01',
"valjalaske_lopp" = '1983-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 140 Y universal (HLB310)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1982-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 160 J (710, A10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-05-01',
"valjalaske_lopp" = '1981-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 180 B (PL810)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-09-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'DATSUN 240 coupe (KMLGC210)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'INTERSTAR bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'INTERSTAR truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'KUBISTAR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-03-01',
"valjalaske_lopp" = '1983-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'LAUREL (HLC230)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'LAUREL (JC31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'LAUREL (JC32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MAXIMA (J30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '2000-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MAXIMA QX (A32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MAXIMA QX (A33)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MAXIMA Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-12-01',
"valjalaske_lopp" = '1992-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MICRA (K10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '2003-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MICRA (K11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'MICRA (K12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATHFINDER (R50)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = '1997-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL GR I (Y60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL GR II (Y61)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL GR Mk II (Y61)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = '1997-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL GR (Y60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-11-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL Hardtop (K160)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-05-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL Hardtop (K260)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-11-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL Station Wagon (W160)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PATROL Station Wagon (W260)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1986-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PICK UP (720)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PICK UP (D21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PICK UP (D22)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1988-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRAIRIE (M10, NM10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRAIRIE PRO (M11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMASTAR bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMASTAR truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA (P10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA (P11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA (P12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Break (W10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Break (WP11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Hatchback (P10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = '2002-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Hatchback (P11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Hatchback (P12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Traveller (W10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Traveller (WP11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA Traveller (WP12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PRIMERA universal (WP12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PULSAR II (N16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'PULSAR II hatchback (N16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SERENA (C23M)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1983-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SILVIA (S110)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-04-01',
"valjalaske_lopp" = '1988-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SILVIA (S12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'STANZA (T11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'STANZA Hatchback (T11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1982-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY (140Y, 150Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-06-01',
"valjalaske_lopp" = '1982-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Break (140Y, 150Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY I (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY I Break (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY I Traveller (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY I coupe (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY II (N13)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY II Break (B12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY II Hatchback (N13)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY II Traveller (B12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY II coupe (B12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY III (N14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY III Break (Y10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY III Hatchback (N14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY III Liftback (N14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY III Traveller (Y10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk II (N13)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk II hatchback (N13)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk II coupe (B12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk II universal (B12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk III (N14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk III hatchback (N14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-10-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk III hatchback (N14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Mk III universal (Y10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-06-01',
"valjalaske_lopp" = '1982-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY Traveller (140Y, 150Y)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY coupe (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-03-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY universal (B11)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'SUNNY truck (Y10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-07-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'TERRANO I (WD21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'TERRANO II (R20)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'TERRANO Mk II (R20)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-07-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'TERRANO (WD21)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1988-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'URVAN bus (E23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'URVAN bus (E24)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-07-01',
"valjalaske_lopp" = '1987-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'URVAN truck (E23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'URVAN truck (E24)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VANETTE CARGO bus (HC 23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VANETTE CARGO truck (HC 23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VANETTE bus (C22)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-06-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VANETTE bus (KC120)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VANETTE truck (C22)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1982-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VIOLET (710, A10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1977-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'VIOLET' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NISSAN' )
AND "mudel" = 'X-TRAIL (T30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = '1000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-09-01',
"valjalaske_lopp" = '1971-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = '1200' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-08-01',
"valjalaske_lopp" = '1974-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = 'PRINZ' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1971-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = 'RO 80' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = 'SPIDER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-07-01',
"valjalaske_lopp" = '1971-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = 'TT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1971-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='NSU' )
AND "mudel" = 'TTS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OLDSMOBILE' )
AND "mudel" = 'CUTLASS SUPREME' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OLTCIT' )
AND "mudel" = '11' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-04-01',
"valjalaske_lopp" = '1969-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ADMIRAL A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-03-01',
"valjalaske_lopp" = '1978-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ADMIRAL B' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'AGILA (H00)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ARENA Combi (THB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ARENA truck (TB, TF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-10-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASCONA A (81_, 86_, 87_, 88_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-10-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASCONA A Voyage (84_, 89_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASCONA B (81_, 86_, 87_, 88_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASCONA C (81_, 86_, 87_, 88_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASCONA C hatchback (84_, 89_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F (56_, 57_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F CLASSIC hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F CLASSIC universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F CLASSIC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-10-01',
"valjalaske_lopp" = '1999-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F Van (55_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F hatchback (53_, 54_, 58_, 59_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F cabrio (53_B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA F universal (51_, 52_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G (F69_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G Delvan (F70)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G hatchback (F48_, F08_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G coupe (F07_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G universal (F35_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA G truck (F70)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA H universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ASTRA H' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = '1997-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CALIBRA A (85_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CAMPO (TF_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMBO (71_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMBO Tour' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMBO truck/universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1972-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMMODORE A coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1972-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMMODORE A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1978-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMMODORE B coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1978-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMMODORE B' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-08-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMMODORE C (14_, 19_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-12-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'COMMODORE C universal (61)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-09-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA A TR (91_, 92_, 96_, 97_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-09-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA A hatchback (93_, 94_, 98_, 99_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-02-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA A truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA B (73_, 78_, 79_, F35_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA B truck (73_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA C (F08, F68)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'CORSA C truck (F08, W5L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-03-01',
"valjalaske_lopp" = '1967-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'DIPLOMAT A coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-10-01',
"valjalaske_lopp" = '1969-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'DIPLOMAT A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-03-01',
"valjalaske_lopp" = '1978-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'DIPLOMAT B' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'FRONTERA A (5_MWL4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'FRONTERA A Sport (5_SUD2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'FRONTERA B (6B_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-09-01',
"valjalaske_lopp" = '1973-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-09-01',
"valjalaske_lopp" = '1965-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT A coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-03-01',
"valjalaske_lopp" = '1968-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT A universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-09-01',
"valjalaske_lopp" = '1965-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-09-01',
"valjalaske_lopp" = '1973-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT B coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-09-01',
"valjalaske_lopp" = '1973-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT B universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-09-01',
"valjalaske_lopp" = '1973-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT B' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT C City' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT C coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT C universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT C' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = '1984-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT D (31_-34_, 41_-44_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = '1984-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT D universal (35_, 36_, 45_, 46_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT E (39_, 49_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT E Combo (38_, 48_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT E hatchback (33_, 34_, 43_, 44_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT E cabrio (43B_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT E universal (35_, 36_, 45_, 46_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-08-01',
"valjalaske_lopp" = '1992-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KADETT E truck (37_, 47_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1958-05-01',
"valjalaske_lopp" = '1963-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'KAPITДN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-09-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MANTA A (58_, 59_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MANTA B (58_, 59_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-09-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MANTA B CC (53_, 55_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MERIVA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MONTEREY A (UBS_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MONTEREY B' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MONZA A (22_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MOVANO Combi (J9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MOVANO c бортовой платформой/ходовая часть (U9, E9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MOVANO самосвал (H9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'MOVANO truck (F9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1971-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OLYMPIA A coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1971-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OLYMPIA A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-07-01',
"valjalaske_lopp" = '1960-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OLYMPIA REKORD universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-03-01',
"valjalaske_lopp" = '1966-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OLYMPIA REKORD' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OMEGA A (16_, 17_, 19_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OMEGA A universal (66_, 67_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2003-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OMEGA B (25_, 26_, 27_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2003-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'OMEGA B universal (21_, 22_, 23_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1965-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD A coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1965-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-08-01',
"valjalaske_lopp" = '1967-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD B coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-08-01',
"valjalaske_lopp" = '1967-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD B universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-01-01',
"valjalaske_lopp" = '1966-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD B' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD C coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD C universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD C' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD D coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD D universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD D' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD E (17_-19_, 11_, 14_, 16_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD E universal (61_, 66_, 67_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-07-01',
"valjalaske_lopp" = '1961-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD P1 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-06-01',
"valjalaske_lopp" = '1960-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD P1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-08-01',
"valjalaske_lopp" = '1963-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD P2 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-08-01',
"valjalaske_lopp" = '1963-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD P2 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-08-01',
"valjalaske_lopp" = '1963-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'REKORD P2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1987-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'SENATOR A (29_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'SENATOR B (29_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'SIGNUM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-11-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'SINTRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'SPEEDSTER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '2000-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'TIGRA (95_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'TIGRA TwinTop' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA A (86_, 87_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-04-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA A hatchback (88_, 89_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA B (36_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA B hatchback (38_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA B universal (31_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA C GTS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA C universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VECTRA C' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VIVARO Combi' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'VIVARO truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OPEL' )
AND "mudel" = 'ZAFIRA (F75_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OSCA' )
AND "mudel" = '2500 GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OTOSAN' )
AND "mudel" = 'ANADOL Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OTOSAN' )
AND "mudel" = 'ANADOL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='OTOSAN' )
AND "mudel" = 'TAUNUS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PANOZ' )
AND "mudel" = 'ROADSTER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PANTHER' )
AND "mudel" = 'KALLISTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PANTHER' )
AND "mudel" = 'LIMA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PANTHER' )
AND "mudel" = 'SOLO coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PAYKAN' )
AND "mudel" = '1600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = '1979-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PAYKAN' )
AND "mudel" = '1725' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PAYKAN' )
AND "mudel" = '1800' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-09-01',
"valjalaske_lopp" = '1988-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '104 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-10-01',
"valjalaske_lopp" = '1988-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '104' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1996-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '106 I (1A, 1C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '106 II (1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '106 Mk II (1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1996-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '106 (1A, 1C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1977-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '204 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1970-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '204 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-07-01',
"valjalaske_lopp" = '1970-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '204 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1977-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '204' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 I (741A/C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-04-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 I cabrio (741B, 20D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 II (20A/C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 Mk II (20A/C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1987-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 (741A/C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-04-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 cabrio (741B, 20D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '205 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '206 (2A/C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '206 CC (2D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '206 SW (2E/K)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '20coeur (2D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-09-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '304 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-03-01',
"valjalaske_lopp" = '1976-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '304 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-03-01',
"valjalaske_lopp" = '1975-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '304 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1979-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '304' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-11-01',
"valjalaske_lopp" = '1982-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 I (581A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1982-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 I Break (581D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 II (581M)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 II Break (581E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 Mk II (581M)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 Mk II universal (581E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-11-01',
"valjalaske_lopp" = '1982-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 (581A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1982-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '305 universal (581D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '306 (7B, N3, N5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '306 Break (7E, N3, N5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '306 hatchback (7A, 7C, N3, N5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '306 cabrio (7D, N3, N5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '307 (3A/C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '307 Break (3E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '307 CC (3B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '307 SW (3H)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '309 I (10C, 10A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-07-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '309 II (3C, 3A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-07-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '309 Mk II (3C, 3A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '309 (10C, 10A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-04-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '404 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-04-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '404' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 I (15B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 I Break (15E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 II (4B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '1996-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 II Break (4E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 Mk II (4B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '1996-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 Mk II universal (4E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 (15B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '405 universal (15E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = '2004-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '406 (8B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '406 Break (8E/F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '406 coupe (8C)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '407 SW' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '407' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-04-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '504 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-10-01',
"valjalaske_lopp" = '1984-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '504 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-10-01',
"valjalaske_lopp" = '1984-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '504 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '504 пикап' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-07-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '504' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '505 (551A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-04-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '505 Break (551D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1987-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '604' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '605 (6B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '607 (9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2002-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '806 (221)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = '807 (E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'BOXER c бортовой платформой/ходовая часть (244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'BOXER c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'BOXER bus (230P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'BOXER bus (244, Z_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-03-01',
"valjalaske_lopp" = '2002-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'BOXER truck (230L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'BOXER truck (244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'EXPERT (224)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'EXPERT c бортовой платформой/ходовая часть (223)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'EXPERT truck (222)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J5 c бортовой платформой/ходовая часть (280L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J5 c бортовой платформой/ходовая часть (290L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J5 bus (280P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J5 bus (290P)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1990-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J5 truck (280L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J5 truck (290L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1980-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J7 c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1980-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J7 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1980-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J7 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1987-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J9 c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1987-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J9 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1987-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'J9 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'PARTNER Combispace (5F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PEUGEOT' )
AND "mudel" = 'PARTNER truck (5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PIAGGIO' )
AND "mudel" = 'M500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PIAGGIO' )
AND "mudel" = 'PORTER c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PIAGGIO' )
AND "mudel" = 'PORTER truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PIAGGIO' )
AND "mudel" = 'VESPACAR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = '2001-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PLYMOUTH' )
AND "mudel" = 'BREEZE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PLYMOUTH' )
AND "mudel" = 'NEON II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-05-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PLYMOUTH' )
AND "mudel" = 'NEON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PLYMOUTH' )
AND "mudel" = 'VOYAGER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'BONNEVILLE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-12-01',
"valjalaske_lopp" = '1989-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'FIREBIRD ''81' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'FIREBIRD ''89' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'FIREBIRD cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-04-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'PHOENIX coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-04-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'PHOENIX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'SUNBIRD' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-07-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'TRANS SPORT ''89' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PONTIAC' )
AND "mudel" = 'TRANS SPORT ''97' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '356 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1965-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '356' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-12-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 (964)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-10-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 (993)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 (996)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 (997)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 Targa (993)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-11-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 Targa' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 cabrio (964)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 cabrio (993)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 cabrio (996)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1989-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911 тарга (996)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1990-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '911' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-03-01',
"valjalaske_lopp" = '1970-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '912 Targa' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-01-01',
"valjalaske_lopp" = '1970-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '912' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1976-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '914' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-11-01',
"valjalaske_lopp" = '1988-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '924' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-09-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '928' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-12-01',
"valjalaske_lopp" = '1991-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '944 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-06-01',
"valjalaske_lopp" = '1991-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '944' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1991-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '959' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-06-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '968 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-06-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = '968' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = 'BOXSTER (986)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = 'CARRERA GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = 'CAYENNE (955)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PORSCHE' )
AND "mudel" = 'GT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PREMIER' )
AND "mudel" = '118 NE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PREMIER' )
AND "mudel" = 'PADMINI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'AEROBACK hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'ISWARA hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'ISWARA sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'MPI Hatchback hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'MPI Sedan sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'PERSONA 300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'PERSONA 400 hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'PERSONA 400' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1996-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'SALOON sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'SATRIA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'WIRA hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PROTON' )
AND "mudel" = 'WIRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PUCH (STEYR-DAIMLER-PUCH)' )
AND "mudel" = 'G-MODELL (W 460)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PUCH (STEYR-DAIMLER-PUCH)' )
AND "mudel" = 'G-MODELL (W 461)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='PUCH (STEYR-DAIMLER-PUCH)' )
AND "mudel" = 'G-MODELL (W 463)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-02-01',
"valjalaske_lopp" = '1978-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RANGER' )
AND "mudel" = 'REKORD coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-02-01',
"valjalaske_lopp" = '1978-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RANGER' )
AND "mudel" = 'REKORD' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RAYTON FISSORE' )
AND "mudel" = 'MAGNUM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'KITTEN Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'KITTEN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'REBEL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'SCIMITAR Cabriolet' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'SCIMITAR Roadster' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'SCIMITAR SABRE Roadster' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RELIANT' )
AND "mudel" = 'SCIMITAR Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-05-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '10' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1989-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '11 (B/C37_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1989-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '11 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '12 Break (117_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '12 Variable (117_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-07-01',
"valjalaske_lopp" = '1983-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '12 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '12' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-05-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '14 (121_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-03-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '15' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-09-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '16 (115_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-03-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '17' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '18 (134_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '18 Break (135_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '18 Variable (135_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '18 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 I (B/C53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = '1992-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 I Cabriolet (D53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 I Chamade (L53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 I truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 II (B/C53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 II Cabriolet (D53_, 853_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 II Chamade (L53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 II truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 Mk II (B/C53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 Mk II cabrio (D53_, 853_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 Mk II sedan (L53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 Mk II truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 (B/C53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-07-01',
"valjalaske_lopp" = '1992-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 cabrio (D53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 sedan (L53_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '19 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '20 (127_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-09-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '21 (B48_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-03-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '21 sedan (L48_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-03-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '21 universal (K48_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-06-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '21 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-04-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '25 (B29_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-02-01',
"valjalaske_lopp" = '1986-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '30 (127_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '4 (112_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-09-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '4 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '5 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '5' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-10-01',
"valjalaske_lopp" = '1987-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '6' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-11-01',
"valjalaske_lopp" = '1969-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = '9 (L42_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = '2003-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'AVANTIME (DE0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-05-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO I (B/C57_, 5/357_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO I truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO II (B/C/B0/1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO II truck (SB0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO Mk II (B/C/B0/1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-05-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO (B/C57_, 5/357_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'CLIO truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE I (J11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE II (J/S63_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-11-01',
"valjalaske_lopp" = '2002-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE III (JE_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE IV (JK0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE Mk II (J/S63_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-11-01',
"valjalaske_lopp" = '2002-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE Mk III (JE_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE Mk IV (JK0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-07-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESPACE (J11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-02-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'ESTAFETTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'EXPRESS truck (F40_, G40_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'EXTRA truck (F40_, G40_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-02-01',
"valjalaske_lopp" = '1985-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'FUEGO (136_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'GRAND SCЙNIC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'KANGOO (KC0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'KANGOO Express (FC0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'KANGOO Rapid (FC0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-11-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'LAGUNA (B56_, 556_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'LAGUNA (B74_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-09-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'LAGUNA Grandtour (K56_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'LAGUNA Grandtour (K74_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-09-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'LAGUNA Nevada (K56_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MASTER I c бортовой платформой/ходовая часть (P__)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MASTER I bus (T__)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MASTER I truck (T__)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MASTER II c бортовой платформой/ходовая часть (ED/HD/UD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MASTER II bus (JD/ND)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MASTER II truck (FD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Break (KA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Cabriolet (EA0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Classic (LA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Coach (DA0/1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Coupй (DA0/1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Grandtour (KA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE I (BA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE II (BM0_, CM0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE II Coupй-Cabriolet' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE II Grandtour' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE II sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '1999-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'MEGANE Scenic (JA0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'RAPID truck (F40_, G40_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-08-01',
"valjalaske_lopp" = '1981-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'RODEO 4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-11-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'RODEO 5' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-05-01',
"valjalaske_lopp" = '1981-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'RODEO 6' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SAFRANE I (B54_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = '2000-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SAFRANE II (B54_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-07-01',
"valjalaske_lopp" = '2000-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SAFRANE Mk II (B54_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SAFRANE (B54_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SCЙNIC (JA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SCЙNIC II (JM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-03-01',
"valjalaske_lopp" = '1999-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SPORT SPIDER (EF0_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SUPER 5 (B/C40_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'SUPER 5 truck (S40_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'THALIA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1989-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC c бортовой платформой/ходовая часть (P6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC c бортовой платформой/ходовая часть (PXX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC bus (JL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1989-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC bus (T5, T6, T7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC bus (TXW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC truck (FL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-03-01',
"valjalaske_lopp" = '1989-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC truck (T1, T3, T4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TRAFIC truck (TXX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TWINGO (C06_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'TWINGO truck (S06_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RENAULT' )
AND "mudel" = 'VEL SATIS (BJ0)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-03-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RILEY' )
AND "mudel" = '4/72' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RILEY' )
AND "mudel" = 'ELF Mk.III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-03-01',
"valjalaske_lopp" = '1968-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='RILEY' )
AND "mudel" = 'KESTREL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROLLS-ROYCE' )
AND "mudel" = 'CORNICHE cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROLLS-ROYCE' )
AND "mudel" = 'PHANTOM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROLLS-ROYCE' )
AND "mudel" = 'SILVER SERAPH' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-11-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '100 (METRO) (XP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-04-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '100 cabrio (XP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '200 (RF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-03-01',
"valjalaske_lopp" = '1989-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '200 (XH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-10-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '200 hatchback (XW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '200 coupe (XW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-06-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '2000-3500 hatchback (SD1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-09-01',
"valjalaske_lopp" = '1976-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '2200-3500 (P6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '25 (RF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-05-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '400 (RT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-04-01',
"valjalaske_lopp" = '1995-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '400 (XW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-09-01',
"valjalaske_lopp" = '1998-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '400 Tourer (XW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-05-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '400 hatchback (RT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '45 (RT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '45 sedan (RT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-08-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '600 (RH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '75 (RJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '75 Tourer (RJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '800 hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '800 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1999-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = '800' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-01-01',
"valjalaske_lopp" = '1969-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'A60 CAMBRIDGE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1999-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'CABRIOLET (XW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-03-01',
"valjalaske_lopp" = '1999-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'COUPE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'MAESTRO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'MINI MK I cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'MINI MK I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'MONTEGO Break (XE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'MONTEGO Estate (XE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'MONTEGO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ROVER' )
AND "mudel" = 'STREETWISE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = '2002-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9-3 (YS3D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9-3 (YS3F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = '2003-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9-3 Cabriolet (YS3D)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9-3 cabrio (YS3F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9-5 (YS3E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9-5 universal (YS3E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-09-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 I Combi Coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 I cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-12-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 II cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-12-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 II coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-12-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 Mk II cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-12-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 Mk II coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-09-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1994-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9000 hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-04-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '9000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '900' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-08-01',
"valjalaske_lopp" = '1987-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '90' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1978-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '95 Station Wagon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-10-01',
"valjalaske_lopp" = '1980-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '96' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1987-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '99 Combi Coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-11-01',
"valjalaske_lopp" = '1987-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SAAB' )
AND "mudel" = '99' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '124 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1980-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '124' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-04-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '127 (127A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '128' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-05-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '131' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '132' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-05-01',
"valjalaske_lopp" = '1979-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '133' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-09-01',
"valjalaske_lopp" = '1970-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '600 D' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1975-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = '850' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'ALHAMBRA (7V8, 7V9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'ALTEA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'AROSA (6H)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-06-01',
"valjalaske_lopp" = '2002-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'CORDOBA (6K2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-02-01',
"valjalaske_lopp" = '1999-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'CORDOBA (6K2/C2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'CORDOBA (6L2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = '1999-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'CORDOBA Vario (6K5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'CORDOBA Vario (6K5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'FURA (025A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-06-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA I (021A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA II (6K1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = '2002-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA III (6K1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA IV (6L1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA Mk II (6K1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-08-01',
"valjalaske_lopp" = '2002-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA Mk III (6K1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA Mk IV (6L1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-06-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'IBIZA (021A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'INCA (6K9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'LEON (1M1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'MALAGA (023A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-08-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'MARBELLA (28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-11-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'MARBELLA truck (028A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-10-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'PANDA (141A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-07-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'RITMO (138)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-06-01',
"valjalaske_lopp" = '1988-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'RONDA (022A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'TERRA (24)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1996-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'TERRA truck (024A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'TOLEDO I (1L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'TOLEDO II (1M2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'TOLEDO Mk II (1M2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SEAT' )
AND "mudel" = 'TOLEDO (1L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SHELBY' )
AND "mudel" = 'SERIES 1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SIPANI' )
AND "mudel" = 'D-1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SIPANI' )
AND "mudel" = 'MONTANA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-09-01',
"valjalaske_lopp" = '1970-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '1000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '100' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-08-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '105,120 (742)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '105,120 (744)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-07-01',
"valjalaske_lopp" = '1982-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '110 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1970-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '1100' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-12-01',
"valjalaske_lopp" = '1982-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '110' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-02-01',
"valjalaske_lopp" = '1991-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = '130' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FABIA (6Y2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FABIA Combi (6Y5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FABIA Praktik' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FABIA sedan (6Y3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-05-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FAVORIT (781)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1995-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FAVORIT Forman (785)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-12-01',
"valjalaske_lopp" = '1997-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FAVORIT пикап (787)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA I (6U1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA I Fun (797)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA I universal (6U5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA II (6U1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA II universal (6U5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA Mk II (6U1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = '2001-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA Mk II universal (6U5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA (6U1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA пикап (797)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'FELICIA universal (6U5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'OCTAVIA (1U2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'OCTAVIA (1Z)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'OCTAVIA Combi (1U5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-04-01',
"valjalaske_lopp" = '1971-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'OKTAVIA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1991-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'RAPID (120G, 130G, 135G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SKODA' )
AND "mudel" = 'SUPERB (3U4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'CABRIO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'CITY-COUPE (MC01)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'CROSSBLADE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'FORFOUR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'FORTWO cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'FORTWO coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'ROADSTER coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SMART (MCC)' )
AND "mudel" = 'ROADSTER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SPECTRE' )
AND "mudel" = 'R42' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SPECTRE' )
AND "mudel" = 'R45' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-12-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SSANGYONG' )
AND "mudel" = 'KORANDO (K4)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SSANGYONG' )
AND "mudel" = 'KORANDO (KJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SSANGYONG' )
AND "mudel" = 'KORANDO Cabrio (KJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SSANGYONG' )
AND "mudel" = 'MUSSO (FJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SSANGYONG' )
AND "mudel" = 'REXTON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-01-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='STANDARD' )
AND "mudel" = 'GAZEL' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1990-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = '1800 XT COUPE (XT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-08-01',
"valjalaske_lopp" = '2002-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'FORESTER (SF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'FORESTER (SG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '2000-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'IMPREZA (GC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'IMPREZA (GD, GG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-12-01',
"valjalaske_lopp" = '2000-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'IMPREZA coupe (GFC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'IMPREZA universal (GD, GG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-08-01',
"valjalaske_lopp" = '2000-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'IMPREZA universal (GF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'JUSTY I (KAD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'JUSTY II (JMA, MS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'JUSTY III (G3X)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'JUSTY Mk II (JMA, MS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'JUSTY (KAD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY I (BC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY I universal (BJF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY II (BD, BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '1998-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY II universal (BD, BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY III (BE, BH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY III universal (BE, BH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY IV universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY Mk II (BD, BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '1998-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY Mk II universal (BD, BG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY Mk III (BE, BH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY Mk III universal (BE, BH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY (BC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1994-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEGACY universal (BJF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE I (AB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE I Hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE I universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1992-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1992-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1991-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE (AB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1984-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LEONE universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '2000-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'LIBERO bus (E10, E12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'M70/80' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1989-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'MINI JUMBO II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'MINI JUMBO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'OUTBACK (BE, BH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'OUTBACK' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-07-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1989-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1989-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-07-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-06-01',
"valjalaske_lopp" = '1992-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'REX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '2000-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'SUMO bus (E10, E12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-09-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'SVX (CX)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '2000-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'VANILLE bus (E10, E12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1995-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUBARU' )
AND "mudel" = 'VIVIO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-06-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO I (SS80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1993-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO II (EC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '2002-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO III (EF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO IV (FF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1993-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO Mk II (EC)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-09-01',
"valjalaske_lopp" = '2002-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO Mk III (EF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO Mk IV (FF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-06-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'ALTO (SS80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'BALENO (EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'BALENO hatchback (EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'BALENO universal (EG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-02-01',
"valjalaske_lopp" = '1995-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'CAPPUCINO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'CARRY truck (FD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-11-01',
"valjalaske_lopp" = '1985-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'CARRY truck (ST90V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'GRAND VITARA (FT, GT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-10-01',
"valjalaske_lopp" = '2003-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'IGNIS (FH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'IGNIS II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'JIMNY (FJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'LIANA (ER)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'LIANA universal (ER)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1984-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'LJ 80' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SAMURAI (SJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SJ 410 Cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SJ 410' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SJ 413' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SUPER CARRY bus (ED)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT I (AA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT II (AH, AJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT II hatchback (EA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT Mk II (AH, AJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT Mk II hatchback (EA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT (AA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'SWIFT cabrio (SF413)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-07-01',
"valjalaske_lopp" = '1998-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'VITARA (ET, TA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-07-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'VITARA Cabrio (ET, TA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = '2000-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'WAGON R+ (EM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'WAGON R+ (MM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='SUZUKI' )
AND "mudel" = 'X-90 (EL)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-07-01',
"valjalaske_lopp" = '1984-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = '1307-1510' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1979-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = '160' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-06-01',
"valjalaske_lopp" = '1982-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = '180' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-04-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'AVENGER Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-02-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'AVENGER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1986-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'HORIZON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-01-01',
"valjalaske_lopp" = '1980-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'MATRA BAGHEERA (X)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1985-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'MURENA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-01-01',
"valjalaske_lopp" = '1984-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'RANCHO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SAMBA (51A)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-01-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SAMBA cabrio (51E)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-10-01',
"valjalaske_lopp" = '1978-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1100 Break/Tourisme' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1100 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1100 hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1200 S coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-08-01',
"valjalaske_lopp" = '1968-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1301 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1301 Tourisme' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1301' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-11-01',
"valjalaske_lopp" = '1968-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1500 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-10-01',
"valjalaske_lopp" = '1968-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1501 Break/Tourisme' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1501 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1976-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1501' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-09-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA 1609/1610' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-10-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA SIM''4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-07-01',
"valjalaske_lopp" = '1983-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SIMCA SUNBEAM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-02-01',
"valjalaske_lopp" = '1986-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'SOLARA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-06-01',
"valjalaske_lopp" = '1987-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TALBOT' )
AND "mudel" = 'TAGORA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TATA (TELCO)' )
AND "mudel" = 'INDICA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TATA (TELCO)' )
AND "mudel" = 'SAFARI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TATA (TELCO)' )
AND "mudel" = 'SIERRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-04-01',
"valjalaske_lopp" = '1978-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = '1000 (KP30_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-04-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = '1000 truck (KP36V_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = '1996-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = '4 RUNNER (_N130)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = '4 RUNNER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS (T25)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS (_T22_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS Combi (T25)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS Liftback (_T22_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS Station Wagon (_T22_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS VERSO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS sedan (T25)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'AVENSIS universal (T25)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-06-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY (_V1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = '2001-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY (_V20)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-10-01',
"valjalaske_lopp" = '1991-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY (_V2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY (_V30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1988-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY Liftback (V1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-06-01',
"valjalaske_lopp" = '1997-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY Station Wagon (_V10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-11-01',
"valjalaske_lopp" = '1991-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY Station Wagon (_V2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-02-01',
"valjalaske_lopp" = '1988-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CAMRY sedan (V1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-05-01',
"valjalaske_lopp" = '1978-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA (TA1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-05-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA (TA4L, TA6_L)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA E (_T19_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA E Sportswagon (_T19_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1997-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA E sedan (_T19_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA II (_T15_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA II (_T17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1992-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA II Station Wagon (_T17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA II sedan (_T15_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA II sedan (_T17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA Mk II (_T15_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA Mk II (_T17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-10-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA Mk II sedan (_T15_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA Mk II sedan (_T17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1992-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA Mk II universal (_T17_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-04-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CARINA Station Wagon (TA4K, TA6K)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1990-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA (ST16_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-05-01',
"valjalaske_lopp" = '1978-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA (TA2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA (TA60, RA40, RA6_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA (ZZT23_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-11-01',
"valjalaske_lopp" = '1999-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA (_T20_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-05-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA SUPRA (MA61)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA hatchback (T16)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA cabrio (_T16_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-05-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA cabrio (_T18_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-11-01',
"valjalaske_lopp" = '1999-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA cabrio (_T20_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA coupe (RA6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1990-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA coupe (T16F)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1985-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA coupe (TA4C, TA60)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-10-01',
"valjalaske_lopp" = '1994-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CELICA coupe (_T18_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-04-01',
"valjalaske_lopp" = '1978-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COPAIN (KP30_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-04-01',
"valjalaske_lopp" = '1978-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COPAIN truck (KP36V_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-10-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (KE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (_E10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (_E11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (_E12U_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (_E7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-06-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (_E8_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-07-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA (_E9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-07-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Combi (KE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Combi (_E12J_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Compact (_E10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Compact (_E11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = '1992-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Compact (_E9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-08-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA FX Compact (E8B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-08-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA FX hatchback (E8B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Liftback (_E10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Liftback (_E11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-06-01',
"valjalaske_lopp" = '1988-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Liftback (_E8_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-07-01',
"valjalaske_lopp" = '1993-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Liftback (_E9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-12-01',
"valjalaske_lopp" = '1987-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Station Wagon (_E7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-12-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Station Wagon (_E9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Verso (_E12J_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Verso' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Wagon (_E10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA Wagon (__E11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-10-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA hatchback (KE, TE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-07-01',
"valjalaske_lopp" = '1997-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA hatchback (_E10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = '2002-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA hatchback (_E11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA hatchback (_E7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = '1992-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA hatchback (_E9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-05-01',
"valjalaske_lopp" = '1987-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA coupe (AE86)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-07-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA coupe (KE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA sedan (_E12_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'COROLLA universal (_E12J_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-12-01',
"valjalaske_lopp" = '1981-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CORONA (RX, RT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-06-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CORONA hatchback (TT)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-04-01',
"valjalaske_lopp" = '1979-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CORONA universal (RT118)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-07-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CRESSIDA (RX3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1985-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CRESSIDA (_X6_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-07-01',
"valjalaske_lopp" = '1981-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CRESSIDA Station Wagon (RX3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1985-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CRESSIDA Station Wagon (X6K)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-04-01',
"valjalaske_lopp" = '1985-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CROWN (_S1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-09-01',
"valjalaske_lopp" = '1983-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'CROWN Station Wagon (_S1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'ESTIMA (ACR3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE I Wagon (_H_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-02-01',
"valjalaske_lopp" = '1983-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE I truck (_H_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1989-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE II Wagon (H5_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-03-01',
"valjalaske_lopp" = '1989-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE II truck (H5_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-08-01',
"valjalaske_lopp" = '1995-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE III Wagon (_H10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-08-01',
"valjalaske_lopp" = '1995-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE III truck (_H10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE IV Wagon (_H1_, _H2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HIACE IV truck (_H1_, _H2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'HILUX пикап (_N_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER (J12)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-03-01',
"valjalaske_lopp" = '1986-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER (_J4_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER (_J6_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER (_J7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER 100 (_J10_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER 80 (_J8_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER 90 (_J9_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = '1996-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER Hardtop (_J7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-03-01',
"valjalaske_lopp" = '1986-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LAND CRUISER пикап (_J4_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1992-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LITEACE bus (CM30_G, KM30_G)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LITEACE bus (_R2_LG)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-10-01',
"valjalaske_lopp" = '1992-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LITEACE truck (CM3_V, KM3_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-10-01',
"valjalaske_lopp" = '1986-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LITEACE truck (M2_V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-01-01',
"valjalaske_lopp" = '1995-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'LITEACE truck (_R2__V)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-11-01',
"valjalaske_lopp" = '1990-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'MODELL F bus (_R2_, 31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'MR (ZZW30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'MR 2 (ZZW30)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-11-01',
"valjalaske_lopp" = '1990-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'MR 2 (_W1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-12-01',
"valjalaske_lopp" = '2000-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'MR 2 (_W2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-08-01',
"valjalaske_lopp" = '1999-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PASEO (EL54)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-10-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PASEO cabrio (EL54)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PICNIC (_XM10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PREVIA (ACR3_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-05-01',
"valjalaske_lopp" = '2000-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PREVIA (TCR1_, 2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-05-01',
"valjalaske_lopp" = '2004-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PRIUS (NHW11_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'PRIUS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2000-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'RAV 4 I (SXA1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-12-01',
"valjalaske_lopp" = '2000-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'RAV 4 I Cabrio (SXA1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'RAV 4 II (XA2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'RAV 4 Mk II (XA2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-06-01',
"valjalaske_lopp" = '2000-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'RAV 4 (SXA1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-12-01',
"valjalaske_lopp" = '2000-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'RAV 4 (SXA1_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = '1999-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET (EP91)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET (KP6_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-10-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET (_P7_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-12-01',
"valjalaske_lopp" = '1996-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET (_P8_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-11-01',
"valjalaske_lopp" = '1978-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET 1000 (KP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-11-01',
"valjalaske_lopp" = '1978-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET 1000 Kombi (KP)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'STARLET universal (KP6_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-05-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'SUPRA (JZA80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1993-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'SUPRA (MA70)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-10-01',
"valjalaske_lopp" = '1988-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'TERCEL (AL2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1988-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'TERCEL (_L1_, _L2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'YARIS (_CP10)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TOYOTA' )
AND "mudel" = 'YARIS VERSO (NC/LP2_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-05-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = '1.1 Tramp' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-12-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = '1.1 Universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-05-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = '1.1' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-10-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = 'P 601 Tramp' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = 'P 601 Universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-07-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = 'P 601 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1990-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRABANT' )
AND "mudel" = 'P 601' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-01-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '1500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2.5 PI MK I Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2.5 PI MK I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2000 MK I Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-01-01',
"valjalaske_lopp" = '1972-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2000 MK I' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-03-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2000 MKII Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-03-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2000 MKII' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-05-01',
"valjalaske_lopp" = '1979-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2500 Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-05-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = '2500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'ACCLAIM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'DOLOMITE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'GT6' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'HERALD Estate' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'HERALD cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'HERALD' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-01-01',
"valjalaske_lopp" = '1963-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'ITALIA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-10-01',
"valjalaske_lopp" = '1980-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'SPITFIRE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'STAG' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-01-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TOLEDO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1953-01-01',
"valjalaske_lopp" = '1955-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 2' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1955-01-01',
"valjalaske_lopp" = '1957-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 3' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1957-12-01',
"valjalaske_lopp" = '1961-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 3A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1965-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 4' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-12-01',
"valjalaske_lopp" = '1967-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 4A' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1969-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 5 (250)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1976-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 6' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 7 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1981-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 7' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1981-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'TR 8' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'VITESSE Cabriolet' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TRIUMPH' )
AND "mudel" = 'VITESSE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '1600' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1977-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '2500' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '280 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1986-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '280 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '3000' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '350 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '350 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '390' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '400' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '420 Sports Saloon' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1989-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '420 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = '450' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'CERBERA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'CHIMAERA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'GRIFFITH' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-01-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'S' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'SPEED EIGHT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1980-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'TAIMAR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1983-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'TASMIN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'TUSCAN I coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'TUSCAN II Roadster' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='TVR' )
AND "mudel" = 'VIXEN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='UAZ' )
AND "mudel" = '31512' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='UAZ' )
AND "mudel" = '3160' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='UAZ' )
AND "mudel" = '3162' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='UMM' )
AND "mudel" = 'ALTER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'AGILA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2001-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ARENA Combi' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2001-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ARENA Van' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA MK IV cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA MK V hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-09-01',
"valjalaske_lopp" = '1991-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk II Belmont' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk II hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-01-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk II cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = '1991-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk III hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '2001-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk III cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-03-01',
"valjalaske_lopp" = '1998-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk III universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk IV hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk IV coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk IV universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA Mk IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-09-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRA universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-01-01',
"valjalaske_lopp" = '1998-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRAVAN Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ASTRAVAN Mk IV' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'BRAVA пикап' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-06-01',
"valjalaske_lopp" = '1997-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CALIBRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-10-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CARLTON Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-10-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CARLTON Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CARLTON Mk III universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-09-01',
"valjalaske_lopp" = '1994-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CARLTON Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER CC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER Mk II hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1988-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER Mk II cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-09-01',
"valjalaske_lopp" = '1988-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER Mk III hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1995-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER Mk III' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1981-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CAVALIER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CHEVETTE hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CHEVETTE universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CHEVETTE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '2001-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'COMBO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'COMBO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CORSA Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CORSA cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-03-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CORSA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CORSAVAN MK II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-01-01',
"valjalaske_lopp" = '2000-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CORSAVAN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-01-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CRESTA universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-01-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'CRESTA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1975-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'FIRENZA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'FRONTERA Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'FRONTERA Sport' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-03-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'FRONTERA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1975-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MAGNUM coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1981-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MAGNUM universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-01-01',
"valjalaske_lopp" = '1981-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MAGNUM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MERIVA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MIDI II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MIDI MK II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MIDI' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-07-01',
"valjalaske_lopp" = '1999-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MONTEREY Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-09-01',
"valjalaske_lopp" = '1998-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MONTEREY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MOVANO Chassis/Cab' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MOVANO Combi' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'MOVANO Van' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-05-01',
"valjalaske_lopp" = '1993-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'NOVA hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-09-01',
"valjalaske_lopp" = '1993-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'NOVA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-01-01',
"valjalaske_lopp" = '1994-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'NOVAVAN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'OMEGA universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-12-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'OMEGA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1986-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ROYALE coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1987-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ROYALE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-09-01',
"valjalaske_lopp" = '1993-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'SENATOR Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1978-02-01',
"valjalaske_lopp" = '1987-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'SENATOR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'SIGNUM' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-09-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'SINTRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'TIGRA TwinTop' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'TIGRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VECTRA Mk II GTS' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VECTRA Mk II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VECTRA Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VECTRA hatchback' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VECTRA universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VECTRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-03-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VELOX universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-03-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VELOX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1976-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VENTORA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-01-01',
"valjalaske_lopp" = '1982-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VICEROY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-03-01',
"valjalaske_lopp" = '1976-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VICTOR universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-01-01',
"valjalaske_lopp" = '1976-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VICTOR' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-01-01',
"valjalaske_lopp" = '1972-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VISCOUNT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1971-01-01',
"valjalaske_lopp" = '1975-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VIVA coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-01-01',
"valjalaske_lopp" = '1978-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VIVA universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1963-01-01',
"valjalaske_lopp" = '1979-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VIVA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VIVARO Combi' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VIVARO truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1976-01-01',
"valjalaske_lopp" = '1978-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VX universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VX220' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-01-01',
"valjalaske_lopp" = '1978-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'VX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VAUXHALL' )
AND "mudel" = 'ZAFIRA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VECTOR' )
AND "mudel" = 'M12' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-04-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '1500,1600 (31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-04-01',
"valjalaske_lopp" = '1973-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '1500,1600 Variant (36)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1965-08-01',
"valjalaske_lopp" = '1975-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '1500,1600 hatchback (31)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1942-02-01',
"valjalaske_lopp" = '1945-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '166' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-09-01',
"valjalaske_lopp" = '1979-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '181' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-07-01',
"valjalaske_lopp" = '1975-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '411,412' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-09-01',
"valjalaske_lopp" = '1975-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = '412 Variant' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'BORA (1J2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'BORA Variant (1J6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'BORA universal (1J6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY I (14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY II пикап (9U7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY II truck (9K9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY III truck (2KA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY LIFE III (2KB)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY Mk II (9K9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY Mk II (9U7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-08-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CADDY (14)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1987-08-01',
"valjalaske_lopp" = '1995-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'CORRADO (53I)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-02-01',
"valjalaske_lopp" = '1981-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'DERBY (86)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'DERBY (86C, 80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'DERBY sedan (6KV2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'FLIGHT sedan (6KV2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-04-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF I (17)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF I Cabriolet (155)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-08-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF II (19E, 1G1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF III (1H1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1998-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF III Cabriolet (1E7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF III Variant (1H5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF IV (1J1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF IV Cabriolet (1E7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF IV Variant (1J5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-08-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk II (19E, 1G1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-08-01',
"valjalaske_lopp" = '1997-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk III (1H1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1998-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk III cabrio (1E7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk III cabrio (1E7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-07-01',
"valjalaske_lopp" = '1999-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk III universal (1H5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-08-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk IV (1J1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF Mk IV universal (1J5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF V (1K1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-04-01',
"valjalaske_lopp" = '1985-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF (17)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-01-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'GOLF cabrio (155)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-03-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'ILTIS (183)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'JETTA (1J2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = '1985-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'JETTA I (17)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'JETTA II (19E, 1G2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1984-01-01',
"valjalaske_lopp" = '1992-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'JETTA Mk II (19E, 1G2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = '1985-01-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'JETTA (17)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1970-08-01',
"valjalaske_lopp" = '1974-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'K 70 (48)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-07-01',
"valjalaske_lopp" = '1981-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'KAEFER cabrio (15)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1949-04-01',
"valjalaske_lopp" = '2003-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'KAEFER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-01-01',
"valjalaske_lopp" = '1974-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'KARMANN GHIA cabrio (14, 34)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-01-01',
"valjalaske_lopp" = '1974-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'KARMANN GHIA coupe (14, 34)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 28 I bus (281-363)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 28-35 I c бортовой платформой/ходовая часть (281-363)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 28-35 I truck (281-363)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 28-35 II bus (2DM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 28-46 II c бортовой платформой/ходовая часть (2DX0FE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 28-46 II truck (2DX0AE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 40-55 I c бортовой платформой/ходовая часть (293-909)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT 40-55 I truck (291-512)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT Mk II c бортовой платформой/ходовая часть (2DX0FE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT Mk II bus (2DM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT Mk II truck (2DX0AE)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT28-50 c бортовой платформой/ходовая часть (281-363)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT28-50 bus (281-363)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-04-01',
"valjalaske_lopp" = '1996-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LT28-50 truck (281-363)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'LUPO (6X1, 6E1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'MULTIVAN Mk V (7HM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'MULTIVAN T5 (7HM)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'NEW BEETLE (9C1, 1C1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'NEW BEETLE cabrio (1Y7)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-05-01',
"valjalaske_lopp" = '1980-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT (32)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1988-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT (32B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1996-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT (3A2, 35I)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-08-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT (3B2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT (3B3)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1989-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT Variant (32B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1973-05-01',
"valjalaske_lopp" = '1981-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT Variant (33)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-02-01',
"valjalaske_lopp" = '1997-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT Variant (3A5, 35I)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-06-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT Variant (3B5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT Variant (3B6)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1988-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PASSAT sedan (32B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'PHAETON (3D2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = '1999-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO (6N1)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1999-10-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO (6N2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-03-01',
"valjalaske_lopp" = '1981-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO (86)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO (86C, 80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2001-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO (9N_)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO CLASSIC (6KV2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-01-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO CLASSIC (86C, 80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-04-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO Variant (6KV5)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-10-01',
"valjalaske_lopp" = '1994-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO coupe (86C, 80)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-11-01',
"valjalaske_lopp" = '2001-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO sedan (6KV2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO sedan' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO truck (6NF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'POLO truck (86CF)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1984-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'SANTANA (32B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'SANTANA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-02-01',
"valjalaske_lopp" = '1980-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'SCIROCCO (53)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-08-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'SCIROCCO (53B)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'SHARAN (7M8, 7M9)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-04-01',
"valjalaske_lopp" = '1997-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TARO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TOUAREG (7LA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-02-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TOURAN' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1970-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER I c бортовой платформой/ходовая часть (26)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER I bus (22, 24, 25, 28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER I truck (21, 23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER II c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1979-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER II bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER II truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER III c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER III bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER III truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER IV c бортовой платформой/ходовая часть (70XD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER IV bus (70XB, 70XC, 7DB, 7DW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER IV truck (70XA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk II c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1979-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk II bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk II truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk III c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk III bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk III truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk IV c бортовой платформой/ходовая часть (70XD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk IV bus (70XB, 70XC, 7DB, 7DW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk IV truck (70XA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk V c бортовой платформой/ходовая часть (7JD, 7' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk V bus (7HB, 7HJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER Mk V truck (7HA, 7HH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1970-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T1 c бортовой платформой/ходовая часть (26)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T1 bus (22, 24, 25, 28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T1 truck (21, 23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T2 c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-08-01',
"valjalaske_lopp" = '1979-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T2 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1979-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T2 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T3 c бортовой платформой/ходовая часть' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T3 bus' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-05-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T3 truck' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T4 c бортовой платформой/ходовая часть (70XD)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T4 bus (70XB, 70XC, 7DB, 7DW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T4 truck (70XA)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T5 c бортовой платформой/ходовая часть (7JD, 7JE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T5 bus (7HB, 7HJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER T5 truck (7HA, 7HH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER V c бортовой платформой/ходовая часть (7JD, 7JE,' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER V bus (7HB, 7HJ)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2003-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER V truck (7HA, 7HH)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1970-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER c бортовой платформой/ходовая часть (26)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER bus (22, 24, 25, 28)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1950-01-01',
"valjalaske_lopp" = '1968-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'TRANSPORTER truck (21, 23)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-11-01',
"valjalaske_lopp" = '1998-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLKSWAGEN' )
AND "mudel" = 'VENTO (1H2)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1975-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '140 (142, 144)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-08-01',
"valjalaske_lopp" = '1975-02-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '140 universal (145)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1968-08-01',
"valjalaske_lopp" = '1975-04-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '164' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-08-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '240 (P242, P244)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-08-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '240 Break (P245)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-08-01',
"valjalaske_lopp" = '1993-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '240 Kombi (P245)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1974-08-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '260 (P262, P264)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1977-08-01',
"valjalaske_lopp" = '1978-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '260 coupe (P262)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-07-01',
"valjalaske_lopp" = '1982-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '260 universal (P265)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-08-01',
"valjalaske_lopp" = '1991-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '340-360 (343, 345)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1979-08-01',
"valjalaske_lopp" = '1991-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '340-360 sedan (344)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-08-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '440 K (445)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-09-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '460 L (464)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-04-01',
"valjalaske_lopp" = '1996-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '480 E' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-10-01',
"valjalaske_lopp" = '1979-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '66 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1975-08-01',
"valjalaske_lopp" = '1978-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '66' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1983-08-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '740 (744)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '740 Break (745)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1985-08-01',
"valjalaske_lopp" = '1992-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '740 Kombi (745)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1981-08-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '760 (704, 764)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '760 Break (704, 765)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1982-01-01',
"valjalaske_lopp" = '1992-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '760 Kombi (704, 765)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1986-08-01',
"valjalaske_lopp" = '1990-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '780' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1991-06-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '850 (LS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1992-04-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '850 universal (LW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1994-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 (944)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1995-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 Break (945)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 II (944)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 II universal (945)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1995-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 Kombi (945)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 Mk II (944)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-08-01',
"valjalaske_lopp" = '1998-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '940 Mk II universal (945)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 (964)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 Break (965)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 II (964)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 II universal (965)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1990-08-01',
"valjalaske_lopp" = '1994-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 Kombi (965)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 Mk II (964)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1994-07-01',
"valjalaske_lopp" = '1996-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = '960 Mk II universal (965)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'C70 cabrio' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-03-01',
"valjalaske_lopp" = '2002-09-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'C70 coupe' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-08-01',
"valjalaske_lopp" = '1967-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'DUETT' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-05-01',
"valjalaske_lopp" = '1971-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'P 121' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-05-01',
"valjalaske_lopp" = '1971-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'P 122 S AMAZON universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1959-05-01',
"valjalaske_lopp" = '1971-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'P 122 S AMAZON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1962-04-01',
"valjalaske_lopp" = '1973-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'P 1800' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1964-09-01',
"valjalaske_lopp" = '1967-08-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'P 2200 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1960-05-01',
"valjalaske_lopp" = '1967-07-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'P 544' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = '2003-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'S40 (VS)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'S40' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-11-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'S60' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2000-11-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'S70' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1998-05-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'S80' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '1998-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'S90' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1995-07-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V40 universal (VW)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2004-04-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V50' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V70 I universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V70 II universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-03-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V70 Mk II' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V70 XC' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '2000-03-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V70' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = '1998-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'V90 universal' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2002-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'XC 90' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '2000-09-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='VOLVO' )
AND "mudel" = 'XC70 CROSS COUNTRY' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1991-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WARTBURG' )
AND "mudel" = '353 Break' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1967-10-01',
"valjalaske_lopp" = '1991-05-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WARTBURG' )
AND "mudel" = '353 Tourist' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1966-06-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WARTBURG' )
AND "mudel" = '353' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1997-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WESTFIELD' )
AND "mudel" = '130 Roadster' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = '1997-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WESTFIELD' )
AND "mudel" = 'ZE' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1996-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WIESMANN' )
AND "mudel" = 'ROADSTER' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1973-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WOLSELEY' )
AND "mudel" = '1300' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1971-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WOLSELEY' )
AND "mudel" = '16/60' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1969-08-01',
"valjalaske_lopp" = '1972-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WOLSELEY' )
AND "mudel" = '18/85' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1961-01-01',
"valjalaske_lopp" = '1970-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WOLSELEY' )
AND "mudel" = 'HORNET' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-01-01',
"valjalaske_lopp" = '1975-10-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='WOLSELEY' )
AND "mudel" = 'SIX' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='YULON' )
AND "mudel" = '101 Feeling' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1993-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='YULON' )
AND "mudel" = 'YULON' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1972-06-01',
"valjalaske_lopp" = '1993-12-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ZASTAVA' )
AND "mudel" = '101 (1100)' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1988-10-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ZASTAVA' )
AND "mudel" = 'YUGO FLORIDA' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1980-04-01',
"valjalaske_lopp" = '1995-06-01'
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ZASTAVA' )
AND "mudel" = 'YUGO' ;
            
UPDATE "shop_auto_mudel"
SET 
"valjalaske_algus" = '1989-01-01',
"valjalaske_lopp" = NULL
WHERE "auto_mark_id" = ( SELECT DISTINCT id FROM  "shop_auto_mark" WHERE mark='ZAZ' )
AND "mudel" = 'TAVRIJA' ;
            