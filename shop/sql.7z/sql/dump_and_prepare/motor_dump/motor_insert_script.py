#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on Apr 12, 2012

@author: deko
'''
import os
from prepare_make_model_queries import get_uniq_lines
from make_model_date_insert_query import get_filtered_rows
from make_model_date_insert_query import get_parsed_dates

def get_modified_dates(rows):
    return [ [row[0],
              row[1],
              row[2],
              row[3],              
              get_parsed_dates(row[4]),
              row[5],
              row[6],
              row[7],] for row in rows]


def make_motor_query(motorData):
    resultQuery = ''
    
    for row in motorData:
        make = row[0]
        model = row[1]
        motorName = row[2]
        motorCode = row[3]
        startDate = row[4]['startDate']
        endDate = row[4]['endDate']
        volume = row[5]
        horsePower = row[6]
        kwPower = row[7]
        if startDate is None:
            startDate = 'NULL'
        else:
            startDate = '\'' + startDate.isoformat() + '\''
            
        if endDate is None:
            endDate = 'NULL'
        else:
            endDate = '\'' + endDate.isoformat() + '\''
        
            
        if not volume:
            volume = '0'
        if not horsePower:
            horsePower = '0'
        if not kwPower:
            kwPower = '0'
            
        resultQuery += (
#"""
#INSERT INTO "shop_mootor" ("nimetus","mootori_tyyp", "kubatuur_cm3", "voimsus_kw") 
#VALUES (\'{motorName}\', \'{motorCode}\', \'{volume}\', \'{kwPower}\');             
#""".format(motorName=motorName,
#           motorCode=motorCode,
#                  volume=volume,
#                  kwPower=kwPower))
#        
"""
INSERT INTO "shop_mootor" ("nimetus","mootori_tyyp", "kubatuur_cm3", "voimsus_kw") 
SELECT \'{motorName}\' AS nimetus,
 \'{motorCode}\' AS mootori_tyyp,
 \'{volume}\' AS kubatuur_cm3,
 \'{kwPower}\' AS voimsus_kw
WHERE NOT EXISTS
(SELECT NULL FROM "shop_mootor"
WHERE
nimetus=\'{motorName}\' AND
mootori_tyyp=\'{motorCode}\' AND
kubatuur_cm3=\'{volume}\' AND
voimsus_kw=\'{kwPower}\'
);
""".format(motorName=motorName,
           motorCode=motorCode,
                  volume=volume,
                  kwPower=kwPower))                       
    return resultQuery


def make_motor_omamine_query(motorData):
    resultQuery = ''
    
    for row in motorData:
        make = row[0]
        model = row[1]
        motorName = row[2]
        motorCode = row[3]
        startDate = row[4]['startDate']
        endDate = row[4]['endDate']
        volume = row[5]
        horsePower = row[6]
        kwPower = row[7]
        if startDate is None:
            startDate = 'NULL'
        else:
            startDate = '\'' + startDate.isoformat() + '\''
            
        if endDate is None:
            endDate = 'NULL'
        else:
            endDate = '\'' + endDate.isoformat() + '\''
        
            
        if not volume:
            volume = '0'
        if not horsePower:
            horsePower = '0'
        if not kwPower:
            kwPower = '0'
            
        resultQuery += (
"""
INSERT INTO "shop_mootori_omamine" ("auto_mark_id", "auto_mudel_id", "mootor_id")
SELECT  
(
SELECT id 
FROM "shop_auto_mark"
WHERE mark=\'{make}\'
),
(
SELECT id 
FROM "shop_auto_mudel"
WHERE mudel=\'{model}\' and auto_mark_id=( SELECT id FROM "shop_auto_mark" WHERE mark=\'{make}\')
),
(
SELECT id
FROM "shop_mootor"
WHERE 
nimetus=\'{motorName}\' AND
mootori_tyyp=\'{motorCode}\' AND
kubatuur_cm3=\'{volume}\' AND
voimsus_kw=\'{kwPower}\'
)
WHERE NOT EXISTS (
SELECT NULL
FROM "shop_mootori_omamine"
WHERE
"auto_mark_id" = (SELECT id FROM "shop_auto_mark" WHERE mark=\'{make}\') AND
"auto_mudel_id" = (SELECT id FROM "shop_auto_mudel" WHERE mudel=\'{model}\' and auto_mark_id=( SELECT id FROM "shop_auto_mark" WHERE mark=\'{make}\')) AND
"mootor_id" = (SELECT id FROM "shop_mootor" WHERE nimetus=\'{motorName}\' AND mootori_tyyp=\'{motorCode}\' AND kubatuur_cm3=\'{volume}\' AND voimsus_kw=\'{kwPower}\')
);
""".format(motorName=motorName,
           motorCode=motorCode,
                  volume=volume,
                  kwPower=kwPower,
                  make=make,
                  model=model))                                       
                        
    return resultQuery 


if __name__ == '__main__':
    filename = os.path.join(os.path.dirname(__file__), 'motor_temp_info.csv')
    tempName = os.path.join(os.path.dirname(__file__), 't2.csv')
    get_uniq_lines(filename, tempName)  
    
        
    rows = get_filtered_rows(tempName)
    # skip first line with headers
    motorData = get_modified_dates(rows[1:])
    motorQuery = make_motor_query(motorData)
    
    motoriOmamineQuery = make_motor_omamine_query(motorData)
    
    #print rows
    
    filename = os.path.join(os.path.dirname(__file__), 'motor_insert.sql')
    with open(filename,'w') as queryFile:
        queryFile.write(motorQuery)
    
    filename = os.path.join(os.path.dirname(__file__), 'mootori_omamine_insert.sql')
    with open(filename,'w') as queryFile:
        queryFile.write(motoriOmamineQuery)
           
    os.remove(tempName)