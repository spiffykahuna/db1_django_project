#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on Apr 7, 2012

@author: deko
'''
import os

from UnicodeCsvReaderWriter import UnicodeDictReader
from UnicodeCsvReaderWriter import UnicodeDictWriter
import re


carDict = {
                       u'купе': u'coupe',
                       u'автобус': u'bus',
                       u'фургон': u'truck',
                       u'седан': u'sedan',
                       u'CITROЛN': u'CITROEN',                       
                       u'универсал': u'universal',
                       u'Хетчбек': u'hatchback',
                       u'кабрио': u'cabrio',                       
                       }

def get_uniq_lines(infilename, outfilename=None):
    """
        Function reads one file and writes to another if file to write
        is specified
        all dublicated lines are eliminated
        @param infilename: input file name
        @param outfilename: output file name, if 
        
        @return: set of unique lines
    """
    lines_seen = set() # holds lines already seen
    if outfilename:
        with open(outfilename, "w") as outfile:
            with open(infilename, "r") as infile:
                for line in infile:
                    if line not in lines_seen: # not a duplicate                    
                        outfile.write(line)
                        lines_seen.add(line)
    else:
        with open(infilename, "r") as infile:
                for line in infile:
                    if line not in lines_seen: # not a duplicate
                        lines_seen.add(line)
        
    return sorted(lines_seen)
    

def main():
    filename = os.path.join(os.path.dirname(__file__), 'motor_temp_info.csv')
    #uniqLines = get_uniq_lines(filename)
    #make;model;modi;dvig;vypusk;cm3;horse;kw
    #Maрка;Модель;Модификация;Двигатель;Дата выпуска;куб.см.;л.с.;кВт
    fields = ['Maрка', 'Модель', 'Модификация','Двигатель', 'кВт']
    with open(filename) as csv_file:
        temp = os.path.join(os.path.dirname(__file__), 'temp.csv')
        with open(temp,'w') as out:
            #csv_file.readline()
            
            reader = UnicodeDictReader(csv_file,delimiter=';')            
            writer = UnicodeDictWriter(out, fieldnames=reader.fieldnames[:2] )
            
            writer.writeheader()
            #writer.writerows(reader)
            
#            for row in reader:
#                rows.append( row)
#            t = rows[:10]

                            
            for row in reader:                
                for key, value in row.iteritems():                   
                    
                    for i in range(10):
                        for word in carDict.keys():
                            if word in value:
                                row[key] = value.replace(word, carDict[word])
                        value = row[key]
                            
                    # remove whitespaces and non-breaking
                    pattern = re.compile(r'\xa0')  # 160 ascii symbol (&nbsp;)
                    row[key] = re.sub(pattern, ' ',row[key])                    
                    pattern = re.compile(r'\s+')
                    row[key] = re.sub(pattern, ' ',row[key])
                    pattern = re.compile('\'') # single quotes in sql
                    row[key] = re.sub(pattern, '\'\'',row[key])                    
                                                              
                    
                writer.writerow(row)
    # remove repeated lines
    temp = os.path.join(os.path.dirname(__file__), 'temp.csv')
    temp1 = os.path.join(os.path.dirname(__file__), 'temp1.csv')    
    get_uniq_lines(temp, temp1)
    os.remove(temp)
    os.rename(temp1, temp)
                    
    
#    uniqLines = []
#    filename = os.path.join(os.path.dirname(__file__), 'temp.csv')
#    with open(filename,'w') as tempFile: 
#        #writer = csv.writer(tempFile, delimiter=';')
#        #writer.writerows(uniq)
#        #writer = UnicodeCsvWriter(tempFile, delimiter=';')
#        for line in uniqLines:
#            if not line == '\n':            
#                tempFile.write(line)  
#        


if __name__ == '__main__':
    main()    