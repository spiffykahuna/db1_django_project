﻿TRUNCATE shop_auto_mark CASCADE;
ALTER TABLE shop_auto_mudel DROP CONSTRAINT shop_auto_mudel_mudel_key

ALTER TABLE shop_auto_mudel ALTER "mudel" TYPE character varying(100);
ALTER TABLE shop_auto_mudel ADD CONSTRAINT shop_auto_mudel_unique UNIQUE("auto_mark_id","mudel");
            

SELECT *
FROM shop_auto_mudel
WHERE mudel LIKE '%(8C, B4)%';


INSERT INTO "shop_auto_mark" ("mark") VALUES  ('AC');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ACURA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ALFA ROMEO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ALPINA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ALPINE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ARO INTREPRINDEREA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ASIA MOTORS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ASTON MARTIN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('AUDI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('AUSTIN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('AUSTIN-HEALEY');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('AUTO UNION');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('AUTOBIANCHI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BARKAS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BEDFORD');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BENTLEY');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BERTONE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BITTER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BMW');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BOND');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BORGWARD');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BRISTOL');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BUGATTI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('BUICK');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CADILLAC');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CALLAWAY');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CARBODIES');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CATERHAM');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CHECKER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CHEVROLET');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CHRYSLER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('CITROEN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DACIA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DAEWOO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DAF');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DAIHATSU');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DAIMLER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DALLAS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DE LOREAN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DE TOMASO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('DODGE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('FERRARI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('FIAT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('FORD');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('FORD USA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('FSO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('GEO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('GINETTA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('GLAS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HINDUSTAN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HOBBYCAR');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HOLDEN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HONDA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HUMMER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('HYUNDAI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('INDIGO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('INFINITI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('INNOCENTI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('IRMSCHER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ISDERA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ISH');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ISUZU');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('JAGUAR');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('JEEP');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('JENSEN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('KIA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LADA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LAMBORGHINI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LANCIA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LAND ROVER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LDV INTERNATIONAL');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LEXUS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LIGIER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LINCOLN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('LOTUS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MAHINDRA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MARCOS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MARUTI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MASERATI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MAYBACH');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MAZDA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MCLAREN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MEGA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MERCEDES BENZ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MG');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MIDDLEBRIDGE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MINI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MITSUBISHI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MORGAN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MORRIS');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('MOSKVICH');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('NISSAN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('NSU');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('OLDSMOBILE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('OLTCIT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('OPEL');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('OSCA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('OTOSAN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PANOZ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PANTHER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PAYKAN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PEUGEOT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PIAGGIO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PLYMOUTH');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PONTIAC');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PORSCHE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PREMIER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PROTON');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('PUCH (STEYR-DAIMLER-PUCH)');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('RANGER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('RAYTON FISSORE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('RELIANT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('RENAULT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('RILEY');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ROLLS-ROYCE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ROVER');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SAAB');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SEAT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SHELBY');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SIPANI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SKODA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SMART (MCC)');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SPECTRE');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SSANGYONG');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('STANDARD');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SUBARU');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('SUZUKI');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TALBOT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TATA (TELCO)');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TOYOTA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TRABANT');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TRIUMPH');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('TVR');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('UAZ');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('UMM');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('VAUXHALL');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('VECTOR');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('VOLKSWAGEN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('VOLVO');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('WARTBURG');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('WESTFIELD');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('WIESMANN');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('WOLSELEY');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('YULON');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ZASTAVA');
INSERT INTO "shop_auto_mark" ("mark") VALUES  ('ZAZ');

INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ME', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('428 Fastback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('428 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACECA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COBRA Mk IV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTEGRA sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTEGRA hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTEGRA coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Legend II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND II coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSX тарга', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ACURA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('145 (930)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('155 (167)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('164 (164)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPIDER (105)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('33 (905)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPIDER (115)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('33 (907A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('33 Sportwagon (905A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('33 Sport Wagon (907B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6 (119)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75 (162B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90 (162)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALFASUD (901)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALFASUD Giardinetta (904)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALFASUD Sprint (902.A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALFETTA GT (116)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALFETTA (116)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GIULIA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARNA (920)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GIULIETTA (116)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('146 (930)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GTV (916C_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPIDER (916S_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1750-2000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTREAL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('156 (932)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GTV (116)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SZ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RZ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GIULIA GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AR 6 bus (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AR 6 truck (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AR 8 truck (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AR 8 c бортовой платформой/ходовая часть (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('166 (936)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GTA coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('156 Sportwagon (932)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('147 (937)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALFA ROMEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C1 (E21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C1 (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C2 (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C2 cabrio (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 Touring (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 cabrio (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 Touring (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 coupe (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 cabrio (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B6 (E21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B6 (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B6 (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B7 (E12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B7 (E28)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B7 coupe (E24)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B8 (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B8 Touring (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B8 coupe (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B8 cabrio (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B9 (E28)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B9 coupe (E24)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B10 (E34)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B10 Touring (E34)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B10 (E39)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B10 Touring (E39)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B11 (E32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B12 (E32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B12 (E38)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B12 coupe (E31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RLE Roadster (Z1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('D10 (E39)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('D10 Touring (E39)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 coupe (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 Touring (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B3 cabrio (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER (Z8)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B7 (E65)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER S (Z4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A310', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BERLINETTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A610', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ALPINE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('240-244', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ARO INTREPRINDEREA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('10', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ARO INTREPRINDEREA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPARTANA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ARO INTREPRINDEREA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROCSTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASIA MOTORS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HI-TOPIC (AM 725)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASIA MOTORS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BULLDOG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB6 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB6 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DBS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAGONDA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAGONDA universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TICKFORD CAPRI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V8 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V8 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZAGATO coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZAGATO cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIRAGE coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIRAGE universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIRAGE Saloon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIRAGE LIMITED EDITI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB7 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB7 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIRAGE cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANQUISH', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB9 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DB9 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ASTON MARTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80 "(8C, B4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80 (8C, B4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80 Avant (8C, B4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 (43, C2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 (44, 44Q, C3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80 (80, 82, B1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 (4A, C4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 Avant (43, C2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80 (81, 85, B2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 Avant (44, 44Q, C3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('80 (89, 89Q, 8A, B3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 Avant (4A, C4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 coupe (C1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 (C1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90 (81, 85, B2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90 (89, 89Q, 8A, B3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 (43)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 (44, 44Q)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (81, 85)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (89, 8B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A4 (8D2, B5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A6 (4A, C4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A8 (4D2, 4D8)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('50 (86)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CABRIOLET (8G7, B4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V8 (D1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSU RO 80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('60', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('60 Variant', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A3 (8L1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A6 (4B, C5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 Avant (44, 44Q)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A6 Avant (4B, C5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A6 Avant (4A, C4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A4 Avant (8D5, B5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TT (8N3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QUATTRO (85)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TT Roadster (8N9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A2 (8Z0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75 Variant', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90 Super', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALLROAD (4BH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A4 (8E2, B6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A4 Avant (8E5, B6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A4 cabrio (8H7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A8 (4E_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A3 (8P1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A6 (4F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A3 Sportback (8PA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUDI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1000-Series MK II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAESTRO (XC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAXI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('METRO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI MK I', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEGO (XE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEGO universal (XE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALLEGRO (ADO 67)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRINCESS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALLEGRO universal (ADO 67)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AMBASSADOR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRINCESS 2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('APACHE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAXI II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AUSTIN-HEALEY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUSTIN-HEALEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MUNGA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW F10', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW F11', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW F12', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW F102', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW MEISTERKLASSE F', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW MEISTERKLASSE Universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW SONDERKLASSE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW SONDERKLASSE Universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW SONDERKLASSE F Universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AU 1000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AUDI N', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AUDI N Variant', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AUDI 80 L', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AUDI SUPER 90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AU 1000 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW SONDERKLASSE F', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DKW F12 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTO UNION' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A 111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTOBIANCHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A 112', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTOBIANCHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Y10', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='AUTOBIANCHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B 1000 bus (KB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BARKAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B 1000 truck (KM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BARKAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B 1000 bus (KO)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BARKAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BEDFORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHEVANNE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BEDFORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BEDFORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RASCAL bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BEDFORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RASCAL truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BEDFORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLITZ (CF97)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BEDFORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARNAGE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BENTLEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARNAGE Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BENTLEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AZURE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BENTLEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONTINENTAL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BENTLEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONTINENTAL GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BENTLEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FREECLIMBER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BERTONE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FREECLIMBER Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BERTONE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TYPE 3 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BITTER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('8 (E31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('02 (E10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500-2000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2500-3.3 (E3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2000-3.2 coupe (E9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 (E21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 Touring (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 Compact (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 coupe (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 cabrio (E30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 cabrio (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 (E28)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 (E12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 Touring (E34)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 (E34)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6 (E24)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7 (E23)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7 (E32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7 (E38)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 Touring (E36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISETTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 (E39)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('02 Touring (E6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('02 cabrio (E10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1600 GT coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2.6- 3200 V8 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('501', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 Touring (E39)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('700', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z3 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('503 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 coupe (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 Touring (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 cabrio (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 Compact (E46)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('700 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('7 (E65, E66)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Z4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 (E60)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 Touring', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1 (E87)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BMW' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EQUIPE coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BOND' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EQUIPE Mk. II coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BOND' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EQUIPE Mk. II cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BOND' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISABELLA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BORGWARD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('411', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BRISTOL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EB 110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BUGATTI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EB 16.4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BUGATTI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SKYLARK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BUICK' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CENTURY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BUICK' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PARK AVENUE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BUICK' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LE SABRE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='BUICK' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEVILLE Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCALADE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EVOQ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEVILLE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELDORADO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XLR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CADILLAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C12 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CALLAWAY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C12 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CALLAWAY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FL2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CARBODIES' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CARBODIES' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX FAIRWAY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CARBODIES' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX4R', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CARBODIES' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FX4S', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CARBODIES' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TX1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CARBODIES' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CATERHAM' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPER SEVEN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CATERHAM' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARATHON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHECKER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARATHON Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHECKER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAXICAB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHECKER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANS SPORT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LUMINA APV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLAZER ''94', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORVETTE ґ97', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BERETTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSICA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMARO ''70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMARO ''81', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMARO ґ92', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPRICE ''70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPRICE ''83', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORVETTE ''83', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MALIBU ''69', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTE CARLO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLAZER S ''82', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORVETTE ґ97 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMARO ґ98', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMARO ґ98 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPALA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALERO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAHOE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAILBLAZER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORVETTE (C06)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHEVROLET' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VOYAGER Mk III (RG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LE BARON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LE BARON cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VISION', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEON (PL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEW YORKER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VOYAGER Mk II (GS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STRATUS (JA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STRATUS cabrio (JX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS DAYTONA SHELBY coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SARATOGA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VOYAGER (ES)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300 M (LR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIPER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIPER Convertible', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEON Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PT CRUISER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEBRING (JR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEBRING cabrio (JR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CROSSFIRE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PT CRUISER cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300 C', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CROSSFIRE Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CHRYSLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RELAY bus (230P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XANTIA (X1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XM (Y3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XM Break (Y3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZX (N2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2 CV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LNA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CX universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CX Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DYANE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SYNERGIE (22, U6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AX (ZA-_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BX (XB-_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BX Break (XB-_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C15 (VD-_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C25 bus (280_, 290_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VISA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XANTIA Break (X1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAXO (S0, S1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DISPATCH (U6U)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BERLINGO truck (M_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BERLINGO (MF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DS Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ID', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ID Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AMI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AMI Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XSARA (N1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XSARA Break (N2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RELAY truck (230L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XM (Y4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XANTIA (X2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XANTIA Break (X2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XSARA coupe (N0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZX Break (N2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OLTCIT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C25 truck (280_, 290_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C25 c бортовой платформой/ходовая часть (280_, 290_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CX Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XM Break (Y4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RELAY c бортовой платформой/ходовая часть (230)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XSARA PICASSO (N68)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACADIANE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DS cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ID cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEHARI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DISPATCH truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DISPATCH c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VISA cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C5 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JUMPER bus (244, Z_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JUMPER truck (244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JUMPER c бортовой платформой/ходовая часть (244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C35 bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C35 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C3 Pluriel', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='CITROEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DACIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1310', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DACIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DACIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1310 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DACIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPERO (KLEJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEXIA (KLETN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEXIA sedan (KLETN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TICO (KLY3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANOS sedan (KLAT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NUBIRA (KLAJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NUBIRA Break (KLAJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGANZA (KLAV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANOS (KLAT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NUBIRA sedan (KLAJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MATIZ (KLYA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LUBLIN II truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LUBLIN II c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MUSSO (FJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KORANDO (KJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KORANDO Cabrio (KJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TACUMA (KLAU)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REXTON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KALOS (KLAS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EVANDA (KLAL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NUBIRA sedan (KLAN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LACETTI (KLAN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAEWOO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('33', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('44', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('44 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('55', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('55 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('55 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('46', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('46 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('66 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('66 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400-Serie truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('66', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAF' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARADE Mk II (G11, G30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIRA Mk III (L201)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPORTRAK (F300)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FOURTRAK (F7, F8)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARMANT (A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARADE Mk IV (G200, G202)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIRA (L55, L60)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('APPLAUSE (A101, A111)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARADE Mk III (G100, G101, G102)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARADE (G10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CUORE IV (L501)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRAN MOVE (G3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVE (L6, L9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CUORE V (L5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VALERA IV sedan (G203)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WILDCAT/ROCKY (F75)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERIOS (J1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIRA Mk II (L80, L81)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIJET Mk II bus (S85)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIJET Mk II truck (S85)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIRION (M1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WILDCAT/ROCKY (F70)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CUORE Mk VI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('APPLAUSE Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAFT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPARCAR truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPARCAR bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIJET bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIJET truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YRV (M2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CUORE VII', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARADE III sedan (G102)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COPEN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Atrai bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIHATSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2.8 - 5.3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIMLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANDAULETTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIMLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DAIMLER (X300)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIMLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJ 40, 81', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIMLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIMLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LIMOUSINE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DAIMLER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FUN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DALLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DMC-12', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE LOREAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BIGUA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEAUVILLE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GUARA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GUARA Barchetta', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LONGCHAMP', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LONGCHAMP cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PANTERA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DE TOMASO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DODGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEON II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DODGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STRATUS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DODGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARAVAN II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DODGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARAVAN III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DODGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIPER cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='DODGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('360 MODENA Spider (F131)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('208/308', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('456 GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('512 TR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('512 M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TESTAROSSA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F40', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDIAL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('328 GTB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DINO GT (206/246)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('412 i', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('348 TB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('365 GT 2+2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F355 BERLINETTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('512 BB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DINO GT4 (208/308)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5__ MARANELLO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DINO GTS (206/246)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDIAL cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('328 GTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('365 GTS/4 DAYTONA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F355 GTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('348 TS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('365 GTB/4 DAYTONA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('360 MODENA (F131)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('550 BARCHETTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('612 SCAGLIETTI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ENZO FERRARI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FERRARI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CINQUECENTO (170)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REGATA (138)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REGATA Weekend', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X 1/9 (128 AS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RITMO Bertone cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RITMO (138A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('124 Spider', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('126', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('127', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('128 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('128', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('131', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('131 Familiare/Panorama', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CROMA (154)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO truck (230L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARGENTA (132A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TEMPRA (159)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TEMPRA SW (159)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PANDA (141A_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TIPO (160)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIORINO (127)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIORINO truck (146 Uno)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIORINO (147)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PUNTO (176)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PUNTO cabrio (176C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ULYSSE (220)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('UNO (146A/E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('238-SERIE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('242-SERIE truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BARCHETTA (183)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RITMO Mk II (138A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BRAVA (182)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BRAVO (182)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCUDO Combinato (220P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAREA (185)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAREA Weekend (185)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO truck (290)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('124', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('124 Familiare', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('124 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('128 Familiare', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('130', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('130 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850 Spider', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1000er-Serie', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('125', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('127 Panorama', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('135 DINO coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('135 DINO Spider', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('500 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JAGST', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO Panorama (290)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO bus (230)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO truck (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500-2300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PALIO (178BX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PALIO Weekend (178DX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PUNTO Van (176L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEICENTO (187)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUNA (146 B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUNA Weekend (146 B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (FA/175)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO c бортовой платформой/ходовая часть (290)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('132', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO Panorama (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MULTIPLA (186)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCUDO truck (220L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO c бортовой платформой/ходовая часть (230)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STRADA (178E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PUNTO (188)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('242-SERIE bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIORINO Pick up (146)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIORINO Pick up (147)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO c бортовой платформой/ходовая часть (280)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 T/E Pulmino', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 T/E Panorama', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPAZIO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('147 Panorama', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMPAGNOLA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PANDA Van', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELBA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIENA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PREMIO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DOBLO (223)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DOBLO Cargo (223)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PUNTO Van (188AX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TALENTO truck (290)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TALENTO c бортовой платформой/ходовая часть (290)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TALENTO bus (290)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STILO (192)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO bus (244, Z_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO truck (244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEICENTO Van (187)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUCATO c бортовой платформой/ходовая часть (244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ULYSSE (179AX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STILO Multi Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PANDA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IDEA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FIAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA (GGTL, GGFL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA Mk III (GAE, GGE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA Mk III sedan (GGE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIERRA hatchback (GBC, GBG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIERRA (GBG, GB4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIERRA hatchback (GBC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIERRA Break (BNC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIERRA universal (BNG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO (GBP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO universal (BNP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT (AFH, ATH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk II (ATH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk III (GAA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk III cabrio (ALD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk III universal (AWA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk IV (GAF, AWF, ABFT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA ''80 (GBS, GBNS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk IV universal (AWF, AVF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA (GBTK)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk V (GAL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA (GBTS, GBFS, CBTS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA Estate universal (GBNS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk V universal (GAL, AVL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA Estate ''80 universal (GBNS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VI cabrio (ALL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VI (GAL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ORION (AFD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VI sedan (GAL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ORION Mk II (AFF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VI universal (GAL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ORION Mk III (GAL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA Mk II (FBD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA Mk III (GFJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT bus (72E, 73E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT bus (T_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPRI (ECJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPRI Mk II (GECP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA (GU)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA Break (GNU)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ECONOVAN (KBA, KCA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAVERICK (UDS, UNS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCORPIO Mk II (GFR, GGR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCORPIO Mk II universal (GNR, GGR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALAXY (VX, VY)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VII (GAL, AAL, ABL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VII sedan (GAL, AFL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VII universal (GAL, ANL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk VII cabrio (ALL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA Mk IV (JA_, JB_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT bus (E_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA Courier (J5_, J3_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KA (RB_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO Mk II (BAP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO Mk II universal (BNP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT ''86 Courrier (AVF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT ''91 Courrier (AVL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT ''95 truck (AVL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT ''81 Courrier (AVA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT universal (ADH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS ''51', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M (P4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M coupe (P4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M Turnier (P4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M (11G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M (12G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M coupe (13G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M (21G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M (22G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M coupe (23G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M (29G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M Turnier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M (P3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M coupe (P3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M (21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M (31F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M (32F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M coupe (33F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M Turnier (35F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M Turnier (36F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M Turnier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M (41F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M (42F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M coupe (43F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M XL (52F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M XL coupe (53F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 26M XL (52F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 26M XL coupe (53F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA Coach coupe (GBCK)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA Estate universal (GBNK)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONSUL (GGFL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONSUL coupe (GGCL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONSUL Turnier (GGNL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA coupe (GGCL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA Break (GGNL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT ''55- bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT bus (V_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT truck (72E, 71E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT truck (81E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT truck (T_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT truck (E_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT ''55- truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT truck (V_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT c бортовой платформой/ходовая часть (T_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT c бортовой платформой/ходовая часть (V_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT c бортовой платформой/ходовая часть (E_ _)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA truck (WFVT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA truck (FVD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk IV cabrio (ALF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANADA I universal (GGE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO sedan (GBP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA Courier (F3L, F5L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO Mk II sedan (BFP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M Turnier (15G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M Turnier (P3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M XL (51F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA (GBFK)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUGAR (EC_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 12M Turnier', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FOCUS (DAW, DBW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FOCUS Clipper (DNW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FOCUS sedan (DFW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPRI Mk III (GECP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT Mk V cabrio (ALL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PUMA (EC_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M Turnier (25G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 15M (28G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 17M Turnier (21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS 20M Turnier (46F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA truck (JV_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ECONOVAN truck (KAA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT c бортовой платформой/ходовая часть (74E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RANGER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 100 Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 100', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT bus (FD_Y, FB_Y, FS_Y, FZ_Y, FC_Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT truck (FA_Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT c бортовой платформой/ходовая часть (FM_Y, FN_Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAVERICK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSAIR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSAIR Estate universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA Coach', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORTINA Estate universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZODIAC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT CLASSIC (AAL, ABL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESCORT CLASSIC Turnier (ANL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZODIAK Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZEPHYR Mk III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZEPHYR Mk III universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZEPHYR IV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZEPHYR Mk IV universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO Mk III sedan (B4Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO Mk III (B5Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONDEO Mk III universal (BWY)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIESTA V (JH_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FUSION (JU_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOURNEO CONNECT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STREET KA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSIT CONNECT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FOCUS C-MAX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MUSTANG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MUSTANG Convertible', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAURUS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAURUS Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WINDSTAR (A3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXPLORER (U2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PROBE Mk II (ECP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AEROSTAR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BRONCO Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PROBE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FORD USA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('125P', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('125P universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('126P', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('127P', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('132P', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLONEZ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMA II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLONEZ Mk III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLONEZ Mk III sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='FSO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('METRO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('METRO sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('METRO cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STORM coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STORM Kombi Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRACKER Cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRACKER Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GEO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G15', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G21', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G23', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G27', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G32', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G33', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G34', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G40', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GINETTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOGGOMOBIL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOGGOMOBIL coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISAR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISAR universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('04', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('04 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1700', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V 8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='GLAS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AMBASSADOR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HINDUSTAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONTESSA CLASSIC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HINDUSTAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSPORT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HOBBYCAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HOLDEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VT Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HOLDEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STATESMANN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HOLDEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC universal (WC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk IV (CB3, CB7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk III (CA4, CA5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk IV coupe (CC1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC universal (AN, AR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk III sedan (ED)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD hatchback (SJ, SY)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk II hatchback (AC, AD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk II (AC, AD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND coupe (KA3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND (HS, KA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk III hatchback (EC, ED, EE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRELUDE coupe (SN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRELUDE Mk II (AB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRX (AF, AS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRX Mk II (ED, EE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRELUDE Mk III (BA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSX coupe (NA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk V (CC7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk IV (EG, EH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD (SJ, SY)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND Mk II coupe (KA8)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JAZZ (AA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QUINTET (SU)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC hatchback (SB, SS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk II (AL, AJ, AG, AH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONCERTO (HW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk V universal (CE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD MK V coupe (CD7, CD9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk IV coupe (EJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk IV hatchback (MA, MB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk IV universal (CB8, CC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRELUDE Mk IV (BB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk II universal (EE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRX Mk III (EH, EG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHUTTLE (RA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk V hatchback (EJ9, EK1/3/4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk V (EJ9, EK3/4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk VI (CE, CF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND Mk III (KA9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('N III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk V hatchback (MB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CR-V I (RD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk III universal (CA5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NSX cabrio (NA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRELUDE Mk V (BB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk V universal (MC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC (SL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk VII (CG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGEND Mk II (KA7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC Mk IV hatchback (EG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk VII coupe (CG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S2000 (AP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTEGRA (DC2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HR-V (GH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LOGO (GA3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk VII universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONCERTO sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACTY TN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD Mk VII hatchback (CH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INSIGHT (ZE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC VI Hatchback (EU_, EP_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC VI coupe (EM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STREAM (RN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC VI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JAZZ (GD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CR-V Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTEGRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD VIII', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCORD VIII Tourer', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CIVIC V coupe (EJ6, EJ8)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTEGRA (DA_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HONDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HUMMER H1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HUMMER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HUMMER H2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HUMMER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXCEL (X-3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELANTRA I (J-1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONY (X-2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXCEL sedan (X-2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S COUPE (SLC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SONATA (Y-2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SONATA Mk II (Y-3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELANTRA II universal (J2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (RD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('H 150 bus (P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STAREX (H1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONY sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STELLAR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELANTRA II (J-2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ATOS (MX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SONATA Mk III (EF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXCEL sedan (X-3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('H 150 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONY Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXCEL (LC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('H 200 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('H 200 bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAJET (FO)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELANTRA sedan (XD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELANTRA (XD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIGHWAY VAN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALLOPER II (JK-01)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SANTA FЙ (SM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ATOS PRIME (MX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SANTAMO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MATRIX (FC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERRACAN (HP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SONATA MK IV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (GK)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GETZ (TB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCENT sedan (LC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALLOPER I', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='HYUNDAI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3000 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INDIGO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G20', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('I30', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J30', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M30 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M30 Convertible', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Q45', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QX4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INFINITI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INNOCENTI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELBA (146)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INNOCENTI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KORAL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='INNOCENTI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='IRMSCHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SENATOR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='IRMSCHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='IRMSCHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA Caravan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='IRMSCHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMENDATORE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISDERA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPERATOR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISDERA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ORBITA (2126)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ORBITA universal (21262)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TROOPER (UBS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GEMINI sedan (JT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GEMINI (JT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TROOPER Джип открытый (UBS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI Van (94000, 98000)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FASTER (KB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PIAZZA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI truck (98000N)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI bus (94000, 98000)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TROOPER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TROOPER (UB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TROOPER Джип открытый (UB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TROOPER Джип открытый', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ISUZU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJ (XJ 40, 81)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJ (X300)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJS coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJSC Convertible', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XK 8 coupe (QEV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XK 8 Convertible (QDV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-TYPE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-TYPE 2+2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-TYPE Convertible', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-TYPE (CCX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XJ (NAW, NBW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-TYPE (CF1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-TYPE Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JAGUAR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WRANGLER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WRANGLER Mk II (TJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHEROKEE (XJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRAND CHEROKEE (Z)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRAND CHEROKEE Mk II (WJ, WG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CJ5 - CJ8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LIBERTY (KJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JEEP' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HEALEY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTERCEPTOR Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTERCEPTOR MK III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTERCEPTOR SP', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTERCEPTOR S4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-V8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='JENSEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MENTOR sedan (FA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPORTAGE (K00)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIDE (DA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLARUS (K9A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MENTOR (FA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEPHIA (FB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLARUS universal (GC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BESTA truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PREGIO (TB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIDE universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEDONA (UP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RETONA (CE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JOICE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RIO universal (DC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARENS I (FC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RIO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OPTIMA (GD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHUMA II sedan (FB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHUMA II (FB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SEDONA Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SORENTO (JC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARENS Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OPIRUS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CERATO sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CERATO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PICANTO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('K2500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='KIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1200-1500 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1200-1600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NIVA (2121)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KALINKA (2105, 2108, 2109)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KALINKA universal (2104)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAMARA (2108, 2109)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DIVA (21099)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOSCANA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('112', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('111', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NADESCHDA (2120)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LADA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUNTACH', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DIABLO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DIABLO Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPADA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JALPA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JARAMA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LM-001', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LM-002', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIURA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('URRACO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MURCIЙLAGO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALLARDO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAMBORGHINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KAPPA (838A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A 112', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEDRA (835)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DELTA (831AB0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DELTA Mk II (836)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('THEMA (834)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('THEMA SW (834)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BETA H.P.E. (828BF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TREVI (828DB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRISMA (831AB0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZETA (220)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BETA coupe (828BC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BETA MONTE CARLO (137AS, 137BS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BETA Spider (828BS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GAMMA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FULVIA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GAMMA coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KAPPA SW (838B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KAPPA coupe (838)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEDRA SW (835)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Y10 (156)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('Y (840A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LYBRA (839AX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LYBRA SW (839BX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BETA (828_B_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('THESIS (841AX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PHEDRA (179)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YPSILON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LANCIA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RANGE ROVER Mk II (LP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RANGE ROVER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DISCOVERY Mk II (LJ, LT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DISCOVERY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEFENDER (LD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEFENDER Station Wagon (LD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90/110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('88/109', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('88/109 Hardtop', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FREELANDER Soft Top', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FREELANDER (LN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RANGE ROVER MK III (LM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEFENDER пикап', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LAND ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONVOY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CONVOY c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHERPA bus (AS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHERPA bus (FR)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LDV INTERNATIONAL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ES (F1, F2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS (JZS147)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS (GXE10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS (UCF10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX (XU1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GS (JZS160)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS (UCF20)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS (FE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IS SportCross', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LEXUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BE UP', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LIGIER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NOVA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LIGIER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AMBRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LIGIER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LINCOLN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELITE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ECLAT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPRIT S2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPRIT S3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXCEL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELAN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELISE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EUROPA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPRIT S4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELISE 340 R', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXIGE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='LOTUS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CJ 3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAHINDRA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CJ 3 Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAHINDRA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2-3 Litre', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LM cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTA RAY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTA RAY cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTIS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTIS cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARCOS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('UDYOG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MARUTI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('228', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('420/430', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BITURBO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BITURBO coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BITURBO Spider', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BORA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INDY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KARIF', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KHAMSIN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KYALAMI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MERAK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEXICO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QUATTROPORTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QUATTROPORTE Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHAMAL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GHIBLI Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GHIBLI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GHIBLI Spider', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3200 GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPYDER GT cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPYDER coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('QUATTROPORTE III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MASERATI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAYBACH (240_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAYBACH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EUNOS 500 (CA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MILLENIA (TA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('121 (DA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('121 Mk II (DB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('929 (LA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 7 (SA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('929 Mk II coupe (HB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 7 Mk II (FC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('929 Mk II (HB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 7 Mk III (FD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('929 Mk II universal (HV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('929 Mk III (HC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E 2000,2200 bus (SR1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 C Mk V (BA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 F Mk V (BA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 (FA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 universal (FA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MX-3 (EC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 Mk II (BD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MX-5 (NA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 Mk III hatchback (BF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MX-6 (GE6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 Mk III universal (BW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 Mk III (BF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 F Mk IV (BG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 C Mk IV (BG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 S Mk IV (BG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 S Mk V (BA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk IV (GE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 (CB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk II (GC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk III coupe (GD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk III universal (GV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk III (GD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk IV hatchback (GE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('121 Mk III (JASM, JBSM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MPV I (LV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk V (GF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk V hatchback (GF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E 2000,2200 truck (SR2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk V universal (GW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 Mk II hatchback (BD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk II hatchback (GC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MX-5 Mk II (NB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 S Mk VI (BJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 F/P Mk VI (BJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 P Mk V', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DEMIO (DW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('626 Mk III hatchback (GD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('616', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('818 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-SERIE (UN)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PREMACY (CP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MPV Mk II (LW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E 1600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-SERIE (UF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('323 P Mk VI (BJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRIBUTE (EP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ATENZA (GG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ATENZA hatchback (GG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ATENZA universal (GY)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-SERIE (PE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('B-SERIE (UD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RX 8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3 sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MAZDA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('F1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MCLAREN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MCLAREN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLUB', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MEGA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLUB II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MEGA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTE CARLO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MEGA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRACK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MEGA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (C123)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KOMBI Break (S123)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (C124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('sedan (W124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KOMBI Break (S124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS (W126)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS coupe (C126)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL (R129)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS coupe (C140)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS (W140)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('190 (W201)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-CLASS (W460)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-CLASS (W463)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CABRIOLET (A124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS (W124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS universal (S124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T1 bus (601)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-CLASS (W202)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS sedan (W108, W109)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HECKFLOSSE (W110)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 bus (631)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE (W111)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PAGODE (W113)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('/8 coupe (W114)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('/8 (W114)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('/8 (W115)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS (W116)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONTON (W120)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL (W121)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL (R107)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('sedan (W123)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 2-t c бортовой платформой/ходовая часть (901, 902)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS (W210)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITO bus (638)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-CLASS universal (S202)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS universal (S210)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK (R170)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('170 (W170)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T1 bus (602)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL (R198)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK (C208)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A-CLASS (W168)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HENSCHEL 2-t', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T1 truck (601)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T1 c бортовой платформой/ходовая часть (602)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-CLASS Джип открытый (W463)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 2-t truck (901, 902)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 2-t bus (901, 902)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 3-t bus (903)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 truck (631)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CABRIOLET (W111)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M-CLASS (W163)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL coupe (C107)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS coupe (C124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GULLWING (W198)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T1 c бортовой платформой/ходовая часть (601)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 3-t c бортовой платформой/ходовая часть (903)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK cabrio (A208)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS (W220)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HECKFLOSSE (W111)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONTON (W121)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONTON (W128)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PONTON (W180)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 3-t truck (903)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS cabrio (A124)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('T1 truck (602)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITO truck (638)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PULLMANN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-CLASS (W461)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V-CLASS (638/2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S-CLASS coupe (C215)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-CLASS (W203)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 4-t bus (904)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 4-t truck (904)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPRINTER 4-t c бортовой платформой/ходовая часть (904)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-CLASS Sportscoupe (CL203)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C-CLASS universal (S203)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SL (R230)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANEO (414)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 c бортовой платформой/ходовая часть (631)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS (W211)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK (C209)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('E-CLASS universal (S211)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLK cabrio (A209)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIANO (W639)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITO bus (W639)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITO truck (W639)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLK (R171)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLS (C219)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SLR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MERCEDES BENZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGB cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGB GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGR V8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDGET', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('METRO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAGNETTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAESTRO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300 Mk.II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEGO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGC GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGF (RD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MGTF', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MG ZR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MG ZS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MG ZS Hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MG ZT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MG ZT- T', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIMITAR GTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MIDDLEBRIDGE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI-MOKE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MINI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT (A15_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT Mk II (C1_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT Mk III (C5_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT Mk IV (CA_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT LANCER (A7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORDIA (A21_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 300 bus (LO3_P/G, L0_2P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 300 bus (P0_W, P1_W, P2_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER (A17_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk III (C1_A, C6_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk IV sedan (C6_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk V (CB/D_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAPPORO (A12_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAPPORO Mk II (A16_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAPPORO Mk III (E16A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3000 GT (Z16A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIGMA (F16A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPACE WAGON (D0_V/W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHARIOT (N3_W, N4_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARION (A18_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ECLIPSE (D2_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHOGUN (L04_G, L14_G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHOGUN Mk II (V2_W, V4_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT (A12_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT universal (A12_V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk II (A16_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk III (E1_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TREDIA (A21_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk IV sedan (E3_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk V (E5_A, E7_A, E8_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk V sedan (E5_A, E7_A, E8_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELESTE (A7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHOGUN Mk III (V60)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPACE GEAR (PA/B/D_V/W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk V universal (CB_W, CD_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ECLIPSE Mk II (D3_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARISMA (DA_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT Mk V (CJ_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk VI (CK/P_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 200 (K__T)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIGMA Break (F07W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARISMA sedan (DA_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 300 truck (L03_P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 300 truck (P0_W, P1_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk VI (EA_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk VI universal (EA_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHOGUN Mk II Джип открытый (L04_G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHOGUN Джип открытый (V2_W, V4_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT LANCER Station Wagon (A7_K)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk III universal (C1_V, C3_V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Mk IV (C6_A, C7_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk II universal (A16_V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALANT Mk IV (E3_A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER F Mk II (A17_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RVR (N1_W, N2_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPACE WAGON (N5_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 300 c бортовой платформой/ходовая часть (L03_P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 300 c бортовой платформой/ходовая часть (P1_T )', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHALLENGER (K90)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPACE STAR (DG0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GALLOPER (JK-01)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SANTAMO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IO (H6_W, H7_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPACE RUNNER (N50)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 400 bus (PAOV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('L 400 truck (PAOV)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PROUDIA/DIGNITY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PAJERO CLASSIC (V2_W)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OUTLANDER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LANCER Kombi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRANDIS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COLT VI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MITSUBISHI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FOUR FOUR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORGAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PLUS FOUR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORGAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PLUS EIGHT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORGAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AERO 8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORGAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ITAL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ITAL Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA II Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARINA III universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MORRIS' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASLK 2140', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('412', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASLK 2137 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21412', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('427 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('403', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('423 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('407', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2140', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='MOSKVICH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAUREL (JC32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MICRA (K10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY (140Y, 150Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAXIMA (J30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('280 ZX,ZXT (HGS130)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 SX (S13)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 NX (B13)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAUREL (HLC230)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHERRY (N12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAUREL (JC31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY (B11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk II (N13)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRAIRIE (M10, NM10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA (P10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD (T72 , T12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk II hatchback (N13)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD (U11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STANZA Hatchback (T11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD (910)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MICRA (K11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHERRY Traveller (VN10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Break (140Y, 150Y)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD Hatchback (T72, T12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD Break (WU11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD Traveller (W910)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk III hatchback (N14)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk II universal (B12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk II coupe (B12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERRANO (WD21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRAIRIE PRO (M11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHERRY coupe (N10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHERRY Hatchback (N10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('URVAN bus (E24)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA Hatchback (P10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA Break (W10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300 ZX (Z32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERRANO Mk II (R20)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATROL Station Wagon (W260)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATROL Station Wagon (W160)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SERENA (C23M)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANETTE bus (C22)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANETTE bus (KC120)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAXIMA QX (A32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STANZA (T11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALMERA hatchback (N15)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALMERA (N15)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SILVIA (S12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 100 A (E10, BLF10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 120', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 140 Y universal (HLB310)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIOLET (710, A10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 180 B (PL810)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 240 coupe (KMLGC210)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('URVAN bus (E23)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA (P11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA Hatchback (P11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SILVIA (S110)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATROL Hardtop (K160)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATROL Hardtop (K260)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 100 A universal (WBLF10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DATSUN 120 Y coupe (KB 210)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('URVAN truck (E23)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('300 ZX (Z31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY universal (B11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk III (N14)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY Mk III universal (Y10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PICK UP (D21)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANETTE CARGO truck (HC 23)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANETTE CARGO bus (HC 23)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA Break (WP11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATHFINDER (R50)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY coupe (B11)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATROL GR Mk II (Y61)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PICK UP (D22)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PATROL GR (Y60)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PICK UP (720)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('URVAN truck (E24)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNNY truck (Y10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIOLET', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD coupe (910)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BLUEBIRD (B610)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHERRY (E10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VANETTE truck (C22)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALMERA TINO (V10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 SX (S14)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALMERA Mk II (N16)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAXIMA QX (A33)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAXIMA Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-TRAIL (T30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA (P12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA Traveller (WP12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMERA Hatchback (P12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTERSTAR bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INTERSTAR truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMASTAR bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIMASTAR truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MICRA (K12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('350 Z', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KUBISTAR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NISSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRINZ', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1200', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPIDER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RO 80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='NSU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CUTLASS SUPREME', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OLDSMOBILE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('11', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OLTCIT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT B coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT C universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD C universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT C City', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD C coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT C coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD C', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMBO (71_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT C', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD D universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMODORE B coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD D coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMODORE B', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT D (31_-34_, 41_-44_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD D', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMODORE C universal (61)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT E (39_, 49_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD E universal (61_, 66_, 67_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT E cabrio (43B_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD E (17_-19_, 11_, 14_, 16_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT E universal (35_, 36_, 45_, 46_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT E hatchback (33_, 34_, 43_, 44_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA A TR (91_, 92_, 96_, 97_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA A hatchback (93_, 94_, 98_, 99_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA B (73_, 78_, 79_, F35_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SENATOR A (29_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SENATOR B (29_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTA A (58_, 59_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTA B (58_, 59_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MANTA B CC (53_, 55_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONZA A (22_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA A universal (66_, 67_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA A (16_, 17_, 19_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASCONA A (81_, 86_, 87_, 88_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA B universal (21_, 22_, 23_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASCONA B (81_, 86_, 87_, 88_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASCONA C (81_, 86_, 87_, 88_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASCONA C hatchback (84_, 89_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F (56_, 57_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F cabrio (53_B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F hatchback (53_, 54_, 58_, 59_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FRONTERA A Sport (5_SUD2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CALIBRA A (85_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA A (86_, 87_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT A coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ADMIRAL B', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DIPLOMAT A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DIPLOMAT A coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DIPLOMAT B', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT A universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASCONA A Voyage (84_, 89_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA B hatchback (38_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA B (36_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA B universal (31_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SINTRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OLYMPIA REKORD', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KAPITДN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OLYMPIA REKORD universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA A truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD B', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT E Combo (38_, 48_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMPO (TF_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA G hatchback (F48_, F08_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA G universal (F35_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT B', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMODORE C (14_, 19_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F universal (51_, 52_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT B universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT D universal (35_, 36_, 45_, 46_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FRONTERA A (5_MWL4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA B (25_, 26_, 27_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TIGRA (95_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ADMIRAL A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARENA truck (TB, TF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARENA Combi (THB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEREY B', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEREY A (UBS_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA A hatchback (88_, 89_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA G (F69_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FRONTERA B (6B_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO truck (F9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO c бортовой платформой/ходовая часть (U9, E9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO Combi (J9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F Van (55_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD P1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD P2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD P2 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD P2 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD A coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMODORE A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMMODORE A coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KADETT E truck (37_, 47_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD P1 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OLYMPIA A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OLYMPIA A coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD B universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD B coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZAFIRA (F75_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA G coupe (F07_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AGILA (H00)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO самосвал (H9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPEEDSTER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA G Delvan (F70)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA B truck (73_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA C (F08, F68)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F CLASSIC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F CLASSIC hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA F CLASSIC universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVARO truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVARO Combi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA G cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMBO truck/universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA C truck (F08, W5L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA C', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA C GTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MERIVA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIGNUM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMBO Tour', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA C universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA H', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA H universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TIGRA TwinTop', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OPEL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2500 GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OSCA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ANADOL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OTOSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ANADOL Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OTOSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAUNUS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='OTOSAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PANOZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KALLISTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PANTHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LIMA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PANTHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SOLO coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PANTHER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PAYKAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1725', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PAYKAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1800', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PAYKAN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J5 bus (280P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('806 (221)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('104', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('104 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('106 (1A, 1C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('204', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('205 (741A/C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('205 cabrio (741B, 20D)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('205 Mk II (20A/C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('304 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('305 universal (581D)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('305 Mk II universal (581E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('305 (581A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('305 Mk II (581M)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('306 hatchback (7A, 7C, N3, N5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('306 cabrio (7D, N3, N5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('306 (7B, N3, N5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('309 (10C, 10A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('405 universal (15E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('405 Mk II universal (4E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('405 (15B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('405 Mk II (4B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXER bus (230P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('504', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('505 (551A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('604', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('605 (6B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('406 (8B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('504 пикап', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J7 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J9 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXPERT (224)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('106 Mk II (1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('204 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('204 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('204 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('304', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('304 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('404', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('404 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('504 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J5 truck (280L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J5 c бортовой платформой/ходовая часть (290L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('406 Break (8E/F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXER truck (230L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PARTNER truck (5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PARTNER Combispace (5F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXPERT truck (222)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXPERT c бортовой платформой/ходовая часть (223)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J5 bus (290P)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J5 c бортовой платформой/ходовая часть (280L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J5 truck (290L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('406 coupe (8C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('309 Mk II (3C, 3A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('304 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('206 (2A/C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('306 Break (7E, N3, N5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('505 Break (551D)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXER c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('607 (9_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('504 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('504 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J7 bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J7 c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J9 bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('J9 c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('20coeur (2D)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('205 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('307 (3A/C)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('307 SW (3H)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXER bus (244, Z_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXER truck (244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('807 (E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('206 SW (2E/K)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXER c бортовой платформой/ходовая часть (244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('307 CC (3B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('407', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('307 Break (3E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('407 SW', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PEUGEOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VESPACAR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PIAGGIO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PORTER truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PIAGGIO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PORTER c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PIAGGIO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PIAGGIO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PLYMOUTH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEON II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PLYMOUTH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BREEZE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PLYMOUTH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VOYAGER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PLYMOUTH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANS SPORT ''89', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANS SPORT ''97', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIREBIRD ''89', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIREBIRD ''81', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PHOENIX coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PHOENIX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUNBIRD', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIREBIRD cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BONNEVILLE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PONTIAC' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 Targa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 (964)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 cabrio (964)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 (993)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('924', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('928', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('944', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('944 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('968 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('968', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BOXSTER (986)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('959', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('356 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('356', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('912 Targa', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('912', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 Targa (993)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 (996)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 cabrio (993)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 cabrio (996)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('914', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 тарга (996)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAYENNE (955)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARRERA GT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('911 (997)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PORSCHE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('118 NE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PREMIER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PADMINI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PREMIER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WIRA hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PROTON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WIRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PROTON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SATRIA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PROTON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISWARA sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PROTON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ISWARA hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PROTON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-MODELL (W 460)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PUCH (STEYR-DAIMLER-PUCH)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-MODELL (W 461)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PUCH (STEYR-DAIMLER-PUCH)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('G-MODELL (W 463)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='PUCH (STEYR-DAIMLER-PUCH)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RANGER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REKORD coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RANGER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAGNUM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RAYTON FISSORE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KITTEN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KITTEN Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REBEL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIMITAR SABRE Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIMITAR Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIMITAR Cabriolet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIMITAR Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RELIANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('EXPRESS truck (F40_, G40_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLIO (B/C57_, 5/357_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAGUNA (B56_, 556_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAFRANE (B54_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPACE (J11_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPACE Mk II (J/S63_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC bus (T5, T6, T7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FUEGO (136_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('11 (B/C37_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('12', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TWINGO (C06_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('14 (121_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('16 (115_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('18 (134_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('18 Break (135_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 Mk II cabrio (D53_, 853_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 (B/C53_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 sedan (L53_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 Mk II (B/C53_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 Mk II sedan (L53_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('20 (127_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21 sedan (L48_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21 universal (K48_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('25 (B29_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('30 (127_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4 (112_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPER 5 (B/C40_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9 (L42_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MASTER I truck (T__)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAGUNA Nevada (K56_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE I (BA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE Coupй (DA0/1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE Classic (LA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE Scenic (JA0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPACE Mk III (JE_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE Cabriolet (EA0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC truck (T1, T3, T4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPORT SPIDER (EF0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KANGOO (KC0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21 (B48_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('12 Break (117_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC truck (TXX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLIO Mk II (B/C/B0/1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KANGOO Rapid (FC0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAFRANE Mk II (B54_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESTAFETTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MASTER II truck (FD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MASTER II c бортовой платформой/ходовая часть (ED/HD/UD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MASTER II bus (JD/ND)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC bus (TXW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('10', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('15', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('17', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE Break (KA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 cabrio (D53_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('11 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('18 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('19 Mk II truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('21 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('5 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLIO truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPER 5 truck (S40_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('12 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RODEO 6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RODEO 5', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RODEO 4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TWINGO truck (S06_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC c бортовой платформой/ходовая часть (PXX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC c бортовой платформой/ходовая часть (P6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MASTER I c бортовой платформой/ходовая часть (P__)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MASTER I bus (T__)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCЙNIC (JA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAGUNA (B74_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAGUNA Grandtour (K74_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC bus (JL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRAFIC truck (FL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CLIO II truck (SB0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVANTIME (DE0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VEL SATIS (BJ0)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('THALIA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESPACE Mk IV (JK0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE II (BM0_, CM0_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCЙNIC II (JM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE II Coupй-Cabriolet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE II sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MEGANE II Grandtour', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRAND SCЙNIC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RENAULT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ELF Mk.III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RILEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KESTREL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RILEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4/72', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='RILEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SILVER SERAPH', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROLLS-ROYCE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORNICHE cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROLLS-ROYCE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PHANTOM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROLLS-ROYCE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 (METRO) (XP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100 cabrio (XP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 (XH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 hatchback (XW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CABRIOLET (XW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2000-3500 hatchback (SD1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2200-3500 (P6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 (XW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 Tourer (XW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('800 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('800 hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('800', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI MK I', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 hatchback (RT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 (RF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400 (RT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEGO Break (XE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI MK I cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('200 coupe (XW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('600 (RH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75 (RJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAESTRO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('A60 CAMBRIDGE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COUPE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEGO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('45 (RT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('25 (RF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('45 sedan (RT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('75 Tourer (RJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STREETWISE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ROVER' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 Mk II cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9000 hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('99', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('96', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('95 Station Wagon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('900 Mk II coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-5 (YS3E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('99 Combi Coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-3 (YS3D)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-3 Cabriolet (YS3D)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-5 universal (YS3E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-3 (YS3F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('9-3 cabrio (YS3F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SAAB' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RONDA (022A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORDOBA (6K2/C2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('133', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MALAGA (023A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARBELLA (28)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERRA (24)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERRA truck (024A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOLEDO (1L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FURA (025A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('600 D', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IBIZA (021A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IBIZA Mk II (6K1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INCA (6K9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALHAMBRA (7V8, 7V9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AROSA (6H)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MARBELLA truck (028A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORDOBA Vario (6K5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('131', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOLEDO Mk II (1M2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORDOBA (6K2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEON (1M1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IBIZA Mk III (6K1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IBIZA Mk IV (6L1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORDOBA (6L2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PANDA (141A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RITMO (138)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('127 (127A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('124', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('124 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('132', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('128', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALTEA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SEAT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SERIES 1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SHELBY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('D-1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SIPANI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTANA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SIPANI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RAPID (120G, 130G, 135G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('100', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('105,120 (742)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FAVORIT (781)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FAVORIT Forman (785)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FELICIA (6U1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FELICIA universal (6U5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OKTAVIA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('110', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('130', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OCTAVIA (1U2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('110 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OCTAVIA Combi (1U5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('105,120 (744)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1100', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FELICIA пикап (797)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FAVORIT пикап (787)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FELICIA Mk II (6U1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FELICIA Mk II universal (6U5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FABIA (6Y2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FABIA Combi (6Y5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FABIA sedan (6Y3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPERB (3U4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FABIA Praktik', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OCTAVIA (1Z)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SKODA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CABRIO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CITY-COUPE (MC01)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CROSSBLADE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FORFOUR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FORTWO coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FORTWO cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SMART (MCC)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R42', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SPECTRE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('R45', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SPECTRE' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MUSSO (FJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SSANGYONG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KORANDO (KJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SSANGYONG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KORANDO (K4)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SSANGYONG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KORANDO Cabrio (KJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SSANGYONG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REXTON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SSANGYONG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GAZEL', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='STANDARD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEONE hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY Mk II (BD, BG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY universal (BJF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1800 XT COUPE (XT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEONE Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JUSTY (KAD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEONE universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEONE (AB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEONE Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY (BC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUMO bus (E10, E12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPREZA (GC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JUSTY Mk II (JMA, MS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPREZA coupe (GFC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FORESTER (SF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPREZA universal (GF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVIO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SVX (CX)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY Mk II universal (BD, BG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY Mk III universal (BE, BH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY Mk III (BE, BH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('REX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MINI JUMBO II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M70/80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPREZA (GD, GG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IMPREZA universal (GD, GG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OUTBACK (BE, BH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FORESTER (SG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JUSTY III (G3X)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OUTBACK', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY IV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LEGACY IV universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUBARU' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SWIFT Mk II hatchback (EA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALTO Mk II (EC)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALTO (SS80)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARRY truck (ST90V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LJ 80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITARA (ET, TA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SJ 410 Cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SWIFT Mk II (AH, AJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SWIFT cabrio (SF413)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAMURAI (SJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SJ 413', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPER CARRY bus (ED)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALTO Mk III (EF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BALENO hatchback (EG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BALENO (EG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('X-90 (EL)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BALENO universal (EG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITARA Cabrio (ET, TA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WAGON R+ (EM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SJ 410', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JIMNY (FJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SWIFT (AA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRAND VITARA (FT, GT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAPPUCINO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARRY truck (FD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('WAGON R+ (MM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IGNIS (FH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LIANA universal (ER)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LIANA (ER)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALTO Mk IV (FF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('IGNIS II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='SUZUKI' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RANCHO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1307-1510', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAMBA (51A)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SOLARA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MURENA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAGORA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HORIZON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA SIM''4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1100 hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1200 S coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1301', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1301 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1501', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1609/1610', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MATRA BAGHEERA (X)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA SUNBEAM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('160', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('180', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1100 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1501 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIMCA 1500 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAMBA cabrio (51E)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENGER Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENGER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TALBOT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('INDICA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TATA (TELCO)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SAFARI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TATA (TELCO)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIERRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TATA (TELCO)' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RAV 4 (SXA1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA hatchback (_E10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (_E8_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (_E9_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA hatchback (KE, TE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA hatchback (_E9_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA coupe (AE86)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA hatchback (_E7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Liftback (_E8_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Liftback (_E10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Liftback (_E9_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Station Wagon (_E9_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Station Wagon (_E7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (_E7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Wagon (_E10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORONA hatchback (TT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER 80 (_J8_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER (_J7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRESSIDA (RX3_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRESSIDA (_X6_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LITEACE truck (M2_V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LITEACE truck (CM3_V, KM3_V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CROWN (_S1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MODELL F bus (_R2_, 31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET (_P7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET (_P8_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MR 2 (_W1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET (KP6_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPRA (MA70)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SUPRA (JZA80)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERCEL (_L1_, _L2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TERCEL (AL2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4 RUNNER (_N130)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY (_V1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY sedan (V1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY (_V2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY Liftback (V1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY Station Wagon (_V10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY Station Wagon (_V2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA Mk II sedan (_T15_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA (TA4L, TA6_L)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA E sedan (_T19_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA E (_T19_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA E Sportswagon (_T19_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA Mk II sedan (_T17_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA Mk II (_T17_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA Mk II universal (_T17_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA Mk II (_T15_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA Station Wagon (TA4K, TA6K)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA coupe (RA6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA hatchback (T16)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA coupe (_T18_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE III Wagon (_H10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA (_T20_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE I Wagon (_H_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA coupe (TA4C, TA60)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA cabrio (_T16_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HILUX пикап (_N_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA cabrio (_T18_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA coupe (T16F)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA (TA60, RA40, RA6_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA FX hatchback (E8B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE IV Wagon (_H1_, _H2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASEO (EL54)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER 90 (_J9_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET 1000 (KP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA (TA2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORONA (RX, RT)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PICNIC (_XM10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (_E11_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Liftback (_E11_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA hatchback (_E11_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA coupe (KE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Combi (KE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (KE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRESSIDA Station Wagon (RX3_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRESSIDA Station Wagon (X6K)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CROWN Station Wagon (_S1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARINA (TA1_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET 1000 Kombi (KP)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA (ST16_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE II truck (H5_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LITEACE bus (CM30_G, KM30_G)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA cabrio (_T20_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE III truck (_H10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS (_T22_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS Station Wagon (_T22_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY (_V20)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PREVIA (TCR1_, 2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET universal (KP6_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (_E10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS Liftback (_T22_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER 100 (_J10_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASEO cabrio (EL54)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER Hardtop (_J7_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Wagon (__E11_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA SUPRA (MA61)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MR 2 (_W2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE II Wagon (H5_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STARLET (EP91)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER (_J6_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YARIS (_CP10)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORONA universal (RT118)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE I truck (_H_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HIACE IV truck (_H1_, _H2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YARIS VERSO (NC/LP2_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CELICA (ZZT23_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MR (ZZW30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ESTIMA (ACR3_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('RAV 4 Mk II (XA2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIUS (NHW11_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER (_J4_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER пикап (_J4_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LITEACE bus (_R2_LG)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LITEACE truck (_R2__V)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS VERSO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COPAIN (KP30_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COPAIN truck (KP36V_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAMRY (_V30)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA (_E12U_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA sedan (_E12_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Combi (_E12J_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Verso (_E12J_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS sedan (T25)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS Combi (T25)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LAND CRUISER (J12)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('4 RUNNER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AVENSIS (T25)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PRIUS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COROLLA Verso', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TOYOTA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 601', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1.1', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 601 Universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 601 Tramp', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 601 truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1.1 Tramp', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1.1 Universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRABANT' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ACCLAIM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPITFIRE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 7 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HERALD', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GT6', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITESSE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2000 MK I', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 3', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 4', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 5 (250)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 8', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2.5 PI MK I', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOLEDO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('STAG', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DOLOMITE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 2', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 3A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TR 4A', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ITALIA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HERALD Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VITESSE Cabriolet', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2000 MK I Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2.5 PI MK I Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2500 Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2000 MKII', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2000 MKII Estate', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HERALD cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TRIUMPH' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1600', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('2500', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3000', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CERBERA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHIMAERA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GRIFFITH', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SPEED EIGHT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAIMAR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TASMIN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TUSCAN I coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TUSCAN II Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('280 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('280 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('350 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('350 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('390', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('400', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('420 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('420 Sports Saloon', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('450', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIXEN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='TVR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('31512', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='UAZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3160', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='UAZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('3162', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='UAZ' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ALTER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='UMM' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk II hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk III hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk III universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk II Belmont', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BRAVA пикап', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CALIBRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARLTON Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARLTON Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARLTON Mk III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CARLTON Mk III universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER Mk III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHEVETTE universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NOVA hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAGNUM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAGNUM universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NOVA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('OMEGA universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SENATOR Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROYALE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TIGRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FRONTERA Sport', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FRONTERA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEREY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('COMBO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHEVETTE hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER Mk II hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER Mk III hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROYALE coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SINTRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARENA Van', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FRONTERA Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MONTEREY Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CHEVETTE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk IV hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk IV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk IV universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk III cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZAFIRA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk IV coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA Mk II cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SENATOR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER CC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('FIRENZA coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVA universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVA coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VX universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CAVALIER Mk II cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRESTA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CRESTA universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MAGNUM coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VELOX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VELOX universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VENTORA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VICEROY', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VICTOR', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VICTOR universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VISCOUNT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRAVAN Mk III', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRAVAN Mk IV', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO Van', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NOVAVAN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSAVAN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO Combi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MOVANO Chassis/Cab', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('AGILA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSA Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VX220', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVARO Combi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VIVARO truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ARENA Combi', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA MK IV cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORSAVAN MK II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA Mk II GTS', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIGNUM', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MERIVA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ASTRA MK V hatchback', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VECTRA Mk II universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TIGRA TwinTop', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MIDI MK II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VAUXHALL' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('M12', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VECTOR' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ILTIS (183)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JETTA (17)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('K 70 (48)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KAEFER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KARMANN GHIA coupe (14, 34)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SANTANA (32B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIROCCO (53)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SCIROCCO (53B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT28-50 bus (281-363)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DERBY (86)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DERBY (86C, 80)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TARO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT (32)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('412 Variant', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT (32B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT (3A2, 35I)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT Variant (33)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT Variant (32B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT Variant (3A5, 35I)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO (6N1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO (86)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO (86C, 80)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO coupe (86C, 80)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk II bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk IV bus (70XB, 70XC, 7DB, 7DW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF cabrio (155)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF Mk III cabrio (1E7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF (17)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF Mk II (19E, 1G1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF Mk III (1H1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500,1600 (31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF Mk III universal (1H5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('181', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SHARAN (7M8, 7M9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT sedan (32B)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DERBY sedan (6KV2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT (3B2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER bus (22, 24, 25, 28)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KAEFER cabrio (15)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('KARMANN GHIA cabrio (14, 34)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('411,412', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500,1600 hatchback (31)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1500,1600 Variant (36)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER truck (21, 23)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER c бортовой платформой/ходовая часть (26)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk II truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk III truck', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk III c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk IV truck (70XA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk IV c бортовой платформой/ходовая часть (70XD)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT28-50 truck (281-363)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT28-50 c бортовой платформой/ходовая часть (281-363)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT Variant (3B5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO Variant (6KV5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF Mk IV (1J1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF Mk IV universal (1J5)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT Mk II bus (2DM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT Mk II truck (2DX0AE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT Mk II c бортовой платформой/ходовая часть (2DX0FE)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LUPO (6X1, 6E1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEW BEETLE (9C1, 1C1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JETTA Mk II (19E, 1G2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('JETTA (1J2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO CLASSIC (86C, 80)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('VENTO (1H2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CORRADO (53I)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk II c бортовой платформой/ходовая часть', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk III bus', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CADDY (14)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CADDY Mk II (9K9)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CADDY Mk II (9U7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO truck (86CF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO truck (6NF)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('BORA universal (1J6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT 40-55 I truck (291-512)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('LT 40-55 I c бортовой платформой/ходовая часть (293-909)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO (6N2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SANTANA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('166', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT (3B3)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PASSAT Variant (3B6)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO (9N_)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('PHAETON (3D2)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOUAREG (7LA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TOURAN', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('NEW BEETLE cabrio (1Y7)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('MULTIVAN Mk V (7HM)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('GOLF V (1K1)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk V c бортовой платформой/ходовая часть (7JD, 7', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk V truck (7HA, 7HH)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TRANSPORTER Mk V bus (7HB, 7HJ)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('POLO sedan', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CADDY III truck (2KA)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('CADDY LIFE III (2KB)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLKSWAGEN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850 universal (LW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('940 (944)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('940 Mk II (944)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('940 Mk II universal (945)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('240 (P242, P244)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('240 Break (P245)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('960 (964)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('960 Mk II (964)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('960 Mk II universal (965)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('260 (P262, P264)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('960 Break (965)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('340-360 sedan (344)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('340-360 (343, 345)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('140 (142, 144)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('460 L (464)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('480 E', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('740 (744)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('760 (704, 764)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('760 Break (704, 765)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S40 (VS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V40 universal (VW)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 121', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 122 S AMAZON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('66 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('140 universal (145)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('164', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 1800', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 2200 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('260 universal (P265)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('440 K (445)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 544', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('DUETT', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('780', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V90 universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C70 coupe', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('P 122 S AMAZON universal', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('260 coupe (P262)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('66', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('740 Break (745)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S70', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S80', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('C70 cabrio', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('850 (LS)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('940 Break (945)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V70 Mk II', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S60', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V70 XC', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('XC 90', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('S40', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('V50', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='VOLVO' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('353', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WARTBURG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('353 Break', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WARTBURG' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('130 Roadster', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WESTFIELD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ZE', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WESTFIELD' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('ROADSTER', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WIESMANN' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('1300', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WOLSELEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('SIX', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WOLSELEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('HORNET', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WOLSELEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('18/85', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WOLSELEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('16/60', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='WOLSELEY' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('101 Feeling', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='YULON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YULON', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='YULON' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('101 (1100)', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ZASTAVA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YUGO', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ZASTAVA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('YUGO FLORIDA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ZASTAVA' ));            
            INSERT INTO "shop_auto_mudel" ("mudel","auto_mark_id") 
            VALUES ('TAVRIJA', ( SELECT DISTINCT id FROM  "shop_auto_mark" 
                              WHERE mark='ZAZ' ));            
            
