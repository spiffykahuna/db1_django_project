#!/bin/bash
#cat sed.sql | perl -0777 -pin -e  's/INSERT INTO \"shop_auto_modifikatsioon\" \(\"auto_modifikatsioon_id\", \"auto_mark_id\", \"auto_mudel_id\", \"mootor_id\"\)/INSERT INTO \"shop_auto_modifikatsioon\" \(\"auto_modifikatsioon_id\", \"auto_mudel_id\", \"mootor_id\"\)/igs; print;' | head -n 200
#cat sed.sql | perl -0777 -pin -e  's/INSERT INTO/HEHE/g; print;' | head -n 200
#cat sed.sql | perl -0777 -pin -e  "s/\(\W*SELECT auto_mark_id\W*FROM \"shop_auto_mark\"\W*WHERE mark=\'\w*\'\W*\),\n//igs; print;" | head -n 200

#cat sed.sql | perl -0777 -pin -e  's/INSERT INTO \"shop_auto_modifikatsioon\" \(\"auto_modifikatsioon_id\", \"auto_mark_id\", \"auto_mudel_id\", \"mootor_id\"\)/INSERT INTO \"shop_auto_modifikatsioon\" \(\"auto_modifikatsioon_id\", \"auto_mudel_id\", \"mootor_id\"\)/igs; print;' | \
#perl -0777 -pin -e  "s/\(\W*SELECT auto_mark_id\W*\n\W*FROM \"shop_auto_mark\"\W*WHERE mark=\'\w*\'\W*\),\n//igs; print;" | \
#perl -0777 -pin -e  "s/WHERE\W*\"auto_mark_id\" = \(SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'\w*\'\) AND/WHERE/igs; print;" 

#cat sed.sql | perl -0777 -pin -e  "s/WHERE\W*\"auto_mark_id\" = \(SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'\w*\'\) AND/WHERE/igs; print;" | head -n 200
#FROM "shop_auto_modifikatsioon"
#WHERE
#"auto_mark_id" = (SELECT auto_mark_id FROM "shop_auto_mark" WHERE mark='AUDI') AND
cat sed3.sql | perl -0777 -pin -e  "s/and auto_mark_id=\( SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'.*\'\)\) AND/\)AND/igs; print;" \
| perl -0777 -pin -e  "s/WHERE\W*\"auto_mark_id\" = \(SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'.*\'\) AND/WHERE/igs; print;" \
| perl -0777 -pin -e  "s/FROM \"shop_auto_modifikatsioon\"\W*WHERE\W*\"auto_mark_id\" = \(SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'.*\'\) AND/FROM \"shop_auto_modifikatsioon\"\nWHERE\n/igs; print;" \
| perl -0777 -pin -e  "s/\(\W*SELECT auto_mark_id\W*\n\W*FROM \"shop_auto_mark\"\W*WHERE mark=\'.*\'\W*\),\n//igs; print;"

#FROM "shop_auto_modifikatsioon"
#WHERE
#"auto_mark_id" = (SELECT auto_mark_id FROM "shop_auto_mark" WHERE mark='MERCEDES BENZ') AND

#and auto_mark_id=\( SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'\w*\'\)\) AND

#cat sed6.sql | perl -0777 -pin -e  "s/and auto_mark_id=\( SELECT auto_mark_id FROM \"shop_auto_mark\" WHERE mark=\'\w*\'\)\) AND/AND/igs; print;" 
