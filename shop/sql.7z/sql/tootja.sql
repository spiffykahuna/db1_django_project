ALTER  TABLE shop_auto_modifikatsioon DROP COLUMN auto_mark_id;
