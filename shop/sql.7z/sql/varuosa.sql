

CREATE SEQUENCE common_seq;

INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Alusvankri osad');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Amortisaatorid');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Elektriosad');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Filtrid');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Jahutussüsteemiosad');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Keredetailid');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Mootori ja vent. rihmarullikud');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Piduriosad');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Poolteljed ja kattekummid');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Rihmad');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Rooliosad');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Sidurid');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Tarvikud');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Vedrud');
INSERT INTO "shop_varuosa_kategooria" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Veepumbad');

DROP SEQUENCE common_seq;
CREATE SEQUENCE common_seq;

INSERT INTO "shop_varuosa_seisund" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Available');
INSERT INTO "shop_varuosa_seisund" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Not available');
INSERT INTO "shop_varuosa_seisund" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'In arrival');

DROP SEQUENCE common_seq;
CREATE SEQUENCE common_seq;

INSERT INTO "shop_varuosa_kulg" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Parem');
INSERT INTO "shop_varuosa_kulg" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Vasak');
INSERT INTO "shop_varuosa_kulg" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Esi');
INSERT INTO "shop_varuosa_kulg" ("kood", "nimetus") VALUES ( nextval('common_seq'), 'Taga');

DROP SEQUENCE common_seq;




INSERT INTO shop_tootja ("tootja_id", "nimetus", "lehekulg", "telefon",  "email")
VALUES (1,'Lemforder', 'http://www.zf.com/brands/content/en/lemfoerder/homepage_lemfoerder/homepage_lemfoerder.jsp', '+49 9721 4756-0', 'info.zf-services@zf.com');

INSERT INTO shop_tootja ("tootja_id","nimetus", "lehekulg", "telefon")
VALUES (2,'Bilstein', 'http://www.bilstein.com/', '00372 655 9989');

INSERT INTO shop_tootja ("tootja_id","nimetus", "lehekulg", "telefon")
VALUES (3, 'NGK', 'http://www.ngk.com/', '888-800-9629');



CREATE TABLE "shop_varuosa_pilt"(
	id serial NOT NULL,
	filename VARCHAR(256) NOT NULL PRIMARY KEY,
	data TEXT NOT NULL,
	size INTEGER NOT NULL
);



INSERT INTO  "shop_varuosa_pilt" ( "filename", "data", "size")
VALUES ('img_varuosad/default_varuosa.png', 'iVBORw0KGgoAAAANSUhEUgAAAJYAAACWCAYAAAA8AXHiAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9wEHBIjIjIMeYgAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAd80lEQVR42u2deXCVVZqHn3O+796E5GaBLKxhC4QlBAOIAVpBGpDGQVtbnXHBbnV0qrXbGbFnanq6nCq7Z6pmuqoHutpyadtW224VbXctG0EFwxKQIIQlEELYAgJJIIGs997vO2f+OAlLdpKLhuT7VeWv3Nzce+5z3/Oe97yL0FprPHmKsKS3BJ48sDx5YHnywPLkyQPLkweWJw8sT548sDx5YHnywPLkyQPLkweWJw8sT548sDx5YHnywPLkyQPLkweWJw8sT548sDx5YHnywPIEjuOtgQdW5KTq6wm99BIN//qvuDt2eAvSRdneElwMlbNiBeFnn0WfOoUYNAgxbBhywABvcTyL1T2onGefRZeXg5TosjJ0MOgtjgdWBKAKh7Guvx6RkgJnzyLCYW+BPLC6CZXr4nvoIXz33ouIj0efPYuuq/Mo8cDqPlT2vfcikpMhOhpdVQXV1R4lHljdg8q/ZAkyLg4CAURCAjocRldXe6EHD6zuQUUgAICIjUUkJoLrQm0tSM8V9cDqJlSGLAGxsVBbi6qogFDII8UDqx1pjVq3rn2oAOH3IxIT0VqjKyshOtoj5RLVtwKkQiAGD0bm5CAzM1uFCkD364cYMAARE4OurfUo8cDqWFZWFuKJJ5AJCW1aIiElxMUhXBdOncI9cQJr0KDWt9aiIsKrVmFdey32lCkeUX0VLAA5cGD7hg0QgQBaSnRNDbQRy1JFRYSWL8f9+GOoqkKmpyPj4z2q8AKkrcvng8REiItDnzkDwSA0a9V6IVRy2jSs2bM
9qPqExXIcqKkxgHRly4yLQ8bEoKurEUKYk+IFCv7qV6h16yAhgajly5EjR3o09XawVH097scfo0pKsHJyEBMnImJjkTExnT89BgLoQMA470pd9Ov6e+45B1W/Dz/0oOoTYIXDuB9+SPg3v0HX1+OuXYucMQNr0iTIyUH27w8dASYE0u9HxsbiVlfj7tsHGRlQUkJo+XLUunXIadPwPfaYB1VfAcutqMD96itUdTXCtqG+Hvezz3BXrsS65hqsmTORkydjpaeDbbcZVdd+Pzox0VxCnz2LtG3qf/lL1Pr13vbXF8ES/fsjJ09G5OYiAgGs+fPBsnBzc3Hz8nC3bkVmZGDPn4+VmYnMyDDOumVd/DwxMYiEBER0NO727biff45av96zVH0VLBkVhZWTg1q/HrV3LyIpCevmm7FmzUJt2YK7cSNqyxbChw7hDB6MNXs21tVXI4YOvTgM4fMh+/fHDQZx337bnAo9S9X5w8+TTz75ZO8yWeb0psrLcdevB8fBys7GnjoVMXYs1uTJkJICSqH27UNv24baswdVWmosl89nYljhMOrQIbP11dd7jnqfBwsQ/fohoqPRRUXogwcRaWmIkSORiYnIQYMQ6elYU6Yghg1D19SgCgpQ+fmooiLU8eNo1zV57kKgDx2CpCSi/uu/sLKzPWL6ehxLjBiB/M53cF9/HZWfj549G+LizLcpKQnVvz++5GR0YSFubS34/ejKStwPPkBt2IA7YwZWZia+Rx4xvlpWlkfLpbgkV2ScKhRCnT7d/huLj8eaPh2SknC//BL15Zeo+vrzv6+vJ/zmmzgff4xISMD/4INE/fu/Yy1aZE6Xa9bgrluHHDzYg6ovWKymfCq1Zw++++7Dmjix7Tc3eTLuvHk4b72FW1CANWsWOjoaUVdH6NVXCT//PAiB/+GH8d11F0iJnD4dtX07qrQUa/
Jkz6fqC2CpUAj19tsmn+rECaishKVL24ZLCKzMTJyPPkLl5+Pu2YMvLq51qPr1M5YsJQVmz8Z2HJPs56n3g6VLS3G++AJ9+jRaStxPPjG/aAuuqCjExIlY2dm4H3+Mu2oVKi8P5513WoXqwpAFUVG98xMPh1HHjyOHD/fAOmeAYmNh+HCIjkYkJEAo1CFcVnIyev581LZtuCtXQkMDBAJtQtWbpYJBnDfewF29Gt8DD2DPnes572DyqOy5c5Hp6YjEROzvfx+RnY37ySeEly/HLSxs+Uc+H2LMGERmpqm48fvx3Xdfn4XKeeYZ1K5d6LKyy1p9dGWdCoVAjh6NzM5GHz8OSuF78EHE9OntwiVHjcKeNw85YgRi+HCsa64xwdA+CJUOBvE9+CC+RYvMXakHVuMLHjIEOXs2IjkZNz8fEhLw//Sn7cIlADl+PHLiRDhzBrewENWHofLfey9c5qTEKzPyHghAaSlq/37EwIH4Fy9GjByJOnIElZuLLi9HjBljTnhNli46GlVZiZuXZ7IVxo3rMEXZg6qXWSx19GiL5LqLvg0xMYjMTKirw12zBqewEPs738H/+ONtW66YmHMpM6q0FFVcbFKOPajM4yNcjdSjLJaqr8d94w3CL7+MW1BgUllsG9F4FXNOfj/ExqL270fv3YsYPBhr7FissWMRw4a1brka04t1YwGqvWABMi2td0IVCp2HqqHB1E+2A5Wbm4vz3nuI5GRkcnLvAkuFQjivv0746adxCwvRRUWoPXvQx44Z6xUIILQ2UIFxPGtrUfn5UF+PyM5GJicjhw9vEy4RE4NMTcXKycHuxdc0av9+wr/7HWr/fqxrrsH/6KOm0UkbUIWWL8d97z3EiBGISZNMgmSvAEtrhGUR+sUv4OBBUMq8SUCtXo37wQfo+nrT/SUQANs2zTssy6S87NmDHDTIhCGiotqHKzExYt/KHnvAiY8H1zVfzOPHzSX6+PEtgr5NUKmtW7FuvBH7H/
6hzfrJKxOsxm1KTpmCLi9Hl5QggkH8v/wlcuRI9OHDqI0bcT/91HTZq60Fy0KmpZm0l337ED6fSYWJizPP1QwuER9v0l6aLF5vlmVhTZiA6NfPpGlv2QI+30VwNYfK99hj5ve90ceSqanYixeb7M/Dh1GbNxP11FOmw96ECbjbt0NhIc7u3ai9e00nmGAQdeAAHD2KGDkSKyPjXLJfE1wiJgbr+utNGnJfkW23CZe7eXPnoaqp6dKXseeFG4RATJqELi9H7diBk5+PnDQJa8ECrJkzEaNHQ10durAQXVyMe+AA+uRJqK5GREcjJ0xAXOCkyuHDsaZNi+i38UqGSx89ivPBB6ht2zqEyi0uJvzSS1BXhxwz5sqPY8nUVER6uoErNxd17JiJnufkGF8pOxsxcCDCsuDoUfTZs4jqauTUqVizZpk7xQtZ7e3dYkKhc+5ER3C5+fnw9dfIBQvw/+xn7UIVWr4c97XXTP7/tGkt1rVd+6B1s9rxHnW8UTTcfjtufj4iNZV+H32EuMC51PX1uOvX465ahfb78d19N1ZmZp8wRspxTJD46FGTQpSSgpWWhkxPb/0PgkHCK1YQeuYZ9KlT+H74Q6KWLj2XVdsaVOqjj5BTpuBbuhT7+usvbePp0WB1Ai7AOPxaI1NT+8YWFw4T/vRTnE8+QRcXm5NfcjJy8mTsW27BvvbaDuEiHD7fH+wCuCIB1ZUBVifh6jMKhQi/8w6hV16BsjLTbqlfPxOKOX0akZ2N/1/+BXvmzEuGK1JQfWM+lgoGcV57DXflSsSoURc5111y6AsKzMSIXho5b3cd33yT8NNPQ1UV1pw5+G67DXvhQqysLHRtLXr7duOnjh6N6N+/06dF7fMRfvrpiED1jYGljx4l/NxzOB9+aE4Y48dfMlwtHPojR/oUXBfd/TU04Lv/fux770VmZWFlZJh1iInB3bULTpxATpxoskSbVXi3CldeHiovD71xY0SgMh/6NyRn40Zdm5ama9LSdMO//
VvXn8h1df2tt+qatDRdO22aVl9/rfuCQq+9pmsa1y/4zDOtPkZVV+u6RYt0bVqadvPyOvW84Quet2bCBO0WF0fk9X5j4QaZlgbjxqGKi3Hz8tAnTnTJcjXfFnUohDV1aq8OKajCQsLLlqHKyrDnzcP36KOI5r1THQd3xw7cr75Ca40YMcJscfX1CCkRUVGmTUCzkITMyECkpqJtG/8vfoE1dWqEtqlvWE5eXuQs15IlEfuG9XiL9cIL59Yt9Kc/tf6YV17RtWPG6Nq0NF133XW6dvp0Xb9kiQ49+6xWRUVa19e3+fyqqiqir/cbD5DKYcO6bLma2jPqkyexMjOxFy7sM6dDa9w4dP/+qL17UV9+ibYsxPjxiMYUa+ezzwg//7xJ2U5NRSckGIt15Aju1q04eXm4xcWo8nJT1ibERVY+0hY/smApZX46mORgjR0LycnovXtxN2zolEN/rufn22+bAomrr0YmJfVOilwXwuGLc9L9fhMl9/txt25Fb91qqpXGj0fl5RH+3e/QBQWIGTPw3XEHvltvxZ49GzlhgmkfcOIEuqQEtWkTqqQEXVGBTE42Ezguy4ktktvcpk3a2bCh0baqiG6LdXffbRzMSZO0e/Bg7972Xn5Zh/73f9v+/R//eN6RX7ZM10yapGvS0nTd3XdrdeaMVq1sec6GDTr0hz/oupwc87fjx2v32LHL9h4iY7GCQUJ//jPhp57C3bABdegQuqEBYVnGCrV2h9XJbVEVFRF84gnUZ58hp03D/6tf9equL25JCeGnn8ZZswZdX2/Wo1mZmpWRAU3bYm4u1NVhLVyI/+c/Rw4d2mqinkxNRUyejJWTg5w+Hfsf/xFr3LjLGGOKhKXatUvXZGbq2rQ0XTtunHEeZ87U9ffeq91duzoMCbRnufqSpTq3Hu+/f95R/7//a9dydeTQt/4PnMv+HiJisfTp06gjR9Dl5abMatYsdEMD7q5duJs3m1TjhgZT8t7MaWzLcuH3E/qf/
+kzluqi9Rg7FoYNw927F3fTpnYtV3sOfdv/4PLX0EQELNm/v0kdLipCDB2K7667sGbMMGXwZ8+iCgrQ27ahDxwwp5ZAAKREXNC9+CKHfv161ObNqPz8cz0/7Tlz+s7djRAmMh4Xh1tQgNq82axzc7jacejFt1yQGxkfS2vTG72wEFVSgszMxHfDDchx40xrxv79oaYGfeAA7rp1qKIiM1VLSoiPNw36Les8XEVF6AMHugeV1tA4yFKdOWPK67U2c3KkbNPv8+DqSWBJaQpCy8pQmzaB6yLHj8caMQI5cCBWZqZ5o2lpEAqZloz5+aidO+H0aVR9PSIuDtF4h0VyMvh85j6sK1A5DmrfPpwNG3BWr8ZZvdrcL+7fD+Xl6MakONHZgQIeXJf+0iOZNqMqKgg+8AD6yBGiX34Z2YpPpINBgj/5Ce6qVedfREoK1qJF+G66CTlpEsTGmlNlF4N2ztq1OK++irt2bcui1OHDzYc1Ywa+efO+tcZqOhg01yydPS1+8AHBn/4UDfgfewzf44+3+rjwiy8SarQVUb/+NfZdd13BFqtpsc6eRVdUGJ/q7FnzzbowAFdbS/jPf8Z5/30IBLB+8APktGmo06dRu3YZRzUcRowbh+xK07NQiPBbbxF+7jnU0aPIKVOwFi3C/sEPsBYuRGRlgeOgS0vNazx1yswv/CbLwRyH0F/+gvPyy5CcjBw69JIcerV3rykqEcK4Ds3gbApF4PNhzZv3rWV/RBQs0eiU67170V9/jRg7FjF0qDHHtbXnO+lZFv5HHsF3//1mWsTYsabTcUIC9ty5ZmpEFz6w8Oef47zwAvrkSeybbsK+807s737XtOIeNw5fdrbZHgYMQB86hLtuHVRUIEaP/sbgUqdP4771Fu4775g1SkvrHFxCmCojvx+1cyf6yBFITsYaPrxFhF5MnIidk/OtpmlH/K5QR0WZ64PCQoiLMx+q67banlHEx5vq5FGjjKM/
c2a7PUXbc9Tdfftw33wTVVKCvXgx9v33m+eNjwfLMkFDv98UrY4YgRgyBEpLTXEBptWRSEi4nAHDc36dGDQIdeKEKaa9BLhE44RYampQu3cb2DIzz9VSnnucz3d538u3AZYMBBBK4bz6KnrnTuzFi3E+/ZTwk09CbS3+//gPfPfd16I/lQgEWvZouAQnVxcWEv7NbxAZGUQ9+ihi5Ehka6XijR+ulZaGTkgwIZADB5CJiTBsWItYUUSsVDCIm5tr4lEpKaZqe/ToS4dLCFOZpBTupk2IykrkVVf1yGTHyxIps66/HvvuuxENDYT+8z8JPfGEsdL//d/4fvjDy3F7gLtxIwSD5huckWFCGO3J78eaPh3rxhvBdXE2bTJ545ehBMB9911C991H6KGH0I6D1hrrqquI/v3vkRMnotevJ/yzn5n/35H69cOeNw8rIQFVWIi4oMV4rwdL1dQgsrPRw4fjfPUVJCfjf/JJfHfccXl2mYoK3MpK9ODBiOHDO9eeSAhkUpKZo5OSgrtnjwlHKBVRSxV65RXCv/0tOikJ6+670aHQOehFdDT+X/8aMXcu6vBhGh55BOfLLzsGdd8+VEwMJCWZ0cKhUN8ASwYC+G+7DTlwINJxsK+9Ft8DD1y2np9ywADE4cOI48dNs5BOHuOFZZnWkxMmQH296fMQoQ+prf5UzYdxWlddhf/xx5Fz56LWryf8298auNqwnKquzvT2+vpr0z4gLa1H9qO4bJdGKhjEuv129KhRqLNncffsuSzbDAB1dYicHPTAgbgHDqA6s6VcENwVTVdSx45FpBnbpTY9awHXsmWEc3NRjbcF5xQMooqKcP76V/SpU1jTpiGauhb2MF227qYyOhorKws3PR1VUICbm2tGt3WjTaFyHGQ43NLy9euHNXYsTnS06Qh86BBkZbVeodL8dfr9pm1SY7iju/3dL4LqzBl8P/5xp9ozNsEVtiycL74wHY1vuw2dnY01ahTuyZPo4mLCr72Gu3491pw52N/
7XqfjYL0GLAArMxP/LbcQ/PRT1MaNiMWLu9X/0v3Tn3AOH8b/q181exc2IiMDKzMTVVKCu2WLKQ1LSurwTlCVlZlSsnC429mUF7W8buxLhd+P8vk6tTVYV10FS5eiExJMXtuLL2KNGEE4LQ0qK00Hw9JSrJkz8T3wANaUKfRUXd6cd8dBNTTgHjsGCQnIppnMXfnQDhwg9NxzOGvXos+cMVH9C6LzUkrjfxQUoA4eRAwciDVypLFabcClamtRmzfj/O1vpm/84sVYI0Z0Ka2ked2flZNj0ol27DDWsJP3dnLgQFNsGh0NZ86YdOKSEvT+/YjYWFOl86MfYefk0JN1ecGS0mwt/fphz56NPWlSl59K9O+PTExEvf02autWBGDNnn3RdiiSkkxke9069OHDZmtLTDQfUjNYVG0tas8ewi+9hD58GGvhQuw5c7pktVr4VA89hP+f/xkRCJjL9q1bLw2upCTkyJHIrCzk2LHIjAzkzJnYf/d3WHPndi2I3KvAonEoZXq6sQTd5TQ9HUaPPp8A18xyiYQExNChJmNi61ZUSQkEgyabIToaEQqB6+IeO4bauBHn5Zdx8/KwZs7Ev2SJuY+71FBHOIyzYkULR10kJ5uMA5+vS3CJQACZmmoSJ7OysLKysNPTzYDOK0DfSPmXiOAEBKvxrk/t2GF6tjvORXDJpCTEmDHmzvLgQdSuXaht20x26t69uF9+ibNqFe4nnxhL1eSvXH1117boU6dw33gDdeBAy9NfUzpLF+FCSlM34POZx8srZ97DFTlAoEO4Bgwwd3+JicbPKy01XZi3bkWXlKAPHUL0749v0SJ899yD3UWoAGRsLHLoUOxp0/DdfHPLw0l34bpC1ePaGCnHMX0vLQsZCLR7qgu//z6hZcvQZWX4lizB99BDF/XI0lVVJnu0pAR18KCJUyUkGH9t9GhzSd3V47pSuKdPI5Qy/9N12w9v1NQQ+stfCP/
hD2BZ+B5+GPvOO5G9dFBUjwJLNTTgvvcebnExcsgQ7MWLkdHR0M5NfUdwnUubDgZN8DM6GrRG+nxdGlKkHMf0Pt23D7VrF1RVYS9ciD1/fsd/3Ifg6jlbYThM+PXXCT/1lJnfvG0b7tq1JiX3xAlUZaX5JjRV+TSmoXS0LTb15hQ+HyI6GmHbXfdXwmGczz8n/PrrqFWrDFjBIMTEIMeM6TjVuQ9tiz1nMkVVFc6776I3bQLHQSQmImJjTVLbrl2oTZvQhYWm52ZtrSmUaATMzsxsH64IgR96912c559Hl5QgR4/Gd9NN+P7+700RaGd7SPQRuHoMWCImBjFkCKqsDA4cgPh47JtvRs6aZSqjq6tR+/ahvvoKd8cO1Pbt6CNH0JWVCK2xJ05EDB6MLijAbYQzUnApx8H9/HPCv/89urwca/FifHfeaRIT09MvvRVTW3BNnBjRE7QHVtMJKzUVmZ6OKitDFxSgHQd7wQLsW24xCW0ZGaYmsaHB5K3v2mU60e3ciXvwIAwaBPHxqJ07UTt2RAYurdG7dxNesQJ16BD297+P/777sJpaXna1jKwZXASDpt34NzDyrU+eCgFwXer/6Z9Qq1cjcnLwP/449syZqIYGOHMGVVGB2r8fVVhotsfSUnRdnbF6qakmreTUKYiNJernPzdjeruYWqJqa3HefBPntdeQY8di//jH2BMmRG5Ca00N4dWrEQMHYs+a1Wu2wp5pdy0L/9KlhDBDmkLLlkEjXERHI1NSUBMmIObMQR0/jjp40AwkKipCHTuGwGSVyowMRHp6t/KVdEUF7rZtpuooJwd7+PDIjv0NBEz8qxOZGB5YkWBr0qS24ZLSZAskJmIlJpqqnuuuwy0rM1vk7t2mOdu8eW33PO8sWA0NppInORk5bly7oY/ufJF6m3q0p9guXM38Ffx+rEAA0tPRU6eaHKvuNhVTCior0adOwYABLaphOvUUNTVw6hQyAnelV5J6/
OVTE1xywQL05s2Eli3Dyctrw2NszCWPj49MpzopTel/YiJUVaHr6i4pJ14phT5yhPALL+CsWeOBdUXD1Y3TX6usJiTAkCHokydN9XRNzSUtrm6sXXTz89Fnz3pg9SW4VDCI88UXpkqn+QINGmSmjSUlmfDGsWOdLrhQX3+Nu3UrqqoKMWCAqQnsI7qishsuinPl5qJKS02hZ3cKNrU2BbVPPIHav//8cPIL/SzHMZfYRUUQHW2CsX5/u/6Wqq3F3bzZDPGOi8O+9VbkqFE9v31SXwSrNbhETEz3BggIAZWVJpqfm4uuqLgYrsYeXihlxoPs3ImIjzdjg6VsPVLe0IC7dy/Oiy+i9+/HvuEG7Ouu+9bL3j2wOgkXcXFYc+Z0e3qqHDoUMXTo+eHkzeASUVGmZ0IohNqyBXfnTgiHjWMfFXUeLq1xjx83fdX/+EfcDRuwZswwcxQvZyPZHqgrY6xcW9tNdbUpUO2u0964PTnr15sBBVu2YH3ve/iWLjWN4Jr+X0UF4RUrcP/2N1POP2aMGRWcmYmIiUFXVuLu3o3auBF1+DAyOxv/Qw/1qoh6nwCrq7Epdfo06uRJhOOgExKwExOhMTzREVy6qgpnzRrczz4zl+Ll5QbuQMAEU6uqECkpyFmzTCulSM2m8cDqwQqHcdavR23caDo5V1eb+sOsLOwbbzxX8NGh5Wrsp6qKi822eOSIuascONBE6KdMQU6ciDV6NH1VfQesUIjwe+8RXrHCpCg7jnHMpUSHQtg33ID/4YfPtY7sCC5c10B2+rSJTyllnHMpIRAwma99WHZfeJNNk0md554zPaquvho5daqp+ztyBLVmjSlaTUnB96MfIVNSzt0xhpYvx1250jzRhXA1xqRkSgr00P4JHliXG6oLikntJUuwFy1CDByIDARwy8txYmLQb7yB+uor9Pz5MGAAWFbHcHnqm2C11vXFvuce05ikMeddpKaaNkbR0abFZUXFRdkGHlweWC3CCGrjRtOgo6wM3x13tNr1RQqBC
+eLK6RsMYnUg+vSJXvtOxMCMWSIiTE5Dqq4GGf37hYPcysrUQUFiPp65MiRpkS/lfOMfe21+JcuRUyfjrtyJeHly006tKc+BhZmKmnTxbXKz295ca21Kb9fu9a0cGy8bG6rNOxCuPTJk1Bb6xHUl8MN7q5dhJYvb5FD7+bmElq2DHf7duzbb8f3k59gjRrVse+2YwfKdbF7cH8qD6xvCS7f/Pk4K1eitm7FuvFGfI8/bqY6ePLA6g5cOhBA1NQYqB57rNsX2Z76ULihhc/VLIeeAQOwvvtdDyrPeY8cXHLBAjh9mvBf/xr5NGdPfQ+s5nBdthx6D6y+KQ8uDywPLg+s3gGXu3OnR4Z3KozsaZGKCrTjeIvSTfW91OR25B44gK6txc7K8hbDA8uT52N58sDy5MkDy5MHlicPLE+ePLA8eWB58sDy5MkDy5MHlicPLE+ePLA8eWB58sDy5MkDy5MHlqfeq/8HGXTP/IN2rkQAAAAASUVORK5CYII=', 7832);

ALTER TABLE shop_varuosa ADD CONSTRAINT "check_artikli_nr" CHECK ("artikli_nr" SIMILAR TO 'ALM-([\d]+[a-zA-z]*)');
ALTER TABLE shop_varuosa ALTER COLUMN "kogus" SET DEFAULT 0;
ALTER TABLE shop_varuosa ALTER COLUMN "varuosa_seisund_id" SET DEFAULT 1;
ALTER TABLE shop_varuosa ALTER COLUMN "tootja_id" SET DEFAULT 1;
ALTER TABLE shop_varuosa ALTER COLUMN "varuosa_kulg_id" SET DEFAULT 1;
ALTER TABLE shop_varuosa ADD CONSTRAINT "check_tukihind" CHECK ("tukihind" >= 0.0);
ALTER TABLE "shop_varuosa" ALTER COLUMN "pilt" SET DEFAULT 'img_varuosad/default_varuosa.png';



INSERT INTO shop_varuosa ("varuosa_id", "artikli_nr", "tukihind", "kogus",  "monteerimis_koht", "varuosa_kulg_id", "mootmed", "varuosa_kategooria_id")
VALUES (1,'ALM-3242', 36.5, 10, 'parem lohzheron', 1, '40x50', 1);

INSERT INTO shop_varuosa ("varuosa_id", "artikli_nr", "tukihind", "kogus",  "monteerimis_koht", "varuosa_kulg_id", "mootmed", "varuosa_kategooria_id")
VALUES (2,'ALM-4334a',  24.2, 20, 'vasak lohzheron', 2, '40x50', 1);

INSERT INTO shop_varuosa ("varuosa_id", "artikli_nr", "tukihind", "kogus",  "monteerimis_koht", "varuosa_kulg_id", "mootmed", "varuosa_kategooria_id")
VALUES (3, 'ALM-6666',  10.0, 450, 'taga vasak uks', 2, '4x2', 6);




